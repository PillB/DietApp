# AGENT DEVELOPMENT LOG AND SPECIFICATION

## Project Overview

This document records the iterative design and implementation process for the **Instant Pot Meal Planner** website.  The goal of the project is to create a simple, beautiful, multilingual Single Page Application (SPA) that summarises a flavour profile derived from the user's historic food orders, displays a calendar of curated recipes, provides detailed recipe instructions, and builds a consolidated shopping list.  The site is inspired by art nouveau design motifs and supports English, Spanish, Chinese (中文), Hindi (हिन्दी) and German (Deutsch).  This prototype uses static HTML, Tailwind CSS via CDN and vanilla JavaScript.  All data are embedded in the browser to keep deployment and hosting simple.

## Phase 1: Planning and Requirements Analysis

**Objective:** Understand the user’s requirements and design a plan that can be implemented within the constraints of the environment.  Key tasks include reviewing the data set, extracting important flavour insights, researching best‑in‑class features, and defining the architecture for the SPA.

- **User requirements:**
  - Visualise a flavour profile (spiciness, texture preferences, etc.) based on the provided dataset.
  - Present recipes and a meal planner calendar with ability to review details and generate shopping lists.
  - Support multiple languages: English, Spanish, Chinese, Hindi and German.
  - Use an art nouveau aesthetic and responsive layout.
  - Provide thorough documentation and tests.
- **Data review:**  The spreadsheet `food_delivery_orders_extracted(2).xlsx` includes 1 340 food orders.  We extracted basic flavour statistics (spicy, crispy, sweet, etc.) by scanning descriptions for keywords; counts were stored in `flavourStats`.  These inform the chart in the flavour profile section.
- **Recipe corpus:**  Three sample recipes from the prior gourmet meal plan were chosen for this prototype: *Artichoke Benedict with Trout*, *Brown Rice Risotto with Scallops* and *Miso‑Glazed Salmon Bowl*.  Each recipe includes multi‑language names, portions, times, ingredient lists and step‑by‑step instructions.  Additional recipes can be appended later to the JSON structure.
- **Architecture:**  A single HTML file loads Tailwind CSS and two scripts: `data.js` defines the global data object; `app.js` contains logic for rendering and interactivity.  No build tools are required.
- **Research:**  We consulted meal‑planning app reviews and feature rundowns.  Key takeaways include the importance of drag‑and‑drop meal calendars, automatic grocery list generation, and the ability to view full recipes within the app【194362531740951†L158-L169】.

## Phase 2: Data Extraction and Structuring

**Objective:** Prepare the dataset and recipe information for use in the SPA.

- Parsed the `Food_Orders` sheet to compute the frequency of key flavour descriptors; stored results in `appData.flavourStats`.
- Selected three representative recipes from the gourmet plan and transcribed their ingredients and instructions.  These are stored in `appData.recipes` as objects with multilingual fields.  Each ingredient uses a canonical key, quantity, unit and translations.
- Defined a simple `calendarAssignments` array with four weeks of seven days, assigning the sample recipes in rotation.  This can be extended to support custom scheduling.

## Phase 3: Interface Design and Multilingual Support

**Objective:** Design an intuitive interface and implement i18n infrastructure.

- Added a persistent sidebar with navigation links for the Flavour Profile, Recipes, Calendar and Shopping List sections.  An accessible select element allows the user to switch languages at any time.
- Embedded an i18n dictionary in `app.js` for UI labels and day names.  Each UI element with a `data-i18n` attribute is updated on language change.  Recipe names, ingredients and instructions are drawn from per‑language fields.
- Implemented a bar chart in pure CSS to visualise the flavour statistics.  Bars scale relative to the maximum count.
- Built a responsive calendar using plain HTML tables; clicking on a day opens the corresponding recipe in a modal dialog.  Labels adapt based on the selected language.
- Implemented a shopping list generator that aggregates ingredient quantities across all calendar entries and displays them in a simple list.  For brevity, all ingredients are grouped into a single section; in future iterations, categories (produce, proteins, pantry) could be added.

## Phase 4: Testing and Validation

**Objective:** Ensure that the interface works correctly, content is translated accurately, and design constraints are satisfied.

- Manually tested the navigation links, language switching, recipe modal, calendar interactions and shopping list in Chromium.  Verified that switching languages updates all visible text and that ingredients/steps display correctly.
- Checked for responsive layout issues and overlaps by resizing the browser window.  Adjusted padding and width properties to prevent overflow.
- Reviewed translations for accuracy using online dictionaries.  Placeholder translations should be reviewed by native speakers in future iterations.
- Ensured that content from the dietary guidelines and meal plan complies with the user’s PDF: no added sugars beyond 10 g per portion, minimal processed ingredients, and balanced protein sources.

## Phase 5: Future Work and Enhancements

This prototype is intentionally lightweight; numerous enhancements are possible:

- **Expand recipe library:** Parse the full gourmet meal plan or allow user‑added recipes.
- **Drag‑and‑drop calendar:** Enable interactive scheduling of meals via drag‑and‑drop, with localStorage persistence.
- **Category‑aware shopping list:** Group ingredients by grocery aisles (produce, dairy, pantry) and support scaling quantities by serving size.
- **Progressive Web App (PWA):** Add service‑worker caching and offline support.
- **Theming:** Incorporate more sophisticated art nouveau patterns, custom fonts and decorative borders.
- **Automated tests:** Integrate Playwright tests for navigation, language switching and dynamic data generation.

## File Structure

```
website_prototype/
├── index.html           # Main HTML page with navigation and content sections
├── AGENT.md             # This documentation file
├── assets/
│   ├── js/
│   │   ├── data.js      # Global data definitions (flavour stats, recipes, calendar assignments)
│   │   └── app.js       # Rendering logic and event handlers
│   └── css/
│       └── (unused)     # Reserved for future custom stylesheets
└── data/
    ├── food_delivery_orders_extracted(2).xlsx
    ├── report.md
    └── dariush-mozaffarian-the-2025-2030-dietary-guidelines.pdf
```

## Usage

Open `index.html` in a modern browser.  Use the sidebar to navigate between sections.  Select a different language from the dropdown to view translated labels and recipe information.  Click on any recipe card or calendar day to view details in a modal dialog.  The shopping list aggregates ingredients across all scheduled meals.