/*
 * Application logic for the Instant Pot Meal Planner prototype.
 *
 * This script consumes the global `appData` defined in data.js and
 * renders the flavour chart, recipes list, calendar and shopping list.
 * It also handles multi-language switching and basic navigation.
 */

(() => {
  // i18n dictionary: keys map to translation strings for UI labels.
  const i18n = {
    flavorProfile: { en: 'Flavor Profile', es: 'Perfil de sabor', zh: '风味剖析', hi: 'स्वाद प्रोफ़ाइल', de: 'Geschmacksprofil' },
    recipes: { en: 'Recipes', es: 'Recetas', zh: '菜谱', hi: 'व्यंजन', de: 'Rezepte' },
    calendar: { en: 'Meal Calendar', es: 'Calendario de comidas', zh: '餐食日历', hi: 'भोजन कैलेंडर', de: 'Essenskalender' },
    shoppingList: { en: 'Shopping List', es: 'Lista de compras', zh: '购物清单', hi: 'खरीदारी सूची', de: 'Einkaufsliste' },
    ingredients: { en: 'Ingredients', es: 'Ingredientes', zh: '食材', hi: 'सामग्री', de: 'Zutaten' },
    instructions: { en: 'Instructions', es: 'Instrucciones', zh: '做法', hi: 'निर्देश', de: 'Anleitung' },
    servings: { en: 'Servings', es: 'Porciones', zh: '份量', hi: 'सर्विंग', de: 'Portionen' },
    time: { en: 'Total time', es: 'Tiempo total', zh: '总时间', hi: 'कुल समय', de: 'Gesamtzeit' },
    monday: { en: 'Monday', es: 'Lunes', zh: '周一', hi: 'सोम', de: 'Montag' },
    tuesday: { en: 'Tuesday', es: 'Martes', zh: '周二', hi: 'मंगल', de: 'Dienstag' },
    wednesday: { en: 'Wednesday', es: 'Miércoles', zh: '周三', hi: 'बुध', de: 'Mittwoch' },
    thursday: { en: 'Thursday', es: 'Jueves', zh: '周四', hi: 'गुरु', de: 'Donnerstag' },
    friday: { en: 'Friday', es: 'Viernes', zh: '周五', hi: 'शुक्र', de: 'Freitag' },
    saturday: { en: 'Saturday', es: 'Sábado', zh: '周六', hi: 'शनि', de: 'Samstag' },
    sunday: { en: 'Sunday', es: 'Domingo', zh: '周日', hi: 'रवि', de: 'Sonntag' },
    viewRecipe: { en: 'View recipe', es: 'Ver receta', zh: '查看菜谱', hi: 'रेसिपी देखें', de: 'Rezept ansehen' },
    total: { en: 'Total', es: 'Total', zh: '总计', hi: 'कुल', de: 'Gesamt' }
    ,week: { en: 'Week', es: 'Semana', zh: '周', hi: 'सप्ताह', de: 'Woche' }
  };

  // Current language state
  let currentLang = 'en';

  // DOM elements
  const flavourSection = document.getElementById('flavorSection');
  const recipesSection = document.getElementById('recipesSection');
  const calendarSection = document.getElementById('calendarSection');
  const shoppingSection = document.getElementById('shoppingSection');

  const navLinks = {
    flavor: document.getElementById('navFlavor'),
    recipes: document.getElementById('navRecipes'),
    calendar: document.getElementById('navCalendar'),
    shopping: document.getElementById('navShopping')
  };

  const langSelect = document.getElementById('langSelect');

  // Initialise application
  function init() {
    // Render default section
    showSection('flavor');
    // Render content
    renderFlavorChart();
    renderRecipes();
    renderCalendar();
    renderShoppingList();
    // Attach nav listeners
    navLinks.flavor.addEventListener('click', () => showSection('flavor'));
    navLinks.recipes.addEventListener('click', () => showSection('recipes'));
    navLinks.calendar.addEventListener('click', () => showSection('calendar'));
    navLinks.shopping.addEventListener('click', () => showSection('shopping'));
    // Language change
    langSelect.addEventListener('change', (e) => {
      currentLang = e.target.value;
      applyTranslations();
      // re-render dynamic content
      renderFlavorChart();
      renderRecipes();
      renderCalendar();
      renderShoppingList();
    });
    // Close modal
    document.getElementById('closeModal').addEventListener('click', closeModal);
    // Initial translations
    applyTranslations();
  }

  /**
   * Show one section and hide others.
   */
  function showSection(name) {
    // Remove active background
    Object.values(navLinks).forEach(link => link.classList.remove('bg-emerald-300'));
    // Hide all sections
    [flavourSection, recipesSection, calendarSection, shoppingSection].forEach(sec => sec.classList.add('hidden'));
    if (name === 'flavor') {
      navLinks.flavor.classList.add('bg-emerald-300');
      flavourSection.classList.remove('hidden');
    } else if (name === 'recipes') {
      navLinks.recipes.classList.add('bg-emerald-300');
      recipesSection.classList.remove('hidden');
    } else if (name === 'calendar') {
      navLinks.calendar.classList.add('bg-emerald-300');
      calendarSection.classList.remove('hidden');
    } else if (name === 'shopping') {
      navLinks.shopping.classList.add('bg-emerald-300');
      shoppingSection.classList.remove('hidden');
    }
  }

  /**
   * Replace text content of elements annotated with data-i18n attributes.
   */
  function applyTranslations() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (i18n[key]) {
        el.textContent = i18n[key][currentLang] || i18n[key]['en'];
      }
    });
  }

  /**
   * Render the flavour bar chart based on appData.flavourStats.
   */
  function renderFlavorChart() {
    const container = document.getElementById('flavorChart');
    // Clear container
    container.innerHTML = '';
    const stats = appData.flavourStats;
    const maxVal = Math.max(...Object.values(stats));
    Object.keys(stats).forEach(key => {
      const bar = document.createElement('div');
      bar.className = 'flex items-center mb-2';
      const label = document.createElement('span');
      // Translate the descriptor if available; fallback to English key
      label.textContent = i18n[key] ? i18n[key][currentLang] || i18n[key]['en'] : key;
      label.className = 'w-32 text-sm';
      const progress = document.createElement('div');
      progress.className = 'h-4 bg-emerald-400';
      progress.style.width = `${(stats[key] / maxVal) * 100}%`;
      const value = document.createElement('span');
      value.textContent = stats[key];
      value.className = 'ml-2 text-xs text-gray-600';
      bar.appendChild(label);
      bar.appendChild(progress);
      bar.appendChild(value);
      container.appendChild(bar);
    });
  }

  /**
   * Render the list of recipes with a brief overview.
   */
  function renderRecipes() {
    const listEl = document.getElementById('recipeList');
    listEl.innerHTML = '';
    appData.recipes.forEach(recipe => {
      const card = document.createElement('div');
      card.className = 'border rounded p-4 shadow hover:shadow-lg transition cursor-pointer';
      const title = document.createElement('h3');
      title.className = 'text-lg font-semibold mb-1';
      title.textContent = recipe.name[currentLang] || recipe.name['en'];
      const info = document.createElement('p');
      info.className = 'text-sm text-gray-600';
      info.textContent = `${i18n.servings[currentLang] || i18n.servings['en']}: ${recipe.servings} – ${i18n.time[currentLang] || i18n.time['en']}: ${recipe.time}`;
      card.appendChild(title);
      card.appendChild(info);
      card.addEventListener('click', () => openRecipeModal(recipe));
      listEl.appendChild(card);
    });
  }

  /**
   * Open recipe modal with details.
   */
  function openRecipeModal(recipe) {
    const modal = document.getElementById('recipeModal');
    modal.classList.remove('hidden');
    document.getElementById('modalTitle').textContent = recipe.name[currentLang] || recipe.name['en'];
    document.getElementById('modalServings').textContent = `${i18n.servings[currentLang] || i18n.servings['en']}: ${recipe.servings} – ${i18n.time[currentLang] || i18n.time['en']}: ${recipe.time}`;
    // Populate ingredients
    const ingList = document.getElementById('modalIngredients');
    ingList.innerHTML = '';
    recipe.ingredients.forEach(item => {
      const li = document.createElement('li');
      li.textContent = `${item.qty} ${item.unit} ${item.names[currentLang] || item.names['en']}`.trim();
      ingList.appendChild(li);
    });
    // Populate instructions
    const stepsEl = document.getElementById('modalInstructions');
    stepsEl.innerHTML = '';
    (recipe.instructions[currentLang] || recipe.instructions['en']).forEach(step => {
      const li = document.createElement('li');
      li.textContent = step;
      stepsEl.appendChild(li);
    });
  }

  function closeModal() {
    document.getElementById('recipeModal').classList.add('hidden');
  }

  /**
   * Render a simple calendar showing four weeks with assigned recipes.
   */
  function renderCalendar() {
    const container = document.getElementById('calendarContainer');
    container.innerHTML = '';
    const weekDays = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
    appData.calendarAssignments.forEach((week, wIdx) => {
      const table = document.createElement('table');
      table.className = 'w-full mb-6 table-auto';
      const thead = document.createElement('thead');
      const headRow = document.createElement('tr');
      weekDays.forEach(dayKey => {
        const th = document.createElement('th');
        th.className = 'p-2 border';
        th.textContent = i18n[dayKey][currentLang] || i18n[dayKey]['en'];
        headRow.appendChild(th);
      });
      thead.appendChild(headRow);
      table.appendChild(thead);
      const tbody = document.createElement('tbody');
      const row = document.createElement('tr');
      week.forEach(recipeId => {
        const td = document.createElement('td');
        td.className = 'p-2 border text-sm hover:bg-emerald-100 cursor-pointer';
        const recipe = appData.recipes.find(r => r.id === recipeId);
        td.textContent = recipe ? recipe.name[currentLang] || recipe.name['en'] : '';
        td.addEventListener('click', () => openRecipeModal(recipe));
        row.appendChild(td);
      });
      tbody.appendChild(row);
      table.appendChild(tbody);
      // Week label
      const label = document.createElement('h3');
      label.className = 'font-semibold mt-4 mb-1';
      const weekLabel = (i18n.week && (i18n.week[currentLang] || i18n.week['en'])) || 'Week';
      label.textContent = `${weekLabel} ${wIdx + 1}`;
      container.appendChild(label);
      container.appendChild(table);
    });
  }

  /**
   * Aggregate ingredients from all recipes in the current calendar assignments and render a shopping list.
   */
  function renderShoppingList() {
    const shoppingEl = document.getElementById('shoppingList');
    shoppingEl.innerHTML = '';
    // Compute aggregated quantities per ingredient key
    const counts = {};
    appData.calendarAssignments.flat().forEach(recipeId => {
      const recipe = appData.recipes.find(r => r.id === recipeId);
      if (recipe) {
        recipe.ingredients.forEach(item => {
          const key = item.key;
          // Parse quantity to numeric where possible; for fractions keep string
          const qty = parseFloat(item.qty) || 0;
          const unit = item.unit;
          if (!counts[key]) {
            counts[key] = { total: 0, unit: unit, names: item.names };
          }
          counts[key].total += qty;
        });
      }
    });
    // Render list grouped by categories (simplified: all in one group)
    Object.keys(counts).forEach(key => {
      const li = document.createElement('div');
      li.className = 'flex justify-between p-2 border';
      const name = counts[key].names[currentLang] || counts[key].names['en'];
      const qty = counts[key].total;
      li.textContent = `${name}: ${qty}${counts[key].unit}`;
      shoppingEl.appendChild(li);
    });
  }

  // Kick off the app when DOM is fully loaded.  Using `load` ensures CSS and
  // linked resources are ready; on file:// origins `DOMContentLoaded` may not
  // fire consistently across browsers.
  window.addEventListener('load', init);
})();