// Global data file containing flavour statistics, recipes and calendar assignments.
// This script defines a single global variable `appData` on the window object
// so that other scripts can access the structured data without ES module imports.

(function() {
  /**
   * flavourStats summarises the frequency of certain flavour descriptors based on
   * the user's historic food orders. This informs the flavour profile chart.
   * The keys are canonical English descriptors; the values indicate relative
   * counts observed in the dataset. Use this to generate charts in other
   * languages by translating the keys via the i18n dictionary in app.js.
   */
  const flavourStats = {
    spicy: 111,
    crispy: 56,
    sweet: 45,
    creamy: 38,
    savory: 35,
    crunchy: 28,
    tender: 22,
    smoky: 18
  };

  /**
   * Sample recipes extracted from the gourmet meal plan. Each recipe includes
   * multi-language titles and ingredients/instructions. Only a subset of the
   * complete plan is included here for demonstration; additional recipes can
   * easily be appended following the same schema. The `id` field uniquely
   * identifies each recipe and is used by the calendar assignments.
   */
  const recipes = [
    {
      id: 1,
      name: {
        en: 'Artichoke Benedict with Trout',
        es: 'Benedictino de Alcachofa con Trucha',
        zh: '洋蓟班尼迪克蛋配鳟鱼',
        hi: 'आर्टिचोक बेनेडिक्ट विद ट्राउट',
        de: 'Artischocken-Benedict mit Forelle'
      },
      servings: 2,
      time: '45 min',
      ingredients: [
        { key: 'artichoke', qty: '4', unit: '', names: { en:'Artichoke hearts', es:'Corazones de alcachofa', zh:'洋蓟心', hi:'आर्टिचोक हर्ट्स', de:'Artischockenherzen' } },
        { key: 'trout', qty: '200', unit: 'g', names: { en:'Fresh trout fillet', es:'Filete de trucha fresca', zh:'新鲜鳟鱼片', hi:'ताज़ा ट्राउट फ़िलेट', de:'Frisches Forellenfilet' } },
        { key: 'eggs', qty: '2', unit: '', names: { en:'Eggs', es:'Huevos', zh:'鸡蛋', hi:'अंडे', de:'Eier' } },
        { key: 'hollandaise', qty: '100', unit: 'ml', names: { en:'Hollandaise sauce', es:'Salsa holandesa', zh:'荷兰酱', hi:'हॉलंडैज़ सॉस', de:'Sauce Hollandaise' } },
        { key: 'spinach', qty: '50', unit: 'g', names: { en:'Baby spinach', es:'Espinaca baby', zh:'嫩菠菜', hi:'बेबी पालक', de:'Babyspinat' } },
        { key: 'bread', qty: '2', unit: 'slices', names: { en:'Whole-grain bread', es:'Pan integral', zh:'全麦面包', hi:'संपूर्ण अनाज ब्रेड', de:'Vollkornbrot' } }
      ],
      instructions: {
        en: [
          'Toast the whole-grain bread slices until golden.',
          'Sauté the baby spinach briefly until wilted.',
          'Poach the eggs in simmering water with a splash of vinegar for 3–4 minutes.',
          'Pan-sear the trout fillets until opaque and flake gently.',
          'Layer the toast with spinach, trout, poached egg, and spoon over hollandaise sauce.'
        ],
        es: [
          'Tostar las rebanadas de pan integral hasta que estén doradas.',
          'Saltear brevemente la espinaca baby hasta que se ablande.',
          'Escalfar los huevos en agua hirviendo con un chorrito de vinagre durante 3–4 minutos.',
          'Sellar los filetes de trucha hasta que estén opacos y se desmenucen suavemente.',
          'Montar el pan con espinaca, trucha, huevo escalfado y cubrir con salsa holandesa.'
        ],
        zh: [
          '将全麦面包片烘烤至金黄。',
          '快速翻炒嫩菠菜至微萎。',
          '在微沸的水中加少许醋，水波煮鸡蛋3–4分钟。',
          '煎鳟鱼片至熟透但仍柔嫩。',
          '将烤面包依次铺上菠菜、鳟鱼、溏心蛋，并淋上荷兰酱。'
        ],
        hi: [
          'संपूर्ण अनाज ब्रेड के स्लाइस को सुनहरा होने तक टोस्ट करें।',
          'बेबी पालक को कुछ सेकंड के लिए भूनें जब तक वह मुरझा न जाए।',
          'अंडों को पानी में हल्का सा सिरका डालकर 3–4 मिनट तक पोच करें।',
          'ट्राउट फ़िलेट को पैन में पकाएं जब तक वह पक न जाएं और नरम रहें।',
          'टोस्ट पर पालक, ट्राउट, पोच्ड अंडा रखें और हॉलंडैज़ सॉस डालें।'
        ],
        de: [
          'Die Scheiben Vollkornbrot goldbraun toasten.',
          'Den Babyspinat kurz sautieren, bis er zusammenfällt.',
          'Die Eier in simmerndem Wasser mit einem Spritzer Essig 3–4 Minuten pochieren.',
          'Die Forellenfilets in der Pfanne braten, bis sie gar und zart sind.',
          'Brot mit Spinat, Forelle, pochiertem Ei belegen und Sauce Hollandaise darübergeben.'
        ]
      }
    },
    {
      id: 2,
      name: {
        en: 'Brown Rice Risotto with Scallops',
        es: 'Risotto de Arroz Integral con Vieiras',
        zh: '糙米烩饭配扇贝',
        hi: 'ब्राउन राइस रिसोट्टो विद स्कैलप्स',
        de: 'Vollkorn-Risotto mit Jakobsmuscheln'
      },
      servings: 2,
      time: '60 min',
      ingredients: [
        { key:'brown_rice', qty:'200', unit:'g', names:{ en:'Brown rice', es:'Arroz integral', zh:'糙米', hi:'ब्राउन चावल', de:'Vollkornreis' } },
        { key:'scallops', qty:'6', unit:'', names:{ en:'Sea scallops', es:'Vieiras', zh:'扇贝', hi:'स्कैलप्स', de:'Jakobsmuscheln' } },
        { key:'parmesan', qty:'50', unit:'g', names:{ en:'Parmesan cheese', es:'Queso parmesano', zh:'帕尔马干酪', hi:'परमेसन चीज़', de:'Parmesan' } },
        { key:'broth', qty:'500', unit:'ml', names:{ en:'Vegetable broth', es:'Caldo de verduras', zh:'蔬菜高汤', hi:'सब्जी शोरबा', de:'Gemüsebrühe' } },
        { key:'butter', qty:'30', unit:'g', names:{ en:'Butter', es:'Mantequilla', zh:'黄油', hi:'मक्खन', de:'Butter' } },
        { key:'onion', qty:'1/2', unit:'', names:{ en:'Onion', es:'Cebolla', zh:'洋葱', hi:'प्याज', de:'Zwiebel' } },
        { key:'white_wine', qty:'50', unit:'ml', names:{ en:'White wine (optional)', es:'Vino blanco (opcional)', zh:'白葡萄酒（可选）', hi:'सफेद वाइन (वैकल्पिक)', de:'Weißwein (optional)' } }
      ],
      instructions: {
        en: [
          'Warm the vegetable broth and keep it simmering.',
          'Sauté diced onion in butter until translucent.',
          'Add brown rice and toast gently for 2 minutes.',
          'Deglaze with white wine (optional) and let evaporate.',
          'Ladle broth gradually, stirring constantly until rice is creamy and tender.',
          'Sear scallops separately until caramelised.',
          'Stir grated Parmesan into the risotto, plate and top with scallops.'
        ],
        es: [
          'Calentar el caldo de verduras y mantenerlo hirviendo suavemente.',
          'Sofreír la cebolla picada en mantequilla hasta que esté translúcida.',
          'Añadir el arroz integral y tostar suavemente durante 2 minutos.',
          'Desglasar con vino blanco (opcional) y dejar que se evapore.',
          'Agregar el caldo gradualmente, revolviendo constantemente hasta que el arroz esté cremoso y tierno.',
          'Sellar las vieiras por separado hasta que estén caramelizadas.',
          'Incorporar el queso parmesano rallado al risotto, servir y coronar con las vieiras.'
        ],
        zh: [
          '将蔬菜高汤加热保持微沸。',
          '在黄油中炒洋葱丁至透明。',
          '加入糙米翻炒2分钟。',
          '用白葡萄酒（可选）烹锅，待挥发。',
          '逐渐加入高汤，不断搅拌，直至米饭呈奶油状且柔软。',
          '另起锅煎扇贝至焦糖色。',
          '将磨碎的帕尔马干酪拌入烩饭，装盘并铺上扇贝。'
        ],
        hi: [
          'सब्ज़ी शोरबा गर्म करें और धीमी आंच पर रखे रखें।',
          'बटर में कटी प्याज को पारदर्शी होने तक भूनें।',
          'ब्राउन चावल डालें और 2 मिनट तक हल्का भूनें।',
          'सफेद वाइन (वैकल्पिक) से डिग्लेज़ करें और वाष्पित होने दें।',
          'धीरे-धीरे शोरबा डालें, लगातार हिलाते रहें, जब तक कि चावल क्रीमी और मुलायम न हो जाए।',
          'स्कैलप्स को अलग से कैरामेलाइज़ होने तक सेयर करें।',
          'कद्दूकस किए परमेसन को रिसोट्टो में मिलाएं, परोसें और स्कैलप्स से सजाएं।'
        ],
        de: [
          'Die Gemüsebrühe erhitzen und köchelnd warmhalten.',
          'Die gewürfelte Zwiebel in Butter glasig anschwitzen.',
          'Den Vollkornreis hinzufügen und 2 Minuten sanft rösten.',
          'Mit Weißwein (optional) ablöschen und verdampfen lassen.',
          'Brühe nach und nach zugießen, dabei ständig rühren, bis der Reis cremig und zart ist.',
          'Jakobsmuscheln separat anbraten, bis sie karamellisiert sind.',
          'Parmesan unter das Risotto rühren, anrichten und mit Jakobsmuscheln belegen.'
        ]
      }
    },
    {
      id: 3,
      name: {
        en: 'Miso-Glazed Salmon Bowl',
        es: 'Bol de Salmón Glaseado con Miso',
        zh: '味噌酱烤三文鱼饭碗',
        hi: 'मिसो-ग्लेज़्ड सामन बाउल',
        de: 'Miso-glasiertes Lachs-Bowl'
      },
      servings: 2,
      time: '30 min',
      ingredients: [
        { key:'salmon', qty:'300', unit:'g', names:{ en:'Salmon fillet', es:'Filete de salmón', zh:'三文鱼', hi:'सालमन फ़िलेट', de:'Lachsfilet' } },
        { key:'miso', qty:'2', unit:'tbsp', names:{ en:'White miso paste', es:'Pasta de miso blanco', zh:'白味噌酱', hi:'सफ़ेद मिसो पेस्ट', de:'Weiße Misopaste' } },
        { key:'soy_sauce', qty:'1', unit:'tbsp', names:{ en:'Low-sodium soy sauce', es:'Salsa de soja baja en sodio', zh:'低钠酱油', hi:'लो-सोडियम सोया सॉस', de:'Sojasauce (natriumarm)' } },
        { key:'honey', qty:'1', unit:'tbsp', names:{ en:'Honey', es:'Miel', zh:'蜂蜜', hi:'शहद', de:'Honig' } },
        { key:'rice', qty:'150', unit:'g', names:{ en:'Short-grain rice', es:'Arroz de grano corto', zh:'短粒米', hi:'छोटे दाने का चावल', de:'Rundkornreis' } },
        { key:'edamame', qty:'100', unit:'g', names:{ en:'Edamame beans', es:'Frijoles de edamame', zh:'毛豆', hi:'एडामेमे', de:'Edamame-Bohnen' } },
        { key:'pickled_ginger', qty:'20', unit:'g', names:{ en:'Pickled ginger', es:'Jengibre encurtido', zh:'腌姜', hi:'अचार अदरक', de:'Eingelegter Ingwer' } }
      ],
      instructions: {
        en: [
          'Cook the short-grain rice in water until fluffy.',
          'Whisk miso, soy sauce, and honey into a glaze.',
          'Brush the glaze over the salmon fillets and broil or air-fry until caramelised.',
          'Blanch edamame beans until tender.',
          'Assemble bowls with rice, salmon, edamame, and pickled ginger.'
        ],
        es: [
          'Cocinar el arroz de grano corto en agua hasta que quede esponjoso.',
          'Mezclar miso, salsa de soja y miel para obtener el glaseado.',
          'Untar el glaseado sobre los filetes de salmón y cocinar al horno o en airfryer hasta caramelizar.',
          'Blanquear los frijoles de edamame hasta que estén tiernos.',
          'Montar los tazones con arroz, salmón, edamame y jengibre encurtido.'
        ],
        zh: [
          '将短粒米煮熟至蓬松。',
          '调匀味噌、酱油和蜂蜜成酱汁。',
          '将酱汁刷在三文鱼片上，烤或空气炸至焦糖化。',
          '焯水毛豆至熟。',
          '将米饭、三文鱼、毛豆和腌姜装入碗中。'
        ],
        hi: [
          'छोटे दाने के चावल को पानी में fluffy होने तक पकाएं।',
          'मिसो, सोया सॉस और शहद को मिलाकर glaze तैयार करें।',
          'इस glaze को सामन फ़िलेट पर ब्रश करें और Broil/air-fry करें जब तक caramelise न हो जाए।',
          'एडामेमे को नरम होने तक blanch करें।',
          'बाउल में चावल, सामन, एडामेमे और अचार अदरक को एक साथ परोसें।'
        ],
        de: [
          'Den Rundkornreis in Wasser garen bis er locker ist.',
          'Miso, Sojasauce und Honig zu einer Glasur verrühren.',
          'Die Glasur über die Lachsfilets pinseln und im Ofen oder der Heißluftfritteuse karamellisieren.',
          'Edamame blanchieren, bis sie zart sind.',
          'Bowls mit Reis, Lachs, Edamame und eingelegtem Ingwer zusammenstellen.'
        ]
      }
    }
  ];

  /**
   * calendarAssignments defines which recipe IDs appear on each day of the
   * four-week planner. Weeks are arrays of seven day entries (Monday–Sunday).
   */
  const calendarAssignments = [
    [1, 2, 3, 1, 2, 3, 1],
    [2, 3, 1, 2, 3, 1, 2],
    [3, 1, 2, 3, 1, 2, 3],
    [1, 2, 3, 1, 2, 3, 1]
  ];

  // Expose data globally
  window.appData = { flavourStats, recipes, calendarAssignments };
})();