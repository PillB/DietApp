# Recipe App Import Pack — Gourmet Meal Plan

This pack contains import-friendly versions of the DGA-reviewed gourmet meal plan recipes. It was generated from the existing GitHub SPA data file and keeps the original metric measurements, mise en place, method steps, food-science notes, pairing notes, and recipe-level DGA compliance metadata.

## Recommended import routes

### 1. Mela (best direct import)
Use `mela/gourmet-meal-plan-dga-reviewed.melarecipes`.

Open the file on iPhone/iPad/Mac and share/open it with Mela. The file is a ZIP of `.melarecipe` JSON files following Mela's documented import/export format.

### 2. Paprika (best power-user import)
Use `paprika/gourmet-meal-plan-paprika.yml`.

Paprika supports importing a plain YAML file with multiple recipes. Copy this file into iCloud Drive/Files, then in Paprika go to Settings → Import Recipes and choose the `.yml` file. If the YAML importer rejects a recipe because of strict whitespace, use the Schema.org HTML route below.

### 3. AnyList / Recipe Keeper / Crouton / Pestle / Samsung Food / MealBoard / CookBook
Use `schema-org-html/`.

Deploy this folder to GitHub Pages or any static hosting. Then open each recipe URL in Safari and use the app's Share Extension / Web Import. Each recipe page embeds Schema.org Recipe JSON-LD so standards-based importers can identify ingredients and instructions.

### 4. Universal archival / spreadsheet route
Use `csv/recipes.csv`, `csv/shopping_lists.csv`, `markdown/recipes.md`, and `schema-org-jsonld/recipes-schemaorg-graph.jsonld`.

These are best for backup, Notion/Airtable/Sheets import, custom scripts, or future conversion.

## Files

- `mela/gourmet-meal-plan-dga-reviewed.melarecipes` — bulk import for Mela; also likely useful for apps that import Mela files.
- `mela/individual_melarecipe_files/` — one `.melarecipe` JSON file per recipe.
- `paprika/gourmet-meal-plan-paprika.yml` — direct multi-recipe YAML import for Paprika.
- `schema-org-html/index.html` and `schema-org-html/recipes/*.html` — standards-based web import pages.
- `schema-org-jsonld/*.jsonld` — open Schema.org JSON-LD exports.
- `csv/*.csv` — recipe and shopping-list spreadsheets.
- `markdown/*.md` — human-readable backup.

## Practical note
No iOS recipe app is perfect at bulk-importing every external custom field. If an app does not preserve DGA compliance notes or pairings as separate fields, they are intentionally embedded into the notes/instructions sections so the information is not lost.
