# Master Weekly Shopping Lists

## Week 1

### Produce

- [ ] Artichokes (6 whole)
- [ ] lemons (4)
- [ ] limes (12)
- [ ] cilantro (3 bunches)
- [ ] chives
- [ ] red onions (4)
- [ ] cucumbers (3)
- [ ] avocados (4)
- [ ] purple corn or chicha morada concentrate
- [ ] pineapple
- [ ] tomatoes (8)
- [ ] sweet potatoes (2)
- [ ] red cabbage
- [ ] carrot
- [ ] mango
- [ ] plantains (3)
- [ ] rocoto chiles
- [ ] garlic (3 heads)
- [ ] ginger
- [ ] scallions
- [ ] mushrooms (200 g)
- [ ] shallot
- [ ] edamame (200 g)
- [ ] kale (200 g)
- [ ] radishes
- [ ] micro-greens
- [ ] herbs (mint, parsley).

### Proteins

- [ ] Roasted trout (200 g)
- [ ] salmon fillet (720 g)
- [ ] sashimi-grade tuna/salmon (200 g)
- [ ] beef sirloin (1 kg)
- [ ] lamb or beef chuck (800 g)
- [ ] beef sirloin for bulgogi (400 g)
- [ ] seafood mix (cod 600 g, prawns 400 g, squid 300 g)
- [ ] turkey mince (250 g)
- [ ] firm tofu (400 g)
- [ ] eggs (3 dozen)
- [ ] chicken breasts (4)
- [ ] black cod (600 g)
- [ ] short ribs (1.2 kg).

### Dairy

- [ ] Butter (500 g)
- [ ] heavy cream (500 ml)
- [ ] whole milk (1 L)
- [ ] Greek yoghurt (600 g)
- [ ] cream cheese (200 g)
- [ ] mascarpone (250 g)
- [ ] queso fresco (600 g)
- [ ] mozzarella (200 g)
- [ ] Parmesan & Pecorino (400 g total).

### Grains & bakery

- [ ] Whole-wheat flour (2 kg)
- [ ] bread flour (1 kg)
- [ ] quinoa (800 g)
- [ ] brown rice (1 kg)
- [ ] whole-grain tortillas
- [ ] corn tortillas
- [ ] ramen noodles
- [ ] whole-wheat spaghetti
- [ ] whole-wheat gnocchi ingredients (potatoes)
- [ ] oats (200 g)
- [ ] whole-grain ladyfinger ingredients
- [ ] whole-grain pizza dough ingredients
- [ ] rolled oats or cooked potato
- [ ] purple potatoes
- [ ] bagel ingredients.

### Pantry

- [ ] Olive oil (500 ml)
- [ ] sesame oil
- [ ] sunflower oil
- [ ] low-sodium soy sauce
- [ ] low-sodium tamari
- [ ] fish sauce
- [ ] oyster sauce
- [ ] miso (white and red)
- [ ] aji amarillo paste (300 g)
- [ ] ají panca paste
- [ ] rocoto paste
- [ ] chipotle in adobo
- [ ] dried guajillo and ancho chiles
- [ ] cumin
- [ ] coriander seeds
- [ ] cinnamon stick
- [ ] cloves
- [ ] star anise
- [ ] brown raw sugar or honey (measured; added-sugar cap <=10 g/serving)
- [ ] honey
- [ ] coconut raw sugar or honey (measured; added-sugar cap <=10 g/serving)
- [ ] raw raw sugar or honey (measured; added-sugar cap <=10 g/serving)
- [ ] cocoa powder
- [ ] dark chocolate (500 g)
- [ ] almonds
- [ ] pecans
- [ ] peanuts
- [ ] sesame seeds
- [ ] seaweed (nori)
- [ ] bonito flakes
- [ ] tenkasu or breadcrumbs
- [ ] vinegar (rice, cider, white)
- [ ] baking powder
- [ ] yeast
- [ ] malt syrup.

### Beverages & Misc.

- [ ] Sparkling water
- [ ] unsalted mushroom stock; sake optional for adults
- [ ] verjus or unsalted stock; dry white wine optional for adults
- [ ] pomegranate molasses
- [ ] Marsala or fortified wine (for tiramisu)
- [ ] espresso; whiskey optional for adults
- [ ] beer or non-alcoholic alternatives.

## Week 2

### Produce

- [ ] Mushrooms (400 g)
- [ ] artichokes
- [ ] tomatoes (8)
- [ ] bell peppers (3)
- [ ] eggplant (optional)
- [ ] olives (80 g)
- [ ] capers (30 g)
- [ ] carrots
- [ ] celery
- [ ] onions
- [ ] spinach or Swiss chard
- [ ] purple potatoes
- [ ] lemons
- [ ] limes
- [ ] herbs (basil, oregano, rosemary)
- [ ] lucuma purée or fresh lucuma
- [ ] salad greens.

### Proteins

- [ ] Sea scallops (8)
- [ ] prawns (12)
- [ ] chicken breasts (4)
- [ ] grass-fed beef or lamb for birria (remainder if needed)
- [ ] salmon
- [ ] tuna
- [ ] cod
- [ ] turkey mince (if replenishing)
- [ ] eggs.

### Dairy

- [ ] Parmesan
- [ ] Pecorino
- [ ] mozzarella
- [ ] mascarpone
- [ ] Greek yoghurt
- [ ] cream cheese.

### Grains

- [ ] Brown rice
- [ ] whole-grain pasta
- [ ] whole-wheat flour
- [ ] bread flour
- [ ] quinoa
- [ ] corn tortillas
- [ ] rolled oats or cooked potato
- [ ] whole-grain pizza dough ingredients.

### Pantry

- [ ] Canned San Marzano tomatoes
- [ ] anchovies
- [ ] anchovy fillets
- [ ] olives
- [ ] capers
- [ ] ají panca paste
- [ ] dried herbs
- [ ] chipotle
- [ ] cocoa powder
- [ ] honey
- [ ] raw raw sugar or honey (measured; added-sugar cap <=10 g/serving)
- [ ] dark chocolate
- [ ] espresso beans
- [ ] nuts (pecans)
- [ ] spices as needed.

## Week 3

### Produce

- [ ] Mangoes
- [ ] jicama
- [ ] red cabbage
- [ ] limes
- [ ] avocados
- [ ] cucumbers
- [ ] carrots
- [ ] onions
- [ ] tomatoes
- [ ] radishes
- [ ] cilantro
- [ ] Thai basil
- [ ] shallots
- [ ] ginger
- [ ] garlic
- [ ] scallions
- [ ] chili peppers (guajillo, ancho, chipotle)
- [ ] sesame seeds
- [ ] edamame
- [ ] kimchi ingredients if making from scratch (napa cabbage, daikon, Korean chile powder).

### Proteins

- [ ] White fish for tacos (600 g)
- [ ] salmon
- [ ] turkey mince
- [ ] tofu
- [ ] lamb or beef for birria (if not leftover)
- [ ] eggs
- [ ] squid
- [ ] shrimp
- [ ] octopus
- [ ] ground turkey.

### Dairy

- [ ] Greek yoghurt
- [ ] crema or sour cream alternative
- [ ] cotija cheese
- [ ] butter.

### Grains

- [ ] Whole-wheat tortillas
- [ ] corn tortillas
- [ ] brown rice
- [ ] quinoa
- [ ] ramen noodles.

### Pantry

- [ ] Cornstarch
- [ ] baking powder
- [ ] sparkling water
- [ ] low-sodium soy sauce
- [ ] gochujang
- [ ] sesame oil
- [ ] mirin
- [ ] miso
- [ ] miso paste
- [ ] unsalted mushroom stock; sake optional for adults
- [ ] vinegars
- [ ] chipotle in adobo
- [ ] cumin
- [ ] smoked paprika
- [ ] cinnamon
- [ ] honey
- [ ] cocoa powder.

## Week 4

### Produce

- [ ] Purple potatoes
- [ ] Swiss chard or kale
- [ ] oranges (for curing salmon)
- [ ] dill
- [ ] fresh herbs (parsley, cilantro)
- [ ] garlic
- [ ] onions
- [ ] mushrooms
- [ ] cabbage
- [ ] carrots
- [ ] celery
- [ ] lettuce
- [ ] avocados
- [ ] lemons
- [ ] limes
- [ ] pomegranates or pomegranate juice.

### Proteins

- [ ] Salmon fillet (for curing)
- [ ] beef short ribs
- [ ] chicken thighs
- [ ] lean grass-fed beef mince or turkey mince (800 g)
- [ ] duck breasts (4)
- [ ] avocado, caramelised onions, and roasted mushrooms for burger toppings
- [ ] eggs.

### Dairy

- [ ] Butter
- [ ] milk
- [ ] cream
- [ ] Greek yoghurt
- [ ] cream cheese
- [ ] cheddar
- [ ] mozzarella
- [ ] Parmesan
- [ ] mascarpone.

### Grains

- [ ] Whole-wheat flour
- [ ] bread flour
- [ ] almond meal
- [ ] cornmeal (for fried chicken breading)
- [ ] farro
- [ ] whole-grain buns or ingredients to make them
- [ ] bagels (if not already made)
- [ ] sourdough loaf
- [ ] popcorn kernels.

### Pantry

- [ ] Pomegranate molasses
- [ ] miso
- [ ] low-sodium soy sauce
- [ ] honey
- [ ] brown raw sugar or honey (measured; added-sugar cap <=10 g/serving)
- [ ] spices (smoked paprika, cayenne)
- [ ] whiskey
- [ ] bourbon
- [ ] cocoa powder
- [ ] dark chocolate
- [ ] nuts (pecans)
- [ ] nutritional yeast
- [ ] truffle oil or truffle salt.
