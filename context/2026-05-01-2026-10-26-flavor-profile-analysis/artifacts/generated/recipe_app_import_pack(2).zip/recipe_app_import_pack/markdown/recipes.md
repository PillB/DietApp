# Gourmet Meal Plan Recipes

## Artichoke Benedict with Roasted Trout (Peruvian × Nikkei)
**Servings: 4 | Active time: 45 min | Total time: 1 h 15 min**

**Mise en place**
- Station A - English muffins: Mix whole-wheat dough (250 g whole-wheat flour, 250 g bread flour, 7 g yeast, 10 g sugar, 300 ml warm milk, 30 g butter, 5 g salt) and let proof; shape into 8 muffins, rest 20 min.
- Station B - Artichokes & trout: Trim and steam 4 large artichoke hearts (400 g), then slice into quarters; season 200 g roasted trout fillet, cooked from fresh trout with olive oil, lemon zest, and no sweet cure and flake into bite-sized pieces.
- Station C - Hollandaise: Juice 1 lemon (30 ml), dice 50 g cold butter, measure 3 egg yolks and 50 ml aji-amarillo purée; set up bain-marie.
- Station D - Poaching setup: Crack 8 fresh eggs into individual ramekins; bring a wide shallow pan of water to a gentle simmer with 30 ml vinegar.
- Station E - Garnishes: Chop 30 g chives and 10 g cilantro; prepare aji amarillo hollandaise ingredients and warm plates.

**Ingredients**
- For the muffins: As per Station A above.
- Protein & veg: 4 steamed artichoke hearts (≈400 g), 200 g roasted trout fillet, cooked from fresh trout with olive oil, lemon zest, and no sweet cure, 8 large eggs.
- Hollandaise: 3 egg yolks, 50 g cold unsalted butter cut into cubes, 30 ml lemon juice, 50 ml aji amarillo purée, 2 ml Dijon mustard, salt to taste.
- Poaching liquor: Water, 30 ml white vinegar.
- Garnish: Chopped chives, cilantro, freshly ground black pepper.

**Method**
1. Cook muffins: Preheat a heavy skillet over medium-low heat. Roll the rested dough into 2 cm-thick rounds using a ring cutter. Cook muffins dry (no fat) until golden on each side (≈5 min per side). Split and keep warm.
2. Steam artichokes: If not already steamed, cook trimmed hearts in salted boiling water until tender (≈10 min); drain and sear in a hot pan with a drizzle of olive oil until lightly caramelised.
3. Prepare hollandaise: In a bain-marie over barely simmering water, whisk egg yolks with lemon juice and mustard until thick ribbons form. Slowly whisk in cold butter cubes one at a time until emulsified. Add aji amarillo purée; season lightly with salt and lemon zest. Keep warm but not hot to avoid scrambling.
4. Poach eggs: Create a gentle vortex in the poaching liquor and slide in one egg at a time. Cook 3 min for runny yolks. Remove with a slotted spoon to a paper towel.
5. Assemble: Place a toasted muffin half on each plate. Top with seared artichoke quarters and flaked roasted trout. Gently perch a poached egg on top and spoon over warm aji amarillo hollandaise. Sprinkle with chives, cilantro and black pepper.

**Why this works**
Whole-wheat muffins provide nutty depth and fibre. Emulsifying butter into egg yolks over gentle heat yields a stable, velvety hollandaise; adding aji amarillo introduces fruity heat and vibrant colour without excess fat. Poaching eggs in acidulated water coagulates the whites quickly for neat spheres, while roasted trout delivers umami and omega-3s. Compliance refinement: the trout is roasted from fresh fish rather than sugar-cured or salt-cured, preserving the seafood umami with less sodium and no processed-meat profile.

**Plating / Pairing**
Serve two halves per person on warm plates. Garnish with micro-greens for colour. Pair with a glass of sparkling brut nature or a chilled chicha morada spritzer (sparkling water with purple-corn reduction and lime) for a non-alcoholic option.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Replaced smoked trout with fresh roasted trout to reduce sodium and avoid cured/smoked processed-food ambiguity.
- Reduced muffin sugar from 10 g to 6 g per batch.

---

## Birria Ramen with Sous-Vide Egg (Mexican × Japanese)
**Servings: 4 | Active time: 1 h | Total time: 6 h (includes braising)**

**Mise en place**
- Station A - Birria broth: Toast 5 dried guajillo and 3 ancho chiles until fragrant; rehydrate in hot water. Sear 800 g lamb or beef chuck in a Dutch oven; gather aromatics (1 onion, 4 garlic cloves, 2 bay leaves, 5 g cumin seeds, 5 g coriander seeds).
- Station B - Ramen tare: Combine 60 ml tamari, 60 ml unsalted mushroom stock; sake optional for adults, 30 ml mirin, 30 ml fish sauce and 30 ml rice vinegar.
- Station C - Noodles & toppings: Prepare 800 g fresh whole-wheat ramen noodles; slice 200 g shiitake mushrooms, 100 g radishes, chop 30 g cilantro, slice 2 limes. Set up sous-vide water bath at 63 °C for eggs.

**Ingredients**
- Birria: 800 g grass-fed lamb or beef chuck cut into chunks, 5 dried guajillo chiles, 3 dried ancho chiles, 1 onion, 4 garlic cloves, 1 stick cinnamon, 2 bay leaves, 5 g each cumin and coriander seeds, 500 ml beef stock, 500 ml water.
- Ramen: 800 g fresh whole-wheat ramen noodles, 4 eggs (for sous-vide), 200 g shiitake mushrooms, 100 g radishes, 100 g bean sprouts, 30 g cilantro, lime wedges.
- Tare: 45 ml low-sodium tamari, 60 ml unsalted mushroom stock or 30 ml rice vinegar + 30 ml water; sake only as an optional adult variation, 30 ml mirin or apple-cider vinegar, 15 ml fish sauce, 30 ml rice vinegar.
- Garnish: 20 g toasted sesame seeds, 2 spring onions sliced.

**Method**
1. Make birria: Toast chiles briefly in a dry pan, then soak in 250 ml boiling water until soft. Blend with soaking liquid, onion, garlic, spices and a pinch of salt to a smooth paste. Sear meat in a Dutch oven until browned; add chile purée, cinnamon stick, bay leaves, stock and water. Bring to a simmer, cover and braise in a 150 °C oven for 4-5 hours until meat is tender. Shred meat and return to broth; adjust salt.
2. Prepare eggs: Submerge eggs in a 63 °C sous-vide bath for 45 min (for jammy yolks). Shock in ice water, then carefully crack and slide into bowls later.
3. Cook noodles & toppings: Sauté mushrooms in a drop of sesame oil until browned; season lightly. Blanch ramen noodles in boiling water for 1 min (fresh) or until al dente; rinse briefly to stop cooking.
4. Assemble bowls: Place 1 tbsp low-sodium tare in each warmed bowl. Add noodles. Ladle over hot birria broth and shredded meat. Top with mushrooms, bean sprouts, sliced radish and cilantro. Gently add peeled sous-vide egg. Finish with sesame seeds, spring onions and a squeeze of lime.

**Why this works**
Slow braising extracts collagen from chuck, producing a silky broth enriched with toasted chiles for deep, complex flavour. The tare concentrates umami (tamari, fish sauce) and balances acidity (vinegar) to season the broth just before serving. Sous-vide eggs cooked at 63 °C achieve custardy yolks that meld into the soup, echoing the richness of traditional ramen. Compliance refinement: the revised tare uses low-sodium tamari, less fish sauce, unsalted stock, and non-alcoholic acidity by default.

**Plating / Pairing**
Serve in deep bowls with long-handled chopsticks and spoons. The broth should be glossy with a gentle chile sheen. Pair with a crisp Kölsch beer (limit to one glass) or a chilled hibiscus-lime agua fresca.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Made sake optional and non-alcoholic stock/vinegar the default.
- Reduced sodium intensity by switching to low-sodium tamari and less fish sauce.

---

## Brown Rice Risotto alla Parmigiana with Artichokes & Scallops (Italian)
**Servings: 4 | Active time: 50 min | Total time: 1 h 10 min (includes soaking)**

**Mise en place**
- Station A - Rice: Soak 300 g short-grain brown rice in water for at least 30 min to soften the bran; drain.
- Station B - Stock: Heat 1.5 L vegetable or fish stock; keep warm on a back burner.
- Station C - Vegetables: Mince 1 shallot, slice 200 g mushrooms, quarter 2 steamed artichoke hearts (200 g), grate 80 g Parmigiano-Reggiano.
- Station D - Scallops: Pat dry 8 large sea scallops (320 g) and season with sea salt; bring a sauté pan to medium-high heat.

**Ingredients**
- 300 g short-grain brown rice (soaked), 1.5 L hot stock (vegetable/fish), 1 shallot, 2 tbsp (30 ml) olive oil, 200 g mixed mushrooms, 200 g cooked artichoke hearts, 80 ml verjus or 60 ml dry white wine as optional adult variation, 80 g Parmigiano-Reggiano, 20 g unsalted butter, 8 sea scallops (≈320 g total), 5 g fresh thyme, salt & black pepper.

**Method**
1. Build the soffritto: In a heavy saucepan over medium heat, sweat minced shallot in olive oil until translucent. Add drained brown rice and stir 2 min to coat the grains; this toasting promotes even absorption.
2. Deglaze: Add verjus (or optional dry white wine); cook until mostly evaporated; if using verjus, reduce just until glossy. Ladle in hot stock (~200 ml at a time), stirring continuously. Maintain a gentle simmer and add more stock only when the previous addition is nearly absorbed. This process takes about 40 min; the rice should be creamy yet toothsome.
3. Cook vegetables: In a separate pan, sauté mushrooms in a drizzle of olive oil until browned; season with thyme, salt and pepper. Add artichoke quarters and warm through.
4. Finish risotto: When rice is just al dente, stir in sautéed mushrooms and artichokes. Remove from heat; vigorously beat in butter and grated Parmigiano-Reggiano to create emulsified creaminess. Season to taste.
5. Sear scallops: Heat a non-stick or stainless pan until very hot. Add 1 tbsp oil, then scallops. Sear without moving for 2 min until a deep golden crust forms; flip and cook 1 min more. The centres should remain slightly translucent.
6. Serve: Spoon risotto into warm shallow bowls; top with two scallops each. Drizzle with good olive oil and sprinkle with extra cheese and black pepper.

**Why this works**
Soaking brown rice softens the bran, reducing cooking time and yielding a creamy texture similar to arborio. Slowly adding hot stock and stirring agitates starch into the liquid, creating the classic risotto creaminess without cream. High-heat searing ensures scallops develop a Maillard crust while staying juicy. Compliance refinement: verjus provides wine-like acidity without alcohol while preserving risotto balance.

**Plating / Pairing**
Present risotto in a shallow bowl with scallops neatly perched. Garnish with micro-herbs. Pair with a minerally Italian white wine (Verdicchio) or sparkling water with lemon zest.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Changed default deglazing liquid from wine to verjus, keeping wine optional.

---

## Chifa Lomo Saltado Quinoa Bowl (Peruvian × Chinese)
**Servings: 4 | Active time: 35 min | Total time: 50 min**

**Mise en place**
- Station A - Quinoa: Rinse 240 g tricolour quinoa; place in a pot with 480 ml water and a pinch of salt; bring to boil then simmer 15 min until fluffy.
- Station B - Beef & vegetables: Slice 500 g beef sirloin into strips; marinate with 30 ml soy sauce, 5 ml sesame oil and 10 ml rice vinegar. Slice 1 red onion into petals, 2 tomatoes into wedges, julienne 1 aji amarillo, chop 20 g cilantro.
- Station C - Sauce: Mix 30 ml oyster sauce, 15 ml soy sauce, 15 ml Pisco (optional) or rice vinegar, 10 ml fish sauce and 5 g sugar (or 5 ml honey).
- Station D - Fried egg & fries: Cut 2 medium sweet potatoes into batons; toss with 15 ml olive oil, salt and smoked paprika. Preheat oven to 220 °C.

**Ingredients**
- 240 g quinoa, 500 g beef sirloin, 2 sweet potatoes, 1 red onion, 2 tomatoes, 1 aji amarillo chile, 20 g cilantro, 2 cloves garlic minced, 20 ml additive-free oyster sauce or mushroom oyster sauce, 30 ml low-sodium soy sauce, 20 ml vinegar or Pisco, 10 ml fish sauce, 5 ml sesame oil, 4 eggs, olive oil, salt, black pepper.

**Method**
1. Bake sweet-potato fries: Toss batons with olive oil, smoked paprika and salt. Spread on a parchment-lined tray; bake at 220 °C for 25 min, flipping once, until crisp.
2. Cook quinoa: Simmer rinsed quinoa with water until tender and fluffy; set aside and keep warm.
3. Stir-fry beef: Heat a wok or heavy skillet until smoking. Add 1 tbsp high-smoke-point oil. Sear marinated lean beef strips in batches until browned; set aside.
4. Aromatics: In the same wok, add a bit more oil if needed; stir-fry garlic, onion petals and aji amarillo for 2 min until fragrant. Return beef; add tomatoes and low-sodium sauce mixture. Stir-fry 1 min to glaze; the tomatoes should soften but retain shape.
5. Fry eggs: Fry 4 eggs sunny-side up in a non-stick pan until whites are crisp and yolks runny.
6. Assemble bowls: Divide quinoa among bowls. Top with lomo saltado mixture, sweet-potato fries and a fried egg. Sprinkle with chopped cilantro.

**Why this works**
High-heat wok cooking caramelises beef quickly, preserving tenderness and producing smoky wok hei. Tomatoes release juice that, combined with oyster sauce and soy, creates a glossy sauce. Sweet-potato fries baked rather than fried maintain crispness while reducing processed fat and providing beta-carotene. Compliance refinement: the bowl keeps wok-char flavor but uses lean beef, low-sodium soy, a smaller amount of additive-free oyster-style sauce, and baked sweet-potato fries.

**Plating / Pairing**
Serve in deep bowls with the egg yolk perched like a jewel. Pair with a citrusy sour beer or chilled kombucha infused with passion fruit.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Reduced soy/oyster sauce sodium.
- Specified lean beef and additive-free or mushroom oyster sauce.
- Kept sweetener to 4 g total.

---

## Chocolate-Cinnamon Churro Sundae with Dark Chocolate Sorbet (Mexican)
**Servings: 4 | Active time: 40 min | Total time: 2 h (includes chilling)**

**Mise en place**
- **Station A - Sorbet:** Blend 500 ml water, 80 g ripe banana purée, 60 g date paste, 55 g unsweetened cocoa powder, 100 g 85% dark chocolate, salt, and cinnamon; chill base 1 h.
- **Station B - Churros:** Prepare whole-wheat pâte à choux with 125 ml water, 40 g butter, 5 g salt, 75 g whole-wheat flour, and 2 eggs. Set up piping bag with a star tip.
- **Station C - Coating & sauce:** Mix 16 g raw sugar, cinnamon, and orange zest. Warm 20 g honey with butter and espresso; use mezcal only as an optional adult variation.

**Ingredients**
- **Sorbet:** 500 ml water, 80 g ripe banana purée, 60 g date paste, 55 g unsweetened cocoa powder, 100 g 85% dark chocolate, pinch salt, 2 g cinnamon.
- **Churros:** 125 ml water, 40 g unsalted butter, 5 g salt, 75 g whole-wheat flour, 2 eggs, 20 ml high-oleic sunflower oil for brushing or 500 ml high-oleic sunflower oil for occasional shallow-frying.
- **Coating:** 16 g raw sugar, 6 g cinnamon, 2 g orange zest.
- **Caramel:** 20 g honey, 45 g butter, 20 ml espresso or mezcal only as optional adult variation, smoked sea salt.
- **Garnish:** Toasted almonds, orange zest.

**Method**
1. **Make sorbet:** Blend water, banana purée, date paste, cocoa, chocolate, salt and cinnamon until smooth; chill 1 h, churn, and freeze until scoopable.
2. **Prepare churro dough:** Bring water, butter and salt to a boil. Off heat, stir in flour; return to low heat for 1 min to dry. Beat in eggs one at a time until glossy.
3. **Bake or shallow-fry churros:** Pipe 10 cm lengths. For default baking, brush lightly with oil and bake at 220 °C for 12-15 min until crisp; for occasional restaurant-style texture, shallow-fry at 180 °C until golden. Roll lightly in the 16 g cinnamon sugar mixture.
4. **Make espresso honey butter:** Warm honey and butter until glossy; whisk in espresso and smoked salt. Use mezcal only as optional adult variation.
5. **Assemble:** Place two mini churros in each bowl, add dark chocolate sorbet, drizzle with espresso honey butter, and garnish with toasted almonds and orange zest.

**Why this works**
Whole-wheat pâte à choux still puffs from steam while adding fiber and nutty flavor. Banana/date-sweetened sorbet creates perceived sweetness without added sugar in the base; the only added sugar is the 16 g coating plus 20 g honey sauce, keeping the dessert at about 9 g added sugar per serving. Brushing and baking is the default compliance path; shallow-frying remains an occasional technique option.

**Plating / Pairing**
Serve immediately for hot/cold contrast. Pair with cinnamon cold brew, espresso, or sparkling water with orange peel; reserve fortified wine or mezcal for optional adult service only.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Reduced added sugar from >50 g/serving to about 9 g/serving.
- Changed default cooking method to baked/air-fried with shallow-fry as occasional.
- Replaced mezcal default with espresso.

---

## Crispy Fish Tacos with Mango Slaw & Black Bean Salad (Mexican)
**Servings: 4 | Active time: 45 min | Total time: 1 h**

**Mise en place**
- Station A - Fish: Cut 600 g firm white fish (e.g., cod or corvina) into 12 strips. Prepare batter: whisk 150 g whole-wheat flour, 50 g cornstarch, 5 g baking powder, 5 g paprika and 5 g salt; gradually whisk in 300 ml chilled sparkling water.
- Station B - Slaw: Julienne 1 ripe mango, ½ red cabbage (200 g), 1 carrot and 1 red onion; toss with 30 ml lime juice, 15 ml olive oil, 5 ml honey and 2 g salt. Set aside to marinate.
- Station C - Black bean salad: Rinse 400 g cooked black beans, halve 200 g cherry tomatoes, dice 1 avocado, chop 20 g cilantro. Mix with 30 ml lime juice and 15 ml olive oil.
- Station D - Tortillas & crema: Warm 12 small corn tortillas. For chipotle crema, blend 200 g Greek yoghurt with 1 chipotle in adobo, 5 ml lime juice and a pinch of salt.

**Ingredients**
- 600 g cod or corvina, 150 g whole-wheat flour, 50 g cornstarch, 5 g baking powder, 5 g paprika, 5 g salt, 300 ml sparkling water, sunflower oil for frying.
- Mango slaw: 1 mango, ½ red cabbage, 1 carrot, 1 red onion, 30 ml lime juice, 15 ml olive oil, 5 ml honey, pinch salt.
- Black bean salad: 400 g cooked black beans, 200 g cherry tomatoes, 1 avocado, 20 g cilantro, 30 ml lime juice, 15 ml olive oil.
- Chipotle crema & tortillas: 200 g Greek yoghurt, 1 chipotle chile in adobo, 5 ml lime juice, salt; 12 corn tortillas.

**Method**
1. Make slaw & salad: Combine slaw vegetables and dressing; let stand to soften. Toss black bean salad ingredients together; season to taste.
2. Prepare batter: In a bowl, whisk flour, cornstarch, baking powder, paprika and salt. Add sparkling water gradually to form a smooth, airy batter. Keep cold.
3. Fry fish: Heat oil to 180 °C in a deep pan. Dip fish strips into batter, allowing excess to drip off, and fry in batches until puffed and golden (≈3 min). Transfer to a wire rack to drain; sprinkle with sea salt.
4. Warm tortillas: Heat tortillas briefly on a dry skillet; keep warm in a cloth.
5. Assemble tacos: Spread a spoonful of chipotle crema on each tortilla. Lay a piece of fried fish on top. Pile on mango slaw and garnish with cilantro leaves. Serve with black bean salad on the side.

**Why this works**
Using sparkling water and cornstarch in the batter traps bubbles and reduces gluten formation, resulting in an ultracrisp coating that stays light. Whole-wheat flour adds nuttiness without compromising texture. The acidic mango slaw cuts through fried richness, while chipotle crema provides smoky heat and probiotic benefits from yoghurt.

**Plating / Pairing**
Serve tacos family-style on a platter with extra lime wedges. Pair with a light lager or a chilled cucumber-lime agua fresca.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Added DGA compliance metadata and sodium/additive-aware execution notes where relevant.

---

## Dark Chocolate & Chicha Morada Mousse with Roasted Pineapple (Peruvian)
**Servings: 4 | Active time: 30 min | Total time: 2 h (includes chilling)**

**Mise en place**
- Station A - Chicha reduction: Simmer 500 ml purple corn chicha (made by boiling purple corn, pineapple rind, cinnamon and clove) until reduced to 150 ml; strain.
- Station B - Mousse: Separate 4 eggs; chop 150 g 85% dark chocolate; measure 24 g honey, 200 ml heavy cream.
- Station C - Pineapple: Peel and core ½ pineapple (300 g); cut into 2 cm cubes. Toss with 5 ml lime juice and roast until naturally caramelised.

**Ingredients**
- 150 g dark chocolate (70 %), 4 eggs separated, 24 g honey, 150 ml chicha morada reduction, 200 ml heavy cream, pinch of salt.
- Roasted pineapple: 300 g pineapple cubes, 5 ml lime juice.

**Method**
1. Make mousse base: Melt dark chocolate in a heatproof bowl over a bain-marie. Remove from heat; stir in honey and chicha reduction until smooth. Allow to cool slightly. Whisk in egg yolks one at a time.
2. Whip egg whites: In a clean bowl, whip egg whites with a pinch of salt to soft peaks. In a separate bowl, whip cream to soft peaks.
3. Fold: Fold egg whites into the chocolate base in two additions, keeping as much air as possible. Gently fold in whipped cream. Divide among glasses and chill for at least 90 min.
4. Roast pineapple: Spread pineapple on a lined baking sheet; sprinkle with lime juice only. Roast at 200 °C for 15 min until caramelised. Cool.
5. Serve: Top each mousse with warm roasted pineapple and drizzle of extra chicha reduction.

**Why this works**
The combination of whipped egg whites and cream aerates the chocolate base without the need for gelatin. Reducing chicha morada intensifies its fruity, spiced flavours while providing natural sweetness and anthocyanins. Roasting pineapple caramelises natural sugars, creating contrast in texture and temperature. Compliance refinement: using 85% chocolate, chicha reduction, and pineapple sweetness keeps added sugar to roughly 6 g per serving.

**Plating / Pairing**
Serve in chilled glass cups to showcase layers. Garnish with a sprig of mint. Pair with a demi-sec sparkling wine or a chilled hibiscus infusion with orange peel.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Reduced honey to 24 g total and removed coconut sugar.
- Specified 85% dark chocolate.

---

## Deconstructed Acevichado Cod with Quinoa Crust & Aji Emulsion (Nikkei)
**Servings: 4 | Active time: 1 h | Total time: 1 h 30 min**

**Mise en place**
- Station A - Fish & crust: Portion 4 black cod fillets (150 g each); season with salt and refrigerate. Cook 100 g quinoa in 200 ml water until just tender; drain and dry on a towel. Crush 20 g nori sheets into flakes.
- Station B - Pickles & garnish: Thinly slice 1 red onion and 1 cucumber; marinate in 30 ml rice vinegar, 5 ml honey and pinch salt. Dice 1 avocado; keep with lime juice.
- Station C - Emulsion: Blend 2 egg yolks with 50 ml lime juice, 30 ml fish stock and 50 g aji amarillo paste; slowly emulsify 120 ml olive oil.

**Ingredients**
- 4 black cod fillets (≈150 g each), 100 g quinoa, 20 g nori, 1 egg white, 30 ml soy sauce.
- Pickled onion & cucumber: 1 red onion, 1 cucumber, 30 ml rice vinegar, 5 ml honey, pinch salt.
- Aji emulsion: 2 egg yolks, 50 ml lime juice, 30 ml fish stock, 50 g aji amarillo paste, 120 ml olive oil, salt.
- Avocado puree: 1 ripe avocado, 10 ml lime juice, salt.
- Garnish: micro-coriander, sesame seeds.

**Method**
1. Make quinoa crust: Spread cooked quinoa on a baking sheet and dehydrate in a 100 °C oven for 30 min until dry. Mix with crumbled nori and a pinch of salt. Brush cod fillets with beaten egg white and press onto quinoa mixture to form a crust.
2. Sear fish: Heat a non-stick pan with 2 tbsp neutral oil. Place cod crust-side down and cook on medium heat until crust is golden and crisp (≈4 min). Transfer to a baking tray and finish in a 180 °C oven for 6-8 min until fish flakes easily.
3. Make emulsion: In a blender, combine egg yolks, lime juice, fish stock and aji amarillo paste. With motor running, slowly drizzle in olive oil to create a thick emulsion. Season with salt.
4. Assemble: Spread a swipe of avocado purée on each plate. Arrange cod fillet atop, crust side up. Scatter pickled onion and cucumber around, along with avocado cubes. Drizzle with aji emulsion and soy sauce drops. Sprinkle sesame seeds and micro-corinander.

**Why this works**
Dehydrating quinoa yields a crispy coating that echoes the crunch of tempura while providing whole-grain fibre. Cod’s high oil content prevents it from drying out during searing and roasting. Emulsifying lime juice and aji amarillo with egg yolks produces a tangy, spicy sauce reminiscent of acevichado without the raw fish.

**Plating / Pairing**
Plate with negative space for a refined look. Pair with a dry Riesling or a yuzu-sparkling water.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Added DGA compliance metadata and sodium/additive-aware execution notes where relevant.

---

## Elote-Style Corn Ribs (Mexican)
**Servings: 4 | Active time: 20 min | Total time: 40 min**

**Mise en place**
- Station A - Corn: Quarter 4 ears of corn lengthwise to form “ribs.”
- Station B - Seasoning: Mix 30 ml olive oil, 10 g smoked paprika, 5 g cumin, 5 g chili powder, 5 g garlic powder and 5 g salt.
- Station C - Sauce & toppings: Blend 130 g Greek yoghurt with 20 g homemade olive-oil aioli, 1 chipotle chile, 10 ml lime juice and 20 g cilantro; crumble 50 g cotija cheese; chop extra cilantro.

**Ingredients**
- 4 ears corn, 30 ml olive oil, 10 g smoked paprika, 5 g cumin, 5 g chili powder, 5 g garlic powder, 5 g salt.
- Sauce: 130 g Greek yoghurt, 20 g homemade olive-oil aioli, 1 chipotle chile, 10 ml lime juice, 20 g cilantro.
- Garnish: 50 g cotija cheese, extra cilantro, lime wedges.

**Method**
1. Season corn: Toss corn ribs with spice oil mixture until well coated.
2. Roast or grill: Arrange on a baking sheet and roast at 220 °C for 20 min, turning once, until kernels char and curl slightly. Alternatively, grill over medium-high heat.
3. Prepare sauce: Blend yoghurt, homemade aioli, chipotle, lime juice and cilantro until smooth; season to taste.
4. Serve: Drizzle corn ribs with sauce, sprinkle with cotija and cilantro, and serve with lime wedges.

**Why this works**
Cutting corn into ribs increases surface area for caramelisation and creates a fun, handheld snack. Roasting at high heat develops charred, sweet notes without deep frying. The yoghurt-mayo sauce provides creaminess while chipotle adds smoky heat. Compliance refinement: homemade aioli and unsweetened yoghurt avoid commercial emulsified condiment additives while maintaining creamy elote richness.

**Plating / Pairing**
Serve on a board lined with parchment. Pair with a light lager or agua de tamarindo.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Replaced commercial emulsified condiment with yoghurt plus homemade olive-oil aioli.

---

## Grilled Chicken Parmigiana with Aji Verde & Quinoa Salad (Italian × Peruvian)
**Servings: 4 | Active time: 45 min | Total time: 1 h 15 min**

**Mise en place**
- Station A - Chicken: Pound 4 free-range chicken breasts (150 g each) to 1 cm thickness. Prepare breading station: 100 g almond meal mixed with 50 g whole-wheat breadcrumbs and 10 g grated Parmesan; beat 2 eggs; measure 50 g flour seasoned with salt and pepper.
- Station B - Sauce: Simmer 500 g crushed San Marzano tomatoes with 2 minced garlic cloves, 5 ml olive oil, 5 g dried oregano, and 1 small grated carrot or 2 g honey only if tomatoes taste sharp until thickened.
- Station C - Aji verde: Blend 50 g cilantro, 1 jalapeño, 1 garlic clove, 30 ml lime juice, 50 g Greek yoghurt, 30 ml olive oil and 5 g salt until smooth.
- Station D - Quinoa salad: Cook 200 g quinoa in 400 ml water; dice 1 cucumber, 1 bell pepper, 1 avocado; chop 20 g mint.

**Ingredients**
- 4 chicken breasts (600 g total), 50 g flour, 2 eggs, 100 g almond meal, 50 g whole-wheat breadcrumbs, 10 g Parmesan, 500 g crushed tomatoes, garlic, oregano, sugar, 150 g fresh mozzarella, olive oil.
- Aji verde: 50 g cilantro, 1 jalapeño, 1 garlic clove, 30 ml lime juice, 50 g Greek yoghurt, 30 ml olive oil, salt.
- Quinoa salad: 200 g quinoa, 1 cucumber, 1 bell pepper, 1 avocado, 20 g mint, 30 ml lemon juice, 15 ml olive oil.

**Method**
1. Prepare sauce: Simmer tomatoes with garlic, oregano and grated carrot for 20 min until rich and naturally sweet; season with salt and pepper.
2. Bread chicken: Dredge pounded chicken in flour, dip in egg, then coat with almond-breadcrumb mixture. Drizzle with olive oil.
3. Bake or air-fry: Arrange breaded chicken on a rack and bake at 200 °C for 15 min or air-fry until crisp and cooked through. Top each cutlet with spoonful of tomato sauce and slice of mozzarella; return to oven for 5 min to melt.
4. Make aji verde: Blend all sauce ingredients until smooth and vibrant green.
5. Quinoa salad: Fluff cooked quinoa and toss with diced cucumber, bell pepper, avocado, mint, lemon juice and olive oil; season.
6. Serve: Plate chicken parmigiana on quinoa salad; drizzle with aji verde.

**Why this works**
Using almond meal and whole-wheat breadcrumbs reduces refined grains and increases healthy fats. Baking rather than shallow-frying delivers a crisp crust with less oil. Aji verde provides a tangy herbal counterpoint to the rich tomato and melted cheese. Compliance refinement: grated carrot replaces most added sugar in the tomato sauce while preserving sweetness and body.

**Plating / Pairing**
Serve on wide plates with salad spread underneath. Pair with a medium-bodied red like Sangiovese or a lime-mint sparkling water.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Replaced added sugar in tomato sauce with grated carrot, with 2 g honey only if needed.

---

## Korean Bulgogi Breakfast Burrito (Korean × Mexican)
**Servings: 4 | Active time: 35 min | Total time: 50 min**

**Mise en place**
- Station A - Bulgogi: Thinly slice 400 g beef sirloin and marinate with 25 ml low-sodium soy sauce, 6 g honey or 40 g grated pear, 10 ml sesame oil, 2 g grated ginger, 2 cloves minced garlic, 5 ml rice vinegar and 5 ml gochujang. Rest 20 min.
- Station B - Rice & eggs: Cook 200 g brown rice; scramble 4 eggs with 30 ml milk and a pinch of salt.
- Station C - Pickles & fillings: Thinly slice 1 cucumber, toss with 10 ml rice vinegar and pinch salt; prepare 100 g kimchi; chop 10 g scallions; warm 4 large whole-wheat tortillas.

**Ingredients**
- 400 g beef sirloin, 25 ml low-sodium soy sauce, 6 g honey or grated pear, 10 ml sesame oil, ginger, garlic, 5 ml rice vinegar, 5 ml gochujang.
- 200 g brown rice, 4 eggs, 30 ml milk, 100 g kimchi, 1 cucumber, 10 ml rice vinegar, 10 g scallions, 4 whole-wheat tortillas, sesame seeds.

**Method**
1. Cook bulgogi: Heat a skillet until hot. Sear marinated beef in batches for 2 min until caramelised; the honey/pear in the marinade will help develop a glaze. Set aside.
2. Scramble eggs: In the same pan, add a knob of butter and cook beaten eggs gently until just set; season.
3. Assemble burritos: Lay tortillas on a board. Divide rice down the centre of each, top with bulgogi, scrambled eggs, kimchi, cucumber pickles and scallions. Sprinkle with sesame seeds and extra gochujang if desired.
4. Roll & sear: Fold sides in and roll tightly. Sear seam-side down in a hot dry pan for 1 min to seal.

**Why this works**
Marinating thinly sliced beef with soy, sugar and gochujang tenderises the meat and builds caramelisation. Whole-wheat tortillas and brown rice provide fibre. Incorporating kimchi and pickled cucumber adds fermentation acids to balance the rich beef and eggs. Compliance refinement: pear or a small amount of honey supports caramelisation while keeping added sugar low; low-sodium soy lowers salt load.

**Plating / Pairing**
Serve halved burritos with a side of sliced avocado. Pair with a lightly sweet cold brew tea or a session ale.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Reduced added sweetener to 6 g total or replaced with grated pear.
- Changed soy sauce to low-sodium.

---

## Lucuma Tiramisu (Italian × Peruvian)
**Servings: 4 | Active time: 45 min | Total time: 4 h (includes chilling)**

**Mise en place**
- **Station A - Ladyfingers:** Prepare a batter with 3 eggs (separated), 20 g raw sugar, 75 g whole-wheat pastry flour and 5 g baking powder. Pipe onto parchment and bake at 180 °C for 10 min until just set.
- **Station B - Lucuma cream:** Whisk 3 egg yolks with 20 g honey over a bain-marie until pale. Beat in 250 g mascarpone and 150 g lucuma purée until smooth.
- **Station C - Espresso soak:** Brew 200 ml strong espresso; stir in 5 ml almond extract. Marsala is optional for adult service only.

**Ingredients**
- **Ladyfingers:** 3 eggs, 20 g raw sugar, 75 g whole-wheat pastry flour, 5 g baking powder.
- **Lucuma cream:** 3 egg yolks, 20 g honey, 250 g mascarpone, 150 g lucuma purée, pinch salt.
- **Espresso soak:** 200 ml espresso, 5 ml almond extract or 20 ml Marsala only as optional adult variation.
- **Topping:** 30 g unsweetened dark cocoa powder, 20 g shaved 85% dark chocolate.

**Method**
1. Bake ladyfingers: Beat egg whites to stiff peaks; gradually add the 20 g sugar. In another bowl, beat yolks with no additional sugar until pale. Fold in flour and baking powder, then fold in meringue. Pipe into fingers and bake until lightly golden. Cool.
2. Make lucuma cream: Cook yolks and 20 g honey over a gentle bain-marie until thick ribbons form. Cool slightly, then fold in mascarpone and lucuma purée until smooth.
3. Assemble tiramisu: Dip ladyfingers briefly into cooled espresso soak and arrange a single layer in a glass dish. Spread half the lucuma cream over. Repeat with another layer. Smooth the top and chill at least 3 h.
4. Finish: Dust with cocoa powder and garnish with shaved dark chocolate just before serving.

**Why this works**
Whole-wheat ladyfingers stay light because whipped egg whites provide structure and lift, while lucuma contributes caramel-like natural sweetness. The revised formula limits added sugar to 40 g total, or 10 g per serving, and keeps Marsala optional rather than default.

**Plating / Pairing**
Cut into squares and serve with espresso. Pair with an almond-milk cortado or unsweetened espresso; Vin Santo is an optional adult pairing only.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Reduced total added sugar to 40 g for 4 servings.
- Made Marsala optional and almond extract the default.
- Specified unsweetened cocoa and 85% chocolate.

---

## Mapo Tofu with Quinoa & Sichuan Peanuts (Chinese × Peruvian)
**Servings: 4 | Active time: 30 min | Total time: 45 min**

**Mise en place**
- Station A - Quinoa: Rinse 240 g quinoa; cook in 480 ml water until fluffy; keep warm.
- Station B - Tofu & turkey: Drain and cube 400 g firm tofu; mince 250 g turkey thigh. Chop 4 garlic cloves, 20 g ginger and 2 scallions; measure 30 g doubanjiang (fermented broad bean paste), 5 ml soy sauce and 5 ml rice wine.
- Station C - Sichuan pepper oil: Toast 5 g Sichuan peppercorns and 5 g chili flakes in 30 ml oil until fragrant; strain.

**Ingredients**
- 400 g firm tofu, 250 g ground turkey, 240 g quinoa, 4 garlic cloves, 20 g ginger, 2 scallions, 30 g doubanjiang, 15 ml soy sauce, 5 ml Shaoxing wine or rice wine, 200 ml chicken stock, 5 g cornstarch mixed with 30 ml water, 30 ml Sichuan pepper-chili oil, 30 g roasted peanuts, 10 ml sesame oil.

**Method**
1. Sauté aromatics: In a wok, heat 15 ml oil; add garlic, ginger and whites of scallions; stir-fry until fragrant. Add minced turkey; cook until browned.
2. Build sauce: Stir in doubanjiang and soy sauce; fry 1 min to release oils. Pour in stock and Shaoxing wine; bring to a simmer.
3. Add tofu: Gently slide in tofu cubes; simmer 5 min to absorb flavours.
4. Thicken: Stir cornstarch slurry into the sauce and simmer until glossy. Drizzle with Sichuan pepper oil and sesame oil.
5. Serve: Spoon mapo tofu over quinoa. Sprinkle with chopped peanuts and green parts of scallions.

**Why this works**
Combining tofu with lean turkey increases protein diversity. Doubanjiang provides deep umami and heat, while Sichuan pepper oil contributes numbing spice. Quinoa soaks up the spicy sauce and offers a whole-grain alternative to rice.

**Plating / Pairing**
Serve in shallow bowls with a cool cucumber salad. Pair with off-dry Gewürztraminer or jasmine tea.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Added DGA compliance metadata and sodium/additive-aware execution notes where relevant.

---

## Miso-Glazed Salmon Bowl with Brown Rice & Sesame Kale (Japanese)
**Servings: 4 | Active time: 35 min | Total time: 50 min**

**Mise en place**
- Station A - Rice: Cook 300 g brown rice in 600 ml water until tender; keep warm.
- Station B - Salmon: Mix glaze: 35 g white miso, 12 g honey, 10 ml rice vinegar, 10 ml low-sodium soy sauce. Portion 4 salmon fillets (180 g each) and brush with glaze; marinate 15 min.
- Station C - Kale & toppings: Destem 200 g kale; slice into ribbons. Julienne 1 cucumber, slice 1 avocado, cook 200 g edamame. Toast 20 g sesame seeds.

**Ingredients**
- 4 salmon fillets (≈720 g), 35 g white miso, 12 g honey, 10 ml rice vinegar, 10 ml low-sodium soy sauce, 300 g brown rice, 200 g kale, 1 cucumber, 1 avocado, 200 g edamame, 20 g sesame seeds, 30 ml rice vinegar, 5 ml sesame oil.

**Method**
1. Cook rice: Simmer brown rice until fluffy; season with a pinch of salt and 15 ml rice vinegar.
2. Roast salmon: Preheat oven to 200 °C. Place glazed salmon on a parchment-lined tray; bake 10-12 min until just opaque. Broil for 1 min to caramelise the glaze.
3. Sauté kale: Heat 5 ml sesame oil in a pan; sauté kale until just wilted; season with salt.
4. Assemble bowls: Divide rice among bowls. Top with roasted salmon, sautéed kale, cucumber, avocado slices and edamame. Sprinkle with sesame seeds. Drizzle with remaining glaze diluted with 20 ml water as a sauce.

**Why this works**
Miso’s glutamates create deep umami; honey and mirin help caramelise the glaze. Brown rice offers chewiness and fibre. Quick sautéing retains kale’s nutrients, while edamame adds plant protein. Compliance refinement: rice vinegar replaces mirin and the honey amount is reduced while still supporting glaze browning.

**Plating / Pairing**
Serve with chopsticks. Pair with a chilled sake or green tea with jasmine.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Reduced honey and replaced mirin with rice vinegar.
- Changed soy sauce to low-sodium.

---

## Nikkei Quinoa Acevichado Salad (Peruvian × Japanese)
**Servings: 4 | Active time: 25 min | Total time: 40 min**

**Mise en place**
- Station A - Quinoa: Rinse 200 g red quinoa and cook in 400 ml water until fluffy.
- Station B - Fish & dressing: Slice 200 g sushi-grade salmon or tuna into thin sashimi strips; juice 4 limes (80 ml); blend 30 ml aji amarillo paste, 5 g grated ginger, 1 garlic clove and 5 g salt.
- Station C - Vegetables: Julienne 1 avocado, 1 cucumber and ½ red onion; chop 50 g fresh cilantro.

**Ingredients**
- 200 g red quinoa, 200 g sashimi-grade salmon or tuna, 80 ml lime juice, 30 ml aji amarillo paste, 8 ml low-sodium soy sauce, 5 g grated ginger, 1 garlic clove, 1 avocado, 1 cucumber, ½ red onion, 50 g cilantro, 30 g toasted corn nuts or cancha serrana, 10 ml olive oil, salt.

**Method**
1. Prepare quinoa: Cook quinoa until tender; spread on a tray to cool.
2. Make dressing: Blend lime juice, aji amarillo, ginger, garlic, soy sauce and olive oil until emulsified. Season to taste.
3. Assemble salad: In a bowl, toss cooled quinoa with avocado, cucumber, red onion and cilantro. Add fish slices and gently mix with dressing. Top with toasted corn nuts for crunch.

**Why this works**
Using quinoa instead of rice increases protein and fibre. The acidic, spicy dressing “cooks” the sashimi lightly, akin to ceviche, while soy and aji amarillo provide Nikkei flavour. Cancha adds a nutty crunch reminiscent of tempura bits.

**Plating / Pairing**
Serve in shallow bowls or mould into ring forms. Pair with a citrus-driven Sauvignon Blanc or a chilled pisco sour made with egg white and minimal sugar.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Changed soy sauce to low-sodium and kept added sweetener minimal.

---

## Parmesan-Reggiano Crisps with Aji Amarillo Aioli (Italian × Peruvian)
**Servings: 4 (snack) | Active time: 15 min | Total time: 30 min**

**Mise en place**
- Station A - Crisps: Finely grate 100 g Parmigiano-Reggiano and 50 g aged cheddar; line a baking tray with silicone.
- Station B - Aioli: Separate 1 egg yolk; measure 5 ml lemon juice, 5 ml white vinegar, 5 g Dijon mustard, 50 g aji amarillo paste and 100 ml olive oil. Mince 1 garlic clove.

**Ingredients**
- Crisps: 100 g Parmigiano-Reggiano, 50 g aged cheddar, 2 g smoked paprika.
- Aji aioli: 1 egg yolk, 5 ml lemon juice, 5 ml white vinegar, 5 g Dijon mustard, 50 g aji amarillo paste, 100 ml olive oil, 1 minced garlic clove, salt.

**Method**
1. Bake crisps: Preheat oven to 200 °C. On a silicone-lined sheet, spoon 15 g mounds of cheese mixture, leaving space to spread. Flatten gently and sprinkle with smoked paprika. Bake for 6-8 min until golden and lace-like. Cool completely to crisp.
2. Make aioli: In a bowl, whisk egg yolk, lemon juice, vinegar and mustard. Slowly drizzle in olive oil while whisking until thick and emulsified. Stir in aji amarillo paste and minced garlic; season.
3. Serve: Plate crisps with a bowl of aioli for dipping.

**Why this works**
Parmesan’s low moisture content melts into lacy crisps that firm up upon cooling. Adding cheddar provides additional sharpness. Making aioli from scratch allows control over oil and eliminates additives; aji amarillo brings floral heat and golden hue.

**Plating / Pairing**
Serve as a pre-meal snack with sparkling wine or a chilled lager.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Added DGA compliance metadata and sodium/additive-aware execution notes where relevant.

---

## Roasted Plantain Chips with Rocoto Dip (Peruvian)
**Servings: 4 | Active time: 15 min | Total time: 40 min**

**Mise en place**
- Station A - Plantains: Peel 3 green plantains and slice thinly on a mandolin; soak in salted water for 10 min.
- Station B - Seasoning: Mix 20 ml olive oil with 5 g cumin, 5 g smoked paprika and 5 g salt.
- Station C - Rocoto dip: Blend 1 roasted red pepper, 1 fresh rocoto chile (seeded), 1 garlic clove, 50 g Greek yoghurt, 20 ml olive oil, 10 ml lime juice and salt.

**Ingredients**
- 3 green plantains, 20 ml olive oil, 5 g cumin, 5 g smoked paprika, 5 g salt.
- Dip: 1 roasted red pepper, 1 rocoto chile, 1 garlic clove, 50 g Greek yoghurt, 20 ml olive oil, 10 ml lime juice, salt.

**Method**
1. Prepare chips: Drain plantain slices and pat dry. Toss with spiced oil. Arrange in a single layer on a lined baking sheet. Roast at 200 °C for 20-25 min, flipping halfway, until crisp and golden.
2. Make dip: Blend roasted pepper, rocoto, garlic, yoghurt, olive oil and lime juice until smooth. Season with salt.
3. Serve: Serve warm plantain chips with rocoto dip.

**Why this works**
Soaking plantains removes excess starch, promoting crispness. Roasting with a thin coating of oil yields chips with a satisfying crunch without deep frying. Rocoto provides fruity heat balanced by creamy yoghurt.

**Plating / Pairing**
Serve in a parchment-lined basket with dip on the side. Pair with a pilsner or passion fruit iced tea.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Added DGA compliance metadata and sodium/additive-aware execution notes where relevant.

---

## Slow-Roasted Salmon & Avocado Whole-Grain Bagel (American × Peruvian)
**Servings: 4 | Active time: 30 min | Total time: 3 h (includes proofing)**

**Mise en place**
- **Station A - Bagels:** Mix dough with 250 g whole-wheat flour, 250 g bread flour, 7 g yeast, 6 g barley malt syrup, 300 ml warm water, 10 g salt. Knead and proof 1 h; shape into rings and proof again. Prepare water bath with 20 g baking soda.
- **Station B - Salmon:** Season 400 g salmon fillet with 8 g salt, orange zest, black pepper, dill, and 10 ml olive oil. Roast at 95 °C until just opaque and silky, then chill and flake or slice.
- **Station C - Toppings:** Slice 2 avocados thinly, pickle 1 red onion in 30 ml cider vinegar with 4 g honey, chop fresh dill, mix 200 g cream cheese with 10 g chopped chives.

**Ingredients**
- **Bagels:** 250 g whole-wheat flour, 250 g bread flour, 7 g yeast, 6 g malt syrup, 300 ml water, 10 g salt, 20 g baking soda for boiling.
- **Slow-roasted salmon:** 400 g salmon fillet, 8 g salt, zest of 1 orange, black pepper, fresh dill, 10 ml olive oil.
- **Toppings:** 2 avocados, 1 red onion, 30 ml cider vinegar, 4 g honey, 200 g cream cheese, 10 g chives, fresh dill, lemon wedges.

**Method**
1. **Make bagels:** After second proof, boil bagels in alkaline water for 30 s per side; sprinkle with sesame seeds if desired; bake at 220 °C for 15 min until golden.
2. **Roast salmon:** Season salmon with salt, orange zest, pepper, dill, and olive oil. Roast at 95 °C until the thickest part reaches 50-52 °C, about 20-25 min. Chill slightly, then flake or slice.
3. **Assemble:** Split bagels and spread with chive cream cheese. Layer with avocado slices, slow-roasted salmon and lightly pickled red onions. Sprinkle with dill and serve with lemon wedges.

**Why this works**
Boiling bagels in an alkaline bath gelatinises exterior starch for the signature shiny chew, while whole-wheat flour adds fiber. Slow-roasting fresh salmon avoids a salt-and-sweet cure, keeps the texture buttery, and preserves the seafood-forward flavor-map cue with less sodium than commercial smoked salmon.

**Plating / Pairing**
Serve open-faced or closed with dressed greens. Pair with citrus-infused sparkling water or a crisp rosé as an optional adult pairing.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Replaced commercially cured salmon with fresh slow-roasted salmon.
- Reduced malt syrup to 6 g and pickle sweetener to 4 g.

---

## Sous-Vide Short Ribs with Purple Potato Purée & Sautéed Greens (American × Peruvian)
**Servings: 4 | Active time: 1 h | Total time: 24 h (includes sous-vide)**

**Mise en place**
- Station A - Ribs: Season 1.2 kg beef short ribs with 20 g salt, 10 g black pepper, 4 g brown sugar or date paste and 20 g miso paste. Vacuum-seal with 2 crushed garlic cloves and 2 sprigs thyme. Preheat sous-vide bath to 68 °C.
- Station B - Potatoes: Peel and cube 600 g purple potatoes; simmer in salted water until tender. Warm 100 ml whole milk and 50 g butter.
- Station C - Greens: Wash and chiffonade 300 g Swiss chard or kale. Slice 2 garlic cloves. Toast 30 g chopped pecans for garnish.

**Ingredients**
- 1.2 kg beef short ribs, 20 g salt, 10 g pepper, 4 g brown sugar or date paste, 20 g miso paste, 2 garlic cloves, 2 thyme sprigs.
- Purple potato purée: 600 g purple potatoes, 100 ml whole milk, 50 g butter, 20 g Parmesan, salt.
- Sautéed greens: 300 g Swiss chard or kale, 2 garlic cloves, 15 ml olive oil, 30 g pecans.
- Glaze: 40 ml unsweetened pomegranate reduction, 30 ml red wine, 10 ml balsamic vinegar.

**Method**
1. Sous-vide ribs: Cook sealed ribs at 68 °C for 24 h. After cooking, remove from bag, pat dry and sear in a hot pan until deep brown. Reduce bag juices with unsweetened pomegranate reduction, red wine and balsamic to glaze consistency.
2. Make purée: Mash drained purple potatoes with warm milk, butter and Parmesan until smooth; season.
3. Sauté greens: Heat olive oil; sauté garlic until fragrant. Add chard and cook until wilted; season and finish with toasted pecans.
4. Serve: Spoon potato purée onto plates. Top with a rib portion, brush with glaze and arrange greens alongside.

**Why this works**
Long, low-temperature cooking converts collagen into gelatin without drying the meat, yielding fork-tender ribs. Miso and brown sugar in the cure enhance savoury depth and promote browning when seared. Purple potatoes provide antioxidants and a vivid colour contrast. Compliance refinement: the portion is positioned as an occasional red-meat dinner, with trimmed ribs, less added sugar, and an unsweetened pomegranate glaze.

**Plating / Pairing**
Plate with glaze drizzled around and garnish with micro-herbs. Pair with a bold Malbec or a tart pomegranate mocktail.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Reduced cure sugar from 10 g to 4 g total.
- Changed glaze to unsweetened pomegranate reduction.
- Flagged as occasional, portion-controlled red meat.

---

## Sous-Vide Eggs (Technique / base preparation)
**Servings: 4 | Active time: 5 min | Total time: 50 min**

**Mise en place**
- Set a sous-vide circulator to 63 °C in a deep pot or Cambro.
- Prepare 4 cold large eggs, a slotted spoon, and an ice bath.
- Choose the serving destination before cooking: ramen, bowls, Benedict variations, or toast.

**Ingredients**
- 4 large eggs
- Water for sous-vide bath
- Ice water for chilling if not serving immediately

**Method**
1. Preheat a sous-vide water bath to 63 °C.
2. Lower eggs into the water and cook for 45 min.
3. Transfer to ice water for 5 min if holding, or crack directly into a small bowl if serving immediately.
4. Season only at service so salt does not toughen the tender whites.

**Why this works**
At 63 °C, yolk proteins thicken into a jammy custard while whites remain tender. Precise temperature control prevents the chalky overcooking common with simmered eggs and adds protein without processed ingredients.

**Plating / Pairing**
Use as a finishing element for ramen, grain bowls, or Benedict-style plates. Pair with acid, herbs, and chile oil for contrast.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Added DGA compliance metadata and sodium/additive-aware execution notes where relevant.

---

## Spaghetti Cacio e Pepe Oatmeal (Italian × Andean)
**Servings: 4 | Active time: 15 min | Total time: 25 min**

**Mise en place**
- Station A - Oats: Measure 200 g rolled oats and 600 ml water. Grate 80 g Pecorino Romano and 20 g Parmigiano-Reggiano. Grind 5 g black pepper.
- Station B - Mushrooms: Clean and slice 200 g porcini or mixed mushrooms; mince 1 garlic clove; pick fresh thyme.
- Station C - Eggs (optional): Poach or fry 4 eggs for topping.

**Ingredients**
- 200 g rolled oats, 600 ml water, 200 ml whole milk, 80 g Pecorino Romano, 20 g Parmigiano-Reggiano, 5 g freshly ground black pepper, 20 ml olive oil, 200 g mushrooms, 1 garlic clove, fresh thyme, salt.

**Method**
1. Cook mushrooms: Sauté mushrooms in olive oil until golden; add minced garlic and thyme; season.
2. Make oatmeal: In a saucepan, bring water and milk to a boil. Stir in oats; cook 5 min until creamy. Stir in cheeses and black pepper vigorously to emulsify. Adjust thickness with additional milk.
3. Serve: Spoon oatmeal into bowls; top with sautéed mushrooms and an optional poached or fried egg. Grind extra pepper on top.

**Why this works**
Oats absorb liquid quickly, and adding cheese off heat prevents curdling. Freshly ground pepper releases volatile compounds that define this classic Roman flavour. Mushrooms add umami and meaty texture.

**Plating / Pairing**
Serve immediately while hot. Pair with a macchiato or a lightly floral white wine.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Added DGA compliance metadata and sodium/additive-aware execution notes where relevant.

---

## Takoyaki-Inspired Omelette Roll (Japanese)
**Servings: 4 | Active time: 20 min | Total time: 35 min**

**Mise en place**
- **Station A - Batter:** Beat 6 eggs with 30 ml dashi, 5 ml low-sodium soy sauce and 5 ml rice vinegar. Dice 100 g cooked octopus. Mix scallions, pickled ginger and 20 g toasted whole-wheat panko.
- **Station B - Sauces:** Simmer tomato paste, tamari, rice vinegar, date paste, ginger and sesame oil into a glossy tomato-tamarind glaze. Mix Greek yoghurt with yuzu or lime and a spoon of homemade aioli.
- **Station C - Toppings:** Prepare bonito flakes, aonori and sliced scallions.

**Ingredients**
- 6 eggs, 30 ml dashi, 5 ml low-sodium soy sauce, 5 ml rice vinegar, 100 g cooked octopus, 30 g scallions, 20 g pickled ginger, 20 g toasted whole-wheat panko or tenkasu made from whole-grain batter.
- **Tomato-tamarind glaze:** 60 g tomato paste, 20 ml tamari, 15 ml rice vinegar, 10 g date paste, 5 g grated ginger, 5 ml toasted sesame oil.
- **Yuzu-yoghurt aioli:** 70 g Greek yoghurt, 1 egg yolk or 20 g homemade olive-oil aioli, 10 g yuzu juice or lime, pinch salt.
- Bonito flakes, aonori, sliced scallions.

**Method**
1. **Cook omelette:** Heat a rectangular tamagoyaki pan or non-stick skillet over medium heat. Lightly oil. Pour a thin layer of egg mixture to coat. Sprinkle with octopus, scallions, ginger and whole-wheat panko. Once set, roll omelette toward you. Repeat layering and rolling until all egg is used.
2. **Glaze & slice:** Brush the roll with tomato-tamarind glaze and drizzle with yuzu-yoghurt aioli. Sprinkle with bonito flakes and aonori; the flakes will undulate from residual heat.
3. **Serve:** Slice into rounds and serve warm.

**Why this works**
Layered tamagoyaki technique creates a tender, structured omelette. Octopus preserves the takoyaki reference; whole-wheat panko adds crunch. Replacing bottled sweet/salty condiments with tomato-tamarind glaze plus yuzu-yoghurt aioli removes common additive and added-sugar pitfalls while keeping sweet-savory umami.

**Plating / Pairing**
Arrange slices neatly and garnish with extra scallions. Pair with cold green tea, roasted barley tea, or a light pilsner as optional adult service.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Replaced bottled sweet/salty condiments with homemade glaze and yuzu-yoghurt aioli.
- Changed soy sauce to low-sodium.

---

## Whole-Grain Chilaquiles with Poached Eggs and Salsa Roja (Mexican)
**Servings: 4 | Active time: 30 min | Total time: 50 min**

**Mise en place**
- Station A - Tortillas: Cut 8 whole-grain corn tortillas into wedges; brush with 15 ml oil and bake at 200 °C for 10 min until crisp.
- Station B - Salsa roja: Roast 5 tomatoes, 2 cloves garlic, 1 onion and 2 dried guajillo chiles; blend with 10 ml lime juice, 5 g cumin and salt.
- Station C - Garnish: Crumble 100 g queso fresco, slice 1 avocado, chop 20 g cilantro. Prepare 4 eggs for poaching.

**Ingredients**
- 8 whole-grain corn tortillas, 5 tomatoes, 2 garlic cloves, 1 onion, 2 dried guajillo chiles, 10 ml lime juice, 5 g cumin, salt, 100 g queso fresco, 1 avocado, 20 g cilantro, 4 eggs.

**Method**
1. Make chips: Bake tortilla wedges until golden and crisp; set aside.
2. Prepare salsa: Dry-roast tomatoes, garlic, onion and guajillos in a hot pan until charred. Blend with lime juice, cumin and a splash of water to a smooth sauce; season.
3. Poach eggs: Poach eggs in simmering acidulated water for 3 min; remove with a slotted spoon.
4. Assemble chilaquiles: Heat salsa in a skillet; add tortilla chips and toss until coated but still crisp. Divide among plates. Top each with a poached egg, queso fresco, avocado slices and cilantro.

**Why this works**
Baking tortillas reduces oil while still producing crunchy chips. Charring vegetables adds smoky depth to the salsa. Tossing chips in hot salsa just before serving preserves some crunch, and the runny egg yolk enriches the sauce.

**Plating / Pairing**
Serve immediately with lime wedges. Pair with a michelada or cold brewed hibiscus tea.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Added DGA compliance metadata and sodium/additive-aware execution notes where relevant.

---

## Whole-Grain Croissant with Roast Turkey & Queso Fresco (French × Peruvian)
**Servings: 4 | Active time: 1 h | Total time: 12 h (includes laminating/proofing)**

**Mise en place**
- **Station A - Dough:** Prepare détrempe: combine 200 g whole-wheat flour, 200 g bread flour, 10 g yeast, 16 g raw sugar, 8 g salt, 220 ml cold milk and 50 g melted butter. Knead and refrigerate.
- **Station B - Butter block:** Flatten 250 g cold butter between parchment to a 20 cm square. Chill.
- **Station C - Filling:** Slice 200 g home-roasted turkey breast or pork tenderloin and 200 g queso fresco; prepare 50 g rocoto-orange glaze with 20 g honey, orange zest and vinegar.

**Ingredients**
- 200 g whole-wheat flour, 200 g bread flour, 10 g instant yeast, 16 g raw sugar, 8 g salt, 220 ml milk, 50 g butter, 250 g butter for laminating.
- Filling: 200 g home-roasted turkey breast or pork tenderloin, 200 g queso fresco, 50 g rocoto-orange glaze made from roasted rocoto, orange zest, 20 g honey, and 10 ml vinegar.

**Method**
1. **Laminate dough:** Encapsulate butter block within détrempe and perform three single folds, resting dough in the refrigerator between folds to keep butter cold. Roll to 0.5 cm thick, cut into triangles and shape into croissants. Proof 2 h until puffy.
2. **Bake:** Brush with egg wash and bake at 200 °C for 15 min until deeply golden and flaky.
3. **Assemble:** Split croissants; spread a thin layer of rocoto-orange glaze. Fill with home-roasted turkey or pork tenderloin and queso fresco. Serve warm.

**Why this works**
Whole-wheat flour is tempered with bread flour to preserve flakiness while increasing fiber. Cold butter layers create steam for distinct lamination. The revision removes processed cured deli meat and keeps added sugar below 10 g per serving by lowering dough sugar and using a small honey-based glaze.

**Plating / Pairing**
Serve with arugula and orange segments. Pair with cappuccino, black coffee, or sparkling orange water.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Replaced cured deli meat/cured deli meat with home-roasted turkey or pork tenderloin.
- Reduced dough sugar and glaze sweetener to keep added sugar under 10 g/serving.

---

## Whole-Grain Gnocchi a la Huancaína with Grilled Prawns (Italian × Peruvian)
**Servings: 4 | Active time: 1 h | Total time: 1 h 20 min**

**Mise en place**
- Station A - Gnocchi: Bake 600 g russet potatoes until fluffy; peel and rice while hot. Mix with 150 g whole-wheat flour, 50 g grated Parmesan, 1 egg yolk and 5 g salt. Roll into ropes and cut into 2 cm pieces; press with a fork.
- Station B - Huancaína sauce: Blend 200 g queso fresco, 100 g aji amarillo paste, 200 ml evaporated milk, 20 g rolled oats or 30 g cooked potato (for body), 2 garlic cloves and 30 ml olive oil until smooth.
- Station C - Prawns: Clean 12 large prawns (≈400 g); marinate with 10 ml olive oil, 5 ml lime juice, 1 g smoked paprika and salt.

**Ingredients**
- 600 g russet potatoes, 150 g whole-wheat flour, 50 g Parmesan, 1 egg yolk, 5 g salt.
- Huancaína sauce: 200 g queso fresco, 100 g aji amarillo paste, 200 ml evaporated milk, 20 g rolled oats or 30 g cooked potato, 2 garlic cloves, 30 ml olive oil.
- 12 large prawns, olive oil, lime juice, smoked paprika, salt.
- Garnish: Chopped olives, boiled quail eggs (optional), parsley.

**Method**
1. Form gnocchi: Combine potatoes with flour, Parmesan, yolk and salt until a soft dough forms. Avoid overworking to keep light. Roll into ropes and cut. Dust with flour.
2. Cook gnocchi: Boil salted water. Drop gnocchi in batches; cook until they float (≈2 min). Transfer to ice water briefly, then drain and toss with olive oil.
3. Make sauce: Blend all sauce ingredients until smooth; adjust thickness with milk. Warm gently in a saucepan; do not boil.
4. Grill prawns: Heat a grill pan; cook marinated prawns for 1 - 2 min per side until just opaque.
5. Sauté gnocchi: In a skillet, heat 20 ml olive oil; sauté gnocchi until lightly golden. Toss with huancaína sauce. Top with grilled prawns, olives and parsley.

**Why this works**
Baking potatoes instead of boiling keeps them dry, producing lighter gnocchi. Using whole-wheat flour adds nuttiness and fibre without making the dumplings heavy. Huancaína sauce’s emulsified cheese and aji mixture coats each gnocchi, while grilling prawns adds smoky sweetness. Compliance refinement: rolled oats or cooked potato thicken the sauce without packaged crackers.

**Plating / Pairing**
Serve in shallow bowls with sauce pooling around. Pair with a crisp Sauvignon Blanc or maracuya (passion fruit) juice.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Replaced packaged crackers with rolled oats or cooked potato.

---

## Whole-Grain Pizza Diavola with Spicy Mushrooms & Rocoto Honey (Italian × Peruvian)
**Servings: 4 | Active time: 45 min | Total time: 18 h (includes dough fermentation)**

**Mise en place**
- **Station A - Dough:** Combine 250 g whole-wheat flour, 250 g bread flour, 2 g instant yeast, 350 ml water, 10 g salt and 20 ml olive oil. Refrigerate 12-24 h; bring to room temperature 2 h before baking.
- **Station B - Sauce & toppings:** Simmer 400 g crushed tomatoes with garlic and oregano. Roast mushrooms and cherry tomatoes with olive oil, chili flakes and salt until deeply browned. Slice bell pepper, red onion and mozzarella.
- **Station C - Rocoto honey:** Warm 24 g honey with 20 g rocoto paste; cool.

**Ingredients**
- 250 g whole-wheat flour, 250 g bread flour, 2 g yeast, 350 ml water, 10 g salt, 20 ml olive oil.
- Toppings: 400 g crushed tomatoes with no added sugar, 2 garlic cloves, oregano, 250 g oyster or cremini mushrooms, 120 g cherry tomatoes, 1 red bell pepper, 1 red onion, 200 g mozzarella, 24 g rocoto honey, 10 g chili flakes, 15 ml olive oil.

**Method**
1. **Prepare dough:** Mix and knead gently. Refrigerate 12-24 h. On baking day, divide, shape into balls and rest until puffy.
2. **Preheat oven:** Heat a baking stone at 250 °C for at least 45 min. Stretch dough into 30 cm rounds.
3. **Assemble pizza:** Spread a thin layer of tomato sauce. Top with roasted mushrooms, cherry tomatoes, bell pepper, onion and mozzarella. Bake on the stone for 8-10 min until crust is crisp and toppings are bubbling.
4. **Finish:** Drizzle with a measured 24 g rocoto honey and sprinkle with chili flakes and fresh oregano.

**Why this works**
Long fermentation builds flavor and extensibility in the whole-grain dough. Roasted mushrooms and tomatoes replace processed deli meat with Maillard-rich umami, preserving the Diavola mood without processed meat. Rocoto honey is portioned at 24 g total, or 6 g added sugar per serving.

**Plating / Pairing**
Slice and serve immediately with arugula or radicchio. Pair with sparkling water, bitter orange soda with no added sugar, or dry Lambrusco as optional adult service.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Removed processed deli meat entirely.
- Reduced rocoto honey to 24 g total.
- Kept Diavola heat through mushrooms, chile, and rocoto.

---

## Whole-Grain Spaghetti Puttanesca with Ají Panca Seafood (Italian × Peruvian)
**Servings: 4 | Active time: 30 min | Total time: 45 min**

**Mise en place**
- Station A - Pasta: Cook 400 g whole-grain spaghetti in abundant salted water until al dente; reserve 200 ml pasta water.
- Station B - Sauce: Chop 4 anchovy fillets, mince 4 garlic cloves, chop 10 g ají panca paste, pit 80 g olives, rinse 30 g capers, chop 400 g canned San Marzano tomatoes.
- Station C - Seafood: Clean 300 g squid tubes (cut into rings) and 200 g shrimp.

**Ingredients**
- 400 g whole-grain spaghetti, 4 anchovy fillets, 4 garlic cloves, 10 g ají panca paste, 80 g olives, 30 g capers, 400 g canned tomatoes, 300 g squid, 200 g shrimp, 5 g red pepper flakes, 30 ml olive oil, 5 ml red wine vinegar, 20 g parsley.

**Method**
1. Make sauce: In a large skillet, warm olive oil; melt anchovies and garlic until fragrant. Add ají panca paste and red pepper flakes; cook 1 min. Stir in tomatoes, olives and capers; simmer 10 min until thickened.
2. Cook seafood: Add squid rings and shrimp to the sauce; cook 2-3 min until just opaque.
3. Combine: Toss cooked spaghetti with sauce, adding reserved pasta water to loosen as needed. Finish with red wine vinegar and chopped parsley.

**Why this works**
Ají panca introduces a smoky, mild heat that complements the briny anchovies and olives. Whole-grain pasta brings extra nutty flavour and fibre, and reserved pasta water emulsifies the sauce, helping it cling to each strand.

**Plating / Pairing**
Twirl pasta into nests on warm plates; top with extra seafood pieces. Pair with a dry rosé or citrus-infused sparkling water.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Added DGA compliance metadata and sodium/additive-aware execution notes where relevant.

---

## Whiskey Pecan Dark Chocolate Tart (American)
**Servings: 8 | Active time: 1 h | Total time: 4 h (includes chilling)**

**Mise en place**
- **Station A - Tart shell:** Combine 200 g whole-wheat flour, 50 g almond flour, 30 g cocoa powder, 25 g raw sugar and 120 g cold butter. Rub to sandy crumbs; add 1 beaten egg and form dough. Press into a 24 cm tart tin; chill 30 min.
- **Station B - Ganache:** Chop 250 g 85% dark chocolate. Heat 250 ml heavy cream with 25 g honey until steaming; pour over chocolate and stir until smooth. Stir in 30 ml espresso; whiskey is optional adult variation only. Add 50 g butter.
- **Station C - Pecans:** Toast 150 g pecans; reserve 50 g for garnish.

**Ingredients**
- Tart shell: 200 g whole-wheat flour, 50 g almond flour, 30 g cocoa powder, 25 g raw sugar, 120 g butter, 1 egg, pinch salt.
- Filling: 250 g 85% dark chocolate, 250 ml heavy cream, 25 g honey, 30 ml espresso or whiskey only as optional adult variation, 50 g butter, 100 g toasted pecans.
- Garnish: 50 g toasted pecans, flaky sea salt.

**Method**
1. Bake shell: Blind-bake chilled tart shell at 180 °C for 15 min with weights; remove weights and bake 10 min more until crisp. Cool.
2. Make ganache: Combine hot cream and 25 g honey with chopped chocolate; stir until glossy. Stir in butter and whiskey until emulsified. Fold in 100 g chopped pecans.
3. Fill tart: Pour ganache into cooled shell; smooth top. Arrange remaining pecans decoratively. Chill for 3 h until set.
4. Finish: Sprinkle with flaky sea salt just before serving.

**Why this works**
Whole-wheat and almond flours create a nutty, sturdy tart shell. 85% chocolate plus cream and pecans delivers luxury with less sugar; the revision caps added sugar at 50 g total for 8 servings, or about 6.25 g per serving. Espresso supplies complexity without default alcohol.

**Plating / Pairing**
Slice with a hot knife for clean edges. Serve with crème fraîche or Greek yoghurt. Pair with black coffee; tawny Port or whiskey is optional adult service only.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Reduced added sugar to about 6.25 g per serving.
- Made espresso the default flavoring and whiskey optional.
- Specified 85% dark chocolate.

---

## Whole-Grain Bagels (Base recipe / whole-grain bakery)
**Servings: 8 bagels | Active time: 45 min | Total time: 3 h**

**Mise en place**
- Mix 250 g whole-wheat flour, 250 g bread flour, 7 g yeast, 6 g barley malt syrup, 300 ml warm water, and 10 g salt.
- Prepare a baking tray with parchment and a wide pot with water plus 20 g baking soda.
- Set aside sesame, poppy, or everything-style seed mix with no additives.

**Ingredients**
- 250 g whole-wheat flour
- 250 g bread flour
- 7 g instant yeast
- 6 g barley malt syrup
- 300 ml warm water
- 10 g salt
- 20 g baking soda for boiling water
- Optional: 20 g sesame or poppy seeds

**Method**
1. Knead the dough 8-10 min until elastic. Cover and proof 1 h, or until visibly puffy.
2. Divide into 8 pieces, shape into rings, and rest 20-30 min.
3. Boil each bagel in the baking-soda water for 30 s per side.
4. Bake at 220 °C for 15-18 min until deeply golden and shiny.
5. Cool at least 15 min before slicing to preserve the chewy crumb.

**Why this works**
Whole-wheat flour adds fiber and nutty flavor; bread flour preserves the chew associated with bagels. The alkaline boil gelatinizes surface starch so the crust bakes glossy and resilient. Only 6 g malt syrup is used across the entire batch, keeping added sugar very low per serving.

**Plating / Pairing**
Use for slow-roasted salmon bagels, egg sandwiches, or avocado toast. Pair with black coffee or sparkling citrus water.

**DGA Compliance Review**
Reviewed against the embedded DGA rule set. Recipe keeps its original flavor-map role while using whole/minimally processed ingredients, whole grains where applicable, controlled added sugar, protein diversity, and low-additive technique choices.
- Updated base note to reflect lower malt syrup and fresh salmon service.

---
