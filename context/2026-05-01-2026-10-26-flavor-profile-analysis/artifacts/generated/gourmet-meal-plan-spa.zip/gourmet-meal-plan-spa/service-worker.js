/* Minimal service worker for static shell caching. CDN files still require network unless cached by browser/CDN. */
const CACHE_NAME = 'gourmet-meal-plan-spa-v1';
const APP_SHELL = [
  './',
  './index.html',
  './assets/css/tailwind.css',
  './assets/js/data.js',
  './assets/js/app.js',
  './manifest.webmanifest',
  './assets/icons/chef-hat.svg'
];
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)));
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))));
});
self.addEventListener('fetch', (event) => {
  event.respondWith(caches.match(event.request).then((cached) => cached || fetch(event.request)));
});
