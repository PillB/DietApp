# Gourmet Meal Plan SPA

A beautiful, dark-mode-first, zero-build Single Page Application for the personalized one-month gourmet meal plan. It turns the markdown meal plan into an interactive personal-chef dashboard with calendar, weekly menus, full recipe modals, shopping lists, checkboxes, print views, and an exportable JSON data layer.

## What is included

- Interactive 28-day monthly calendar.
- Daily menus with clickable recipe links.
- Weekly overview tabs and thematic highlights.
- Searchable recipe library.
- Full recipe modal with mise en place, ingredients, method, science notes, plating/pairing, and preserved source text.
- Weekly shopping lists with persistent checkboxes via `localStorage`.
- Copy-all and print buttons for shopping lists.
- Knowledge Map page showing the user's taste DNA.
- PWA-ready `manifest.webmanifest` and `service-worker.js`.
- GitHub Pages-ready static folder structure.

## Tech stack

- Static HTML.
- Tailwind CSS via CDN.
- Alpine.js via CDN.
- Vanilla JavaScript.
- No Node.js, no npm, no bundler, no build step.

## Folder structure

```text
gourmet-meal-plan-spa/
├── README.md
├── index.html
├── manifest.webmanifest
├── service-worker.js
└── assets/
    ├── css/
    │   └── tailwind.css
    ├── icons/
    │   ├── calendar.svg
    │   ├── chef-hat.svg
    │   ├── knowledge.svg
    │   ├── recipe.svg
    │   └── shopping.svg
    └── js/
        ├── app.js
        └── data.js
```

## Local use

Open `index.html` directly in your browser.

For best PWA/service-worker behavior, use a tiny local server:

```bash
python3 -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

## Deploy to GitHub Pages

1. Create a new GitHub repository, for example `gourmet-meal-plan-spa`.
2. Copy all files in this folder into the repository.
3. Commit and push:

```bash
git init
git add .
git commit -m "Initial gourmet meal plan SPA"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/gourmet-meal-plan-spa.git
git push -u origin main
```

4. In GitHub, open the repository **Settings → Pages**.
5. Set **Source** to **Deploy from a branch**.
6. Select `main` and `/root`, then save.
7. Your site will publish at:

```text
https://YOUR_USERNAME.github.io/gourmet-meal-plan-spa/
```

## Data editing

All meal plan content lives in:

```text
assets/js/data.js
```

Edit `window.MEAL_PLAN_DATA` to adjust dishes, recipes, shopping lists, or knowledge-map sections.

## Notes

The app intentionally uses CDN links for Tailwind and Alpine because the requirement is maximum simplicity. For a production site with strict no-CDN/offline requirements, generate a static Tailwind stylesheet and vendor Alpine locally.
