/*
  Gourmet Meal Plan SPA - Data Store
  ------------------------------------------------------------
  This file is intentionally static and self-contained. It exposes
  `window.MEAL_PLAN_DATA` so the SPA can run from file://, GitHub
  Pages, or any static host without a build step or backend.
*/

window.MEAL_PLAN_DATA = {
  "meta": {
    "title": "Gourmet Meal Plan SPA",
    "subtitle": "A dark-mode personal chef dashboard for the one-month gourmet plan",
    "generatedAt": "2026-05-01T18:46:42.168631Z",
    "sourceReport": "report.md",
    "validationNotes": [
      "Data extracted from the previously generated markdown meal-plan report.",
      "Recipe fullMarkdown fields preserve the complete source text for every recipe, including metric units, science notes, and pairing notes.",
      "Interactive UI uses the structured fields while retaining fullMarkdown for auditability."
    ]
  },
  "knowledgeMap": {
    "Cuisines & Cultural Inspirations": [
      {
        "label": "Peruvian/Nikkei",
        "description": "Frequent orders of artichoke empanadas, quinua bowls, Inca-inspired drinks, maki acevichado and takoyaki show a love of Peru’s Nikkei fusion and seafood-driven dishes."
      },
      {
        "label": "Japanese & Pan-Asian",
        "description": "Takoyaki, nigiri, dumplings (xiao long bao), bulgogi cupbap and Korean-influenced combos indicate comfort with Japanese, Chinese and Korean flavors."
      },
      {
        "label": "Italian & Mediterranean",
        "description": "Multiple orders of spaghetti cacio e pepe, gnocchi, pizza diavola/margherita and croissant sandwiches highlight Italian classics and rich dairy."
      },
      {
        "label": "Mexican/Tex-Mex",
        "description": "Crispy chicken tacos, burritos and guacamole show an affinity for bold Tex-Mex flavors and corn-based dishes."
      },
      {
        "label": "American comfort/fast food",
        "description": "Burgers, chicken nuggets, breakfast sandwiches and fries reflect indulgent American comfort food."
      },
      {
        "label": "Peruvian street food & bakery",
        "description": "Pan con huevo, croissant de jamón y queso, alfajor-style cookies and morcilla cocktail reveal a fondness for street-style snacks and bakery items."
      }
    ],
    "Dominant Flavor Profiles": [
      {
        "label": "Umami-rich",
        "description": "Frequent cheese (pecorino, parmesan, cheddar), meats (beef, chicken, seafood), soy-based sauces and miso highlight a crave for deep savoury notes."
      },
      {
        "label": "Mild-moderate heat",
        "description": "Orders like pizza Inferno, burritos and acevichado rolls suggest appreciation for controlled chile heat (ají amarillo, rocoto, guajillo, chipotle)."
      },
      {
        "label": "Creamy & rich",
        "description": "Hollandaise, cheese sauces, hot chocolate and yoghurt parfaits point to a taste for creamy textures and dairy richness."
      },
      {
        "label": "Crispy & crunchy",
        "description": "Takoyaki, chicken nuggets, fried tacos, empanadas, croissants and cookies show a strong preference for crunchy, crackly textures."
      },
      {
        "label": "Sweet & chocolate-forward",
        "description": "Regular chocolate bars, cookies and milkshakes indicate a sweet tooth for deep cocoa flavours rather than light fruit desserts."
      },
      {
        "label": "Balanced acidity",
        "description": "Items like coleslaw, acevichado (ceviche-style), and Mexican salsas reveal comfort with bright citrus and vinegar notes to cut richness."
      }
    ],
    "Textures": [
      {
        "label": "Crunchy/fried",
        "description": "Breaded chicken, takoyaki, crispy tacos, croissants, empanadas and churros demonstrate enjoyment of audible crunch."
      },
      {
        "label": "Tender & chewy",
        "description": "Pasta, gnocchi, dumplings and sushi highlight a love of tender or gently chewy textures."
      },
      {
        "label": "Creamy & saucy",
        "description": "Hollandaise, cheese sauces, yoghurt, puddings and parfaits showcase creamy elements."
      },
      {
        "label": "Layered/stacked",
        "description": "Burgers, burritos and sushi rolls suggest appreciation for layered constructions and bowls."
      }
    ],
    "Key Ingredients & Spices": [
      {
        "label": "Proteins",
        "description": "Eggs (poached/fried/scrambled), poultry (chicken, turkey), seafood (salmon, tuna, octopus), beef (burgers, lomo saltado), occasional pork/ham."
      },
      {
        "label": "Cheese & dairy",
        "description": "Pecorino, parmesan, mozzarella, cheddar, queso fresco, yoghurt; preference for rich, full-fat flavours."
      },
      {
        "label": "Vegetables & herbs",
        "description": "Artichokes, avocados, onions, cabbage, mushrooms, spinach, aji amarillo, rocoto, cilantro, basil, oregano."
      },
      {
        "label": "Grains & starches",
        "description": "Bread (brioche, croissant), pasta, gnocchi, tortillas, rice, quinoa, oats; many refined in orders but to be shifted to whole-grain forms in the plan."
      },
      {
        "label": "Spices & aromatics",
        "description": "Black pepper, garlic, ginger, cumin, sesame, soy, miso, chili powders (guajillo, chipotle), ají peppers; sweet spices like cinnamon and clove (chicha morada)."
      }
    ],
    "Preferred Techniques": [
      {
        "label": "Frying & crisping",
        "description": "Deep-frying or pan-frying (nuggets, tacos, takoyaki) to achieve crunchy exteriors."
      },
      {
        "label": "Baking & pastry",
        "description": "Croissants, empanadas and pizza highlight a love of baking and laminated doughs."
      },
      {
        "label": "Poaching & slow cooking",
        "description": "Poached eggs (Benedict), ramen broths and braised meats show comfort with slow, moist techniques."
      },
      {
        "label": "Stir-frying & sautéing",
        "description": "Lomo saltado and noodle dishes require quick, high-heat stir-frying."
      },
      {
        "label": "Grilling & searing",
        "description": "Burgers, chicken and seafood often involve searing or grilling to develop Maillard flavour."
      },
      {
        "label": "Layering & rolling",
        "description": "Burritos, sushi, dumplings and burgers show a penchant for layered preparations."
      }
    ],
    "Overall Taste DNA": [
      {
        "label": "",
        "description": "The user’s taste is indulgent and eclectic: they crave bold, savoury umami with occasional bursts of moderate heat; love crispy textures juxtaposed with creamy sauces; enjoy global mash-ups (Peruvian-Nikkei, Tex-Mex, Italian classics) and are unafraid of rich dairy and decadent desserts. Vegetables are welcomed when integrated with strong flavours (artichoke empanadas, coleslaw), while purely raw or bland foods rarely appear. The palate balances richness with brightness (citrus, pickles) and values artisanal preparation over dietary restraint."
      }
    ],
    "How This Will Guide the Month": [
      {
        "label": "Elevate familiar favourites",
        "description": "Classic orders like Eggs Benedict, tacos, gnocchi and burgers will be reimagined with whole-grain foundations, artisanal sauces and higher-quality proteins."
      },
      {
        "label": "Honour cultural fusions",
        "description": "Dishes will fuse Peruvian, Nikkei, Italian, Mexican and American inspirations, reflecting the user’s diverse ordering history."
      },
      {
        "label": "Amplify textures",
        "description": "Recipes will feature intentional contrasts-crispy toppings on creamy bases, tender meats with crunchy sides-to satisfy the user’s love of texture."
      },
      {
        "label": "Prioritise whole foods",
        "description": "Refined ingredients will be swapped for fibre-rich whole grains, fresh produce and homemade sauces to align with the dietary guidelines while preserving indulgence."
      },
      {
        "label": "Balance richness with acidity and spice",
        "description": "Each menu will pair creamy or fatty elements with acidic or spicy components (citrus, ají, pickled vegetables) to keep palates refreshed."
      },
      {
        "label": "Include protein variety",
        "description": "Meals will incorporate eggs, seafood, poultry, legumes and limited red meat, providing the recommended protein while avoiding processed meats."
      }
    ]
  },
  "executiveSummary": "This one-month gourmet plan synthesises the new 2025-2030 dietary guidelines with the user’s demonstrated tastes. By analysing more than 1 300 delivery orders, the plan infers a deep appreciation for Peruvian-Nikkei fusion, Italian comfort foods, Tex-Mex street fare and American classics, all featuring bold umami, controlled heat, creamy sauces and crispy textures. The guidelines demand avoidance of ultra-processed foods, refined grains, added sugars and artificial additives while emphasising whole grains, varied proteins, healthy fats and minimal processing. Each recipe in this plan uses whole-grain bases, fresh produce, full-fat dairy without added sugar, and homemade sauces to meet those standards. Over four themed weeks-Peruvian-Nikkei & seafood, Italian-Mediterranean, Mexican & Asian street food, and elevated American comfort-the user journeys through familiar flavours elevated to Michelin-level sophistication. Detailed mise en place lists, precise metric measurements, just-in-time prep instructions and food-science insights ensure the recipes are testable for skilled home cooks. Wine or beverage pairings and weekly shopping lists streamline execution. The result is an indulgent, varied and cohesive flavour adventure that honours both the user’s taste DNA and the latest nutritional guidance.",
  "weeklyOverviews": [
    {
      "week": 1,
      "title": "Week 1 - Peruvian-Nikkei & Seafood Fusion",
      "theme": "Introduce the month with dishes that celebrate Peru’s Nikkei heritage and the user’s love of eggs, artichokes and seafood. Expect bright citrus and ají sauces balancing creamy elements.",
      "highlights": [
        "Fresh fish (salmon, tuna, cod) and shellfish (prawns) for ceviche-like and sautéed dishes.",
        "Whole-grain English muffins, quinoa and brown rice to replace white breads and refined grains.",
        "Ají amarillo, rocoto and cilantro provide Peruvian heat; kombu, bonito flakes and soy bring Japanese umami.",
        "Early prep: make whole-grain English muffins and croissant dough; prepare fish stock and roast purple corn for dessert syrup."
      ]
    },
    {
      "week": 2,
      "title": "Week 2 - Italian & Mediterranean Comfort",
      "theme": "Honour Italian classics-pasta, pizza, risotto-reimagined with whole grains and Peruvian accents. Rich cheeses and sauces pair with roasted vegetables and seafood.",
      "highlights": [
        "Brown rice risotto, whole-grain gnocchi and pizza dough highlight fibre-rich grains.",
        "Parmesan, pecorino and mozzarella used judiciously to add umami without overwhelming.",
        "Artichokes, mushrooms, tomatoes and olives provide plant variety; herbs like basil, oregano and rosemary.",
        "Prep tasks include fermenting pizza dough overnight, soaking brown rice, and making lucuma purée for tiramisu."
      ]
    },
    {
      "week": 3,
      "title": "Week 3 - Mexican & Asian Street Food Remix",
      "theme": "A playful mash-up of Mexican street dishes and East Asian favourites, featuring tacos, ramen and mapo tofu. Spices, fermented flavours and pickles keep dishes lively.",
      "highlights": [
        "Whole-grain tortillas, brown rice and quinoa support tacos and bowls.",
        "Homemade salsas (salsa roja, chipotle crema), miso glazes and birria broth provide depth.",
        "Proteins include sustainable fish, miso-glazed salmon, slow-braised lamb or beef, turkey mince and tofu.",
        "Prepare birria base and ramen broth ahead; ferment kimchi and prepare churro dough a day prior."
      ]
    },
    {
      "week": 4,
      "title": "Week 4 - Elevated American Classics",
      "theme": "Finish with comfort foods elevated through technique-sous-vide short ribs, gourmet burgers and refined fried chicken. Sweet dishes showcase balanced indulgence.",
      "highlights": [
        "Whole-grain bagels and sourdough for breakfast; almond-flour breading for fried chicken; farro and purple potatoes for starch.",
        "Focus on searing and sous-vide for perfect textures and controlled fat content.",
        "Desserts like whiskey-pecan tart use dark chocolate and nuts to satisfy sweet cravings while limiting added sugar.",
        "Prep includes curing salmon for bagels, marinating chicken and ribs, and making truffle salt for popcorn."
      ]
    }
  ],
  "dailyPlans": [
    {
      "week": 1,
      "day": "Mon",
      "breakfast": "Artichoke Benedict with Trout",
      "lunch": "Nikkei Quinoa Acevichado Salad",
      "dinner": "Whole-Grain Gnocchi a la Huancaína",
      "snackDessert": "Dark Chocolate & Chicha Morada Mousse"
    },
    {
      "week": 1,
      "day": "Tue",
      "breakfast": "Takoyaki-Inspired Omelette Roll",
      "lunch": "Chifa Lomo Saltado Quinoa Bowl",
      "dinner": "Deconstructed Acevichado Cod",
      "snackDessert": "Roasted Plantain Chips with Rocoto Dip"
    },
    {
      "week": 1,
      "day": "Wed",
      "breakfast": "Whole-Grain Croissant w/ Jamón del País & Queso Fresco",
      "lunch": "Brown Rice Risotto alla Parmigiana with Artichokes & Scallops",
      "dinner": "Whole-Grain Pizza Diavola",
      "snackDessert": "Lucuma Tiramisu"
    },
    {
      "week": 1,
      "day": "Thu",
      "breakfast": "Andean Cacio e Pepe Oatmeal",
      "lunch": "Grilled Chicken Parmigiana with Aji Verde",
      "dinner": "Seafood Puttanesca with Ají Panca",
      "snackDessert": "Parmesan-Reggiano Crisps with Aji Amarillo Aioli"
    },
    {
      "week": 1,
      "day": "Fri",
      "breakfast": "Whole-Grain Chilaquiles with Poached Eggs",
      "lunch": "Crispy Fish Tacos with Mango Slaw",
      "dinner": "Birria Ramen with Sous-Vide Egg",
      "snackDessert": "Chocolate-Cinnamon Churro Sundae"
    },
    {
      "week": 1,
      "day": "Sat",
      "breakfast": "Korean Bulgogi Breakfast Burrito",
      "lunch": "Miso-Glazed Salmon Bowl with Brown Rice & Sesame Kale",
      "dinner": "Mapo Tofu with Quinoa & Sichuan Peanuts",
      "snackDessert": "Elote-Style Corn Ribs"
    },
    {
      "week": 1,
      "day": "Sun",
      "breakfast": "Smoked Salmon & Avocado Whole-Grain Bagel",
      "lunch": "Buttermilk Fried Chicken Sandwich with Cabbage Slaw",
      "dinner": "Sous-Vide Short Ribs with Purple Potato Purée",
      "snackDessert": "Whiskey Pecan Dark Chocolate Tart"
    },
    {
      "week": 2,
      "day": "Mon",
      "breakfast": "Takoyaki-Inspired Omelette Roll",
      "lunch": "Grilled Chicken Parmigiana with Aji Verde",
      "dinner": "Mapo Tofu with Quinoa & Sichuan Peanuts",
      "snackDessert": "Lucuma Tiramisu"
    },
    {
      "week": 2,
      "day": "Tue",
      "breakfast": "Whole-Grain Croissant w/ Jamón del País & Queso Fresco",
      "lunch": "Brown Rice Risotto alla Parmigiana with Artichokes & Scallops",
      "dinner": "Deconstructed Acevichado Cod",
      "snackDessert": "Parmesan-Reggiano Crisps"
    },
    {
      "week": 2,
      "day": "Wed",
      "breakfast": "Andean Cacio e Pepe Oatmeal",
      "lunch": "Nikkei Quinoa Acevichado Salad",
      "dinner": "Birria Ramen with Sous-Vide Egg",
      "snackDessert": "Dark Chocolate & Chicha Morada Mousse"
    },
    {
      "week": 2,
      "day": "Thu",
      "breakfast": "Whole-Grain Chilaquiles with Poached Eggs",
      "lunch": "Miso-Glazed Salmon Bowl with Brown Rice & Sesame Kale",
      "dinner": "Whole-Grain Gnocchi a la Huancaína",
      "snackDessert": "Elote-Style Corn Ribs"
    },
    {
      "week": 2,
      "day": "Fri",
      "breakfast": "Korean Bulgogi Breakfast Burrito",
      "lunch": "Chifa Lomo Saltado Quinoa Bowl",
      "dinner": "Whole-Grain Pizza Diavola",
      "snackDessert": "Chocolate-Cinnamon Churro Sundae"
    },
    {
      "week": 2,
      "day": "Sat",
      "breakfast": "Smoked Salmon & Avocado Bagel",
      "lunch": "Crispy Fish Tacos with Mango Slaw",
      "dinner": "Seafood Puttanesca with Ají Panca",
      "snackDessert": "Roasted Plantain Chips with Rocoto Dip"
    },
    {
      "week": 2,
      "day": "Sun",
      "breakfast": "Artichoke Benedict with Trout",
      "lunch": "Buttermilk Fried Chicken Sandwich with Cabbage Slaw",
      "dinner": "Sous-Vide Short Ribs with Purple Potato Purée",
      "snackDessert": "Whiskey Pecan Dark Chocolate Tart"
    },
    {
      "week": 3,
      "day": "Mon",
      "breakfast": "Whole-Grain Croissant w/ Jamón del País & Queso Fresco",
      "lunch": "Miso-Glazed Salmon Bowl with Brown Rice & Sesame Kale",
      "dinner": "Whole-Grain Gnocchi a la Huancaína",
      "snackDessert": "Elote-Style Corn Ribs"
    },
    {
      "week": 3,
      "day": "Tue",
      "breakfast": "Andean Cacio e Pepe Oatmeal",
      "lunch": "Nikkei Quinoa Acevichado Salad",
      "dinner": "Mapo Tofu with Quinoa & Sichuan Peanuts",
      "snackDessert": "Dark Chocolate & Chicha Morada Mousse"
    },
    {
      "week": 3,
      "day": "Wed",
      "breakfast": "Whole-Grain Chilaquiles with Poached Eggs",
      "lunch": "Brown Rice Risotto alla Parmigiana with Artichokes & Scallops",
      "dinner": "Deconstructed Acevichado Cod",
      "snackDessert": "Lucuma Tiramisu"
    },
    {
      "week": 3,
      "day": "Thu",
      "breakfast": "Korean Bulgogi Breakfast Burrito",
      "lunch": "Crispy Fish Tacos with Mango Slaw",
      "dinner": "Birria Ramen with Sous-Vide Egg",
      "snackDessert": "Roasted Plantain Chips with Rocoto Dip"
    },
    {
      "week": 3,
      "day": "Fri",
      "breakfast": "Smoked Salmon & Avocado Bagel",
      "lunch": "Chifa Lomo Saltado Quinoa Bowl",
      "dinner": "Whole-Grain Pizza Diavola",
      "snackDessert": "Parmesan-Reggiano Crisps"
    },
    {
      "week": 3,
      "day": "Sat",
      "breakfast": "Artichoke Benedict with Trout",
      "lunch": "Grilled Chicken Parmigiana with Aji Verde",
      "dinner": "Seafood Puttanesca with Ají Panca",
      "snackDessert": "Chocolate-Cinnamon Churro Sundae"
    },
    {
      "week": 3,
      "day": "Sun",
      "breakfast": "Takoyaki-Inspired Omelette Roll",
      "lunch": "Buttermilk Fried Chicken Sandwich with Cabbage Slaw",
      "dinner": "Sous-Vide Short Ribs with Purple Potato Purée",
      "snackDessert": "Whiskey Pecan Dark Chocolate Tart"
    },
    {
      "week": 4,
      "day": "Mon",
      "breakfast": "Andean Cacio e Pepe Oatmeal",
      "lunch": "Crispy Fish Tacos with Mango Slaw",
      "dinner": "Birria Ramen with Sous-Vide Egg",
      "snackDessert": "Parmesan-Reggiano Crisps"
    },
    {
      "week": 4,
      "day": "Tue",
      "breakfast": "Whole-Grain Chilaquiles with Poached Eggs",
      "lunch": "Nikkei Quinoa Acevichado Salad",
      "dinner": "Whole-Grain Pizza Diavola",
      "snackDessert": "Elote-Style Corn Ribs"
    },
    {
      "week": 4,
      "day": "Wed",
      "breakfast": "Korean Bulgogi Breakfast Burrito",
      "lunch": "Brown Rice Risotto alla Parmigiana with Artichokes & Scallops",
      "dinner": "Mapo Tofu with Quinoa & Sichuan Peanuts",
      "snackDessert": "Dark Chocolate & Chicha Morada Mousse"
    },
    {
      "week": 4,
      "day": "Thu",
      "breakfast": "Smoked Salmon & Avocado Bagel",
      "lunch": "Grilled Chicken Parmigiana with Aji Verde",
      "dinner": "Deconstructed Acevichado Cod",
      "snackDessert": "Roasted Plantain Chips with Rocoto Dip"
    },
    {
      "week": 4,
      "day": "Fri",
      "breakfast": "Artichoke Benedict with Trout",
      "lunch": "Miso-Glazed Salmon Bowl with Brown Rice & Sesame Kale",
      "dinner": "Whole-Grain Gnocchi a la Huancaína",
      "snackDessert": "Chocolate-Cinnamon Churro Sundae"
    },
    {
      "week": 4,
      "day": "Sat",
      "breakfast": "Takoyaki-Inspired Omelette Roll",
      "lunch": "Chifa Lomo Saltado Quinoa Bowl",
      "dinner": "Seafood Puttanesca with Ají Panca",
      "snackDessert": "Lucuma Tiramisu"
    },
    {
      "week": 4,
      "day": "Sun",
      "breakfast": "Whole-Grain Croissant w/ Jamón del País & Queso Fresco",
      "lunch": "Buttermilk Fried Chicken Sandwich with Cabbage Slaw",
      "dinner": "Sous-Vide Short Ribs with Purple Potato Purée",
      "snackDessert": "Whiskey Pecan Dark Chocolate Tart"
    }
  ],
  "recipes": [
    {
      "id": "artichoke-benedict-with-trout",
      "name": "Artichoke Benedict with Trout",
      "cuisine": "Peruvian × Nikkei",
      "servings": "4",
      "activeTime": "45 min",
      "totalTime": "1 h 15 min",
      "miseEnPlace": [
        "Station A - English muffins: Mix whole-wheat dough (250 g whole-wheat flour, 250 g bread flour, 7 g yeast, 10 g sugar, 300 ml warm milk, 30 g butter, 5 g salt) and let proof; shape into 8 muffins, rest 20 min.",
        "Station B - Artichokes & trout: Trim and steam 4 large artichoke hearts (400 g), then slice into quarters; season 200 g smoked trout fillet and flake into bite-sized pieces.",
        "Station C - Hollandaise: Juice 1 lemon (30 ml), dice 50 g cold butter, measure 3 egg yolks and 50 ml aji-amarillo purée; set up bain-marie.",
        "Station D - Poaching setup: Crack 8 fresh eggs into individual ramekins; bring a wide shallow pan of water to a gentle simmer with 30 ml vinegar.",
        "Station E - Garnishes: Chop 30 g chives and 10 g cilantro; prepare aji amarillo hollandaise ingredients and warm plates."
      ],
      "ingredients": [
        "For the muffins: As per Station A above.",
        "Protein & veg: 4 steamed artichoke hearts (≈400 g), 200 g smoked trout fillet, 8 large eggs.",
        "Hollandaise: 3 egg yolks, 50 g cold unsalted butter cut into cubes, 30 ml lemon juice, 50 ml aji amarillo purée, 2 ml Dijon mustard, salt to taste.",
        "Poaching liquor: Water, 30 ml white vinegar.",
        "Garnish: Chopped chives, cilantro, freshly ground black pepper."
      ],
      "method": [
        "Cook muffins: Preheat a heavy skillet over medium-low heat. Roll the rested dough into 2 cm-thick rounds using a ring cutter. Cook muffins dry (no fat) until golden on each side (≈5 min per side). Split and keep warm.",
        "Steam artichokes: If not already steamed, cook trimmed hearts in salted boiling water until tender (≈10 min); drain and sear in a hot pan with a drizzle of olive oil until lightly caramelised.",
        "Prepare hollandaise: In a bain-marie over barely simmering water, whisk egg yolks with lemon juice and mustard until thick ribbons form. Slowly whisk in cold butter cubes one at a time until emulsified. Add aji amarillo purée; season with salt. Keep warm but not hot to avoid scrambling.",
        "Poach eggs: Create a gentle vortex in the poaching liquor and slide in one egg at a time. Cook 3 min for runny yolks. Remove with a slotted spoon to a paper towel.",
        "Assemble: Place a toasted muffin half on each plate. Top with seared artichoke quarters and flaked trout. Gently perch a poached egg on top and spoon over warm aji amarillo hollandaise. Sprinkle with chives, cilantro and black pepper."
      ],
      "whyThisWorks": "Whole-wheat muffins provide nutty depth and fibre. Emulsifying butter into egg yolks over gentle heat yields a stable, velvety hollandaise; adding aji amarillo introduces fruity heat and vibrant colour without excess fat. Poaching eggs in acidulated water coagulates the whites quickly for neat spheres, while smoked trout delivers umami and omega-3s.",
      "plating": "Serve two halves per person on warm plates. Garnish with micro-greens for colour. Pair with a glass of sparkling brut nature or a chilled chicha morada spritzer (sparkling water with purple-corn reduction and lime) for a non-alcoholic option.",
      "fullMarkdown": "## Artichoke Benedict with Trout (Peruvian × Nikkei)\n\n**Servings:** 4 **Active time:** 45 min **Total time:** 1 h 15 min\n\n**Mise en place (≈30 min)**\n- **Station A - English muffins:** Mix whole-wheat dough (250 g whole-wheat flour, 250 g bread flour, 7 g yeast, 10 g sugar, 300 ml warm milk, 30 g butter, 5 g salt) and let proof; shape into 8 muffins, rest 20 min.\n- **Station B - Artichokes & trout:** Trim and steam 4 large artichoke hearts (400 g), then slice into quarters; season 200 g smoked trout fillet and flake into bite-sized pieces.\n- **Station C - Hollandaise:** Juice 1 lemon (30 ml), dice 50 g cold butter, measure 3 egg yolks and 50 ml aji-amarillo purée; set up bain-marie.\n- **Station D - Poaching setup:** Crack 8 fresh eggs into individual ramekins; bring a wide shallow pan of water to a gentle simmer with 30 ml vinegar.\n- **Station E - Garnishes:** Chop 30 g chives and 10 g cilantro; prepare aji amarillo hollandaise ingredients and warm plates.\n\n**Ingredients**\n- **For the muffins:** As per Station A above.\n- **Protein & veg:** 4 steamed artichoke hearts (≈400 g), 200 g smoked trout fillet, 8 large eggs.\n- **Hollandaise:** 3 egg yolks, 50 g cold unsalted butter cut into cubes, 30 ml lemon juice, 50 ml aji amarillo purée, 2 ml Dijon mustard, salt to taste.\n- **Poaching liquor:** Water, 30 ml white vinegar.\n- **Garnish:** Chopped chives, cilantro, freshly ground black pepper.\n\n**Method**\n1. **Cook muffins:** Preheat a heavy skillet over medium-low heat. Roll the rested dough into 2 cm-thick rounds using a ring cutter. Cook muffins dry (no fat) until golden on each side (≈5 min per side). Split and keep warm.\n2. **Steam artichokes:** If not already steamed, cook trimmed hearts in salted boiling water until tender (≈10 min); drain and sear in a hot pan with a drizzle of olive oil until lightly caramelised.\n3. **Prepare hollandaise:** In a bain-marie over barely simmering water, whisk egg yolks with lemon juice and mustard until thick ribbons form. Slowly whisk in cold butter cubes one at a time until emulsified. Add aji amarillo purée; season with salt. Keep warm but not hot to avoid scrambling.\n4. **Poach eggs:** Create a gentle vortex in the poaching liquor and slide in one egg at a time. Cook 3 min for runny yolks. Remove with a slotted spoon to a paper towel.\n5. **Assemble:** Place a toasted muffin half on each plate. Top with seared artichoke quarters and flaked trout. Gently perch a poached egg on top and spoon over warm aji amarillo hollandaise. Sprinkle with chives, cilantro and black pepper.\n\n**Why this works:** Whole-wheat muffins provide nutty depth and fibre. Emulsifying butter into egg yolks over gentle heat yields a stable, velvety hollandaise; adding aji amarillo introduces fruity heat and vibrant colour without excess fat. Poaching eggs in acidulated water coagulates the whites quickly for neat spheres, while smoked trout delivers umami and omega-3s.\n\n**Plating & Pairing:** Serve two halves per person on warm plates. Garnish with micro-greens for colour. Pair with a glass of sparkling brut nature or a chilled chicha morada spritzer (sparkling water with purple-corn reduction and lime) for a non-alcoholic option."
    },
    {
      "id": "birria-ramen-with-sous-vide-egg",
      "name": "Birria Ramen with Sous-Vide Egg",
      "cuisine": "Mexican × Japanese",
      "servings": "4",
      "activeTime": "1 h",
      "totalTime": "6 h (includes braising)",
      "miseEnPlace": [
        "Station A - Birria broth: Toast 5 dried guajillo and 3 ancho chiles until fragrant; rehydrate in hot water. Sear 800 g lamb or beef chuck in a Dutch oven; gather aromatics (1 onion, 4 garlic cloves, 2 bay leaves, 5 g cumin seeds, 5 g coriander seeds).",
        "Station B - Ramen tare: Combine 60 ml tamari, 60 ml sake (optional), 30 ml mirin, 30 ml fish sauce and 30 ml rice vinegar.",
        "Station C - Noodles & toppings: Prepare 800 g fresh whole-wheat ramen noodles; slice 200 g shiitake mushrooms, 100 g radishes, chop 30 g cilantro, slice 2 limes. Set up sous-vide water bath at 63 °C for eggs."
      ],
      "ingredients": [
        "Birria: 800 g grass-fed lamb or beef chuck cut into chunks, 5 dried guajillo chiles, 3 dried ancho chiles, 1 onion, 4 garlic cloves, 1 stick cinnamon, 2 bay leaves, 5 g each cumin and coriander seeds, 500 ml beef stock, 500 ml water.",
        "Ramen: 800 g fresh whole-wheat ramen noodles, 4 eggs (for sous-vide), 200 g shiitake mushrooms, 100 g radishes, 100 g bean sprouts, 30 g cilantro, lime wedges.",
        "Tare: 60 ml tamari, 60 ml sake (omit or use 30 ml extra tamari for non-alcoholic), 30 ml mirin or apple-cider vinegar, 30 ml fish sauce, 30 ml rice vinegar.",
        "Garnish: 20 g toasted sesame seeds, 2 spring onions sliced."
      ],
      "method": [
        "Make birria: Toast chiles briefly in a dry pan, then soak in 250 ml boiling water until soft. Blend with soaking liquid, onion, garlic, spices and a pinch of salt to a smooth paste. Sear meat in a Dutch oven until browned; add chile purée, cinnamon stick, bay leaves, stock and water. Bring to a simmer, cover and braise in a 150 °C oven for 4-5 hours until meat is tender. Shred meat and return to broth; adjust salt.",
        "Prepare eggs: Submerge eggs in a 63 °C sous-vide bath for 45 min (for jammy yolks). Shock in ice water, then carefully crack and slide into bowls later.",
        "Cook noodles & toppings: Sauté mushrooms in a drop of sesame oil until browned; season lightly. Blanch ramen noodles in boiling water for 1 min (fresh) or until al dente; rinse briefly to stop cooking.",
        "Assemble bowls: Place 1 tbsp tare in each warmed bowl. Add noodles. Ladle over hot birria broth and shredded meat. Top with mushrooms, bean sprouts, sliced radish and cilantro. Gently add peeled sous-vide egg. Finish with sesame seeds, spring onions and a squeeze of lime."
      ],
      "whyThisWorks": "Slow braising extracts collagen from chuck, producing a silky broth enriched with toasted chiles for deep, complex flavour. The tare concentrates umami (tamari, fish sauce) and balances acidity (vinegar) to season the broth just before serving. Sous-vide eggs cooked at 63 °C achieve custardy yolks that meld into the soup, echoing the richness of traditional ramen.",
      "plating": "Serve in deep bowls with long-handled chopsticks and spoons. The broth should be glossy with a gentle chile sheen. Pair with a crisp Kölsch beer (limit to one glass) or a chilled hibiscus-lime agua fresca.",
      "fullMarkdown": "## Birria Ramen with Sous-Vide Egg (Mexican × Japanese)\n\n**Servings:** 4 **Active time:** 1 h **Total time:** 6 h (includes braising)\n\n**Mise en place (≈40 min)**\n- **Station A - Birria broth:** Toast 5 dried guajillo and 3 ancho chiles until fragrant; rehydrate in hot water. Sear 800 g lamb or beef chuck in a Dutch oven; gather aromatics (1 onion, 4 garlic cloves, 2 bay leaves, 5 g cumin seeds, 5 g coriander seeds).\n- **Station B - Ramen tare:** Combine 60 ml tamari, 60 ml sake (optional), 30 ml mirin, 30 ml fish sauce and 30 ml rice vinegar.\n- **Station C - Noodles & toppings:** Prepare 800 g fresh whole-wheat ramen noodles; slice 200 g shiitake mushrooms, 100 g radishes, chop 30 g cilantro, slice 2 limes. Set up sous-vide water bath at 63 °C for eggs.\n\n**Ingredients**\n- **Birria:** 800 g grass-fed lamb or beef chuck cut into chunks, 5 dried guajillo chiles, 3 dried ancho chiles, 1 onion, 4 garlic cloves, 1 stick cinnamon, 2 bay leaves, 5 g each cumin and coriander seeds, 500 ml beef stock, 500 ml water.\n- **Ramen:** 800 g fresh whole-wheat ramen noodles, 4 eggs (for sous-vide), 200 g shiitake mushrooms, 100 g radishes, 100 g bean sprouts, 30 g cilantro, lime wedges.\n- **Tare:** 60 ml tamari, 60 ml sake (omit or use 30 ml extra tamari for non-alcoholic), 30 ml mirin or apple-cider vinegar, 30 ml fish sauce, 30 ml rice vinegar.\n- **Garnish:** 20 g toasted sesame seeds, 2 spring onions sliced.\n\n**Method**\n1. **Make birria:** Toast chiles briefly in a dry pan, then soak in 250 ml boiling water until soft. Blend with soaking liquid, onion, garlic, spices and a pinch of salt to a smooth paste. Sear meat in a Dutch oven until browned; add chile purée, cinnamon stick, bay leaves, stock and water. Bring to a simmer, cover and braise in a 150 °C oven for 4-5 hours until meat is tender. Shred meat and return to broth; adjust salt.\n2. **Prepare eggs:** Submerge eggs in a 63 °C sous-vide bath for 45 min (for jammy yolks). Shock in ice water, then carefully crack and slide into bowls later.\n3. **Cook noodles & toppings:** Sauté mushrooms in a drop of sesame oil until browned; season lightly. Blanch ramen noodles in boiling water for 1 min (fresh) or until al dente; rinse briefly to stop cooking.\n4. **Assemble bowls:** Place 1 tbsp tare in each warmed bowl. Add noodles. Ladle over hot birria broth and shredded meat. Top with mushrooms, bean sprouts, sliced radish and cilantro. Gently add peeled sous-vide egg. Finish with sesame seeds, spring onions and a squeeze of lime.\n\n**Why this works:** Slow braising extracts collagen from chuck, producing a silky broth enriched with toasted chiles for deep, complex flavour. The tare concentrates umami (tamari, fish sauce) and balances acidity (vinegar) to season the broth just before serving. Sous-vide eggs cooked at 63 °C achieve custardy yolks that meld into the soup, echoing the richness of traditional ramen.\n\n**Plating & Pairing:** Serve in deep bowls with long-handled chopsticks and spoons. The broth should be glossy with a gentle chile sheen. Pair with a crisp Kölsch beer (limit to one glass) or a chilled hibiscus-lime agua fresca."
    },
    {
      "id": "brown-rice-risotto-alla-parmigiana-with-artichokes-scallops",
      "name": "Brown Rice Risotto alla Parmigiana with Artichokes & Scallops",
      "cuisine": "Italian",
      "servings": "4",
      "activeTime": "50 min",
      "totalTime": "1 h 10 min (includes soaking)",
      "miseEnPlace": [
        "Station A - Rice: Soak 300 g short-grain brown rice in water for at least 30 min to soften the bran; drain.",
        "Station B - Stock: Heat 1.5 L vegetable or fish stock; keep warm on a back burner.",
        "Station C - Vegetables: Mince 1 shallot, slice 200 g mushrooms, quarter 2 steamed artichoke hearts (200 g), grate 80 g Parmigiano-Reggiano.",
        "Station D - Scallops: Pat dry 8 large sea scallops (320 g) and season with sea salt; bring a sauté pan to medium-high heat."
      ],
      "ingredients": [
        "300 g short-grain brown rice (soaked), 1.5 L hot stock (vegetable/fish), 1 shallot, 2 tbsp (30 ml) olive oil, 200 g mixed mushrooms, 200 g cooked artichoke hearts, 100 ml dry white wine, 80 g Parmigiano-Reggiano, 20 g unsalted butter, 8 sea scallops (≈320 g total), 5 g fresh thyme, salt & black pepper."
      ],
      "method": [
        "Build the soffritto: In a heavy saucepan over medium heat, sweat minced shallot in olive oil until translucent. Add drained brown rice and stir 2 min to coat the grains; this toasting promotes even absorption.",
        "Deglaze: Add white wine; cook until mostly evaporated. Ladle in hot stock (~200 ml at a time), stirring continuously. Maintain a gentle simmer and add more stock only when the previous addition is nearly absorbed. This process takes about 40 min; the rice should be creamy yet toothsome.",
        "Cook vegetables: In a separate pan, sauté mushrooms in a drizzle of olive oil until browned; season with thyme, salt and pepper. Add artichoke quarters and warm through.",
        "Finish risotto: When rice is just al dente, stir in sautéed mushrooms and artichokes. Remove from heat; vigorously beat in butter and grated Parmigiano-Reggiano to create emulsified creaminess. Season to taste.",
        "Sear scallops: Heat a non-stick or stainless pan until very hot. Add 1 tbsp oil, then scallops. Sear without moving for 2 min until a deep golden crust forms; flip and cook 1 min more. The centres should remain slightly translucent.",
        "Serve: Spoon risotto into warm shallow bowls; top with two scallops each. Drizzle with good olive oil and sprinkle with extra cheese and black pepper."
      ],
      "whyThisWorks": "Soaking brown rice softens the bran, reducing cooking time and yielding a creamy texture similar to arborio. Slowly adding hot stock and stirring agitates starch into the liquid, creating the classic risotto creaminess without cream. High-heat searing ensures scallops develop a Maillard crust while staying juicy.",
      "plating": "Present risotto in a shallow bowl with scallops neatly perched. Garnish with micro-herbs. Pair with a minerally Italian white wine (Verdicchio) or sparkling water with lemon zest.",
      "fullMarkdown": "## Brown Rice Risotto alla Parmigiana with Artichokes & Scallops (Italian)\n\n**Servings:** 4 **Active time:** 50 min **Total time:** 1 h 10 min (includes soaking)\n\n**Mise en place (≈25 min)**\n- **Station A - Rice:** Soak 300 g short-grain brown rice in water for at least 30 min to soften the bran; drain.\n- **Station B - Stock:** Heat 1.5 L vegetable or fish stock; keep warm on a back burner.\n- **Station C - Vegetables:** Mince 1 shallot, slice 200 g mushrooms, quarter 2 steamed artichoke hearts (200 g), grate 80 g Parmigiano-Reggiano.\n- **Station D - Scallops:** Pat dry 8 large sea scallops (320 g) and season with sea salt; bring a sauté pan to medium-high heat.\n\n**Ingredients**\n- 300 g short-grain brown rice (soaked), 1.5 L hot stock (vegetable/fish), 1 shallot, 2 tbsp (30 ml) olive oil, 200 g mixed mushrooms, 200 g cooked artichoke hearts, 100 ml dry white wine, 80 g Parmigiano-Reggiano, 20 g unsalted butter, 8 sea scallops (≈320 g total), 5 g fresh thyme, salt & black pepper.\n\n**Method**\n1. **Build the soffritto:** In a heavy saucepan over medium heat, sweat minced shallot in olive oil until translucent. Add drained brown rice and stir 2 min to coat the grains; this toasting promotes even absorption.\n2. **Deglaze:** Add white wine; cook until mostly evaporated. Ladle in hot stock (~200 ml at a time), stirring continuously. Maintain a gentle simmer and add more stock only when the previous addition is nearly absorbed. This process takes about 40 min; the rice should be creamy yet toothsome.\n3. **Cook vegetables:** In a separate pan, sauté mushrooms in a drizzle of olive oil until browned; season with thyme, salt and pepper. Add artichoke quarters and warm through.\n4. **Finish risotto:** When rice is just al dente, stir in sautéed mushrooms and artichokes. Remove from heat; vigorously beat in butter and grated Parmigiano-Reggiano to create emulsified creaminess. Season to taste.\n5. **Sear scallops:** Heat a non-stick or stainless pan until very hot. Add 1 tbsp oil, then scallops. Sear without moving for 2 min until a deep golden crust forms; flip and cook 1 min more. The centres should remain slightly translucent.\n6. **Serve:** Spoon risotto into warm shallow bowls; top with two scallops each. Drizzle with good olive oil and sprinkle with extra cheese and black pepper.\n\n**Why this works:** Soaking brown rice softens the bran, reducing cooking time and yielding a creamy texture similar to arborio. Slowly adding hot stock and stirring agitates starch into the liquid, creating the classic risotto creaminess without cream. High-heat searing ensures scallops develop a Maillard crust while staying juicy.\n\n**Plating & Pairing:** Present risotto in a shallow bowl with scallops neatly perched. Garnish with micro-herbs. Pair with a minerally Italian white wine (Verdicchio) or sparkling water with lemon zest."
    },
    {
      "id": "chifa-lomo-saltado-quinoa-bowl",
      "name": "Chifa Lomo Saltado Quinoa Bowl",
      "cuisine": "Peruvian × Chinese",
      "servings": "4",
      "activeTime": "35 min",
      "totalTime": "50 min",
      "miseEnPlace": [
        "Station A - Quinoa: Rinse 240 g tricolour quinoa; place in a pot with 480 ml water and a pinch of salt; bring to boil then simmer 15 min until fluffy.",
        "Station B - Beef & vegetables: Slice 500 g beef sirloin into strips; marinate with 30 ml soy sauce, 5 ml sesame oil and 10 ml rice vinegar. Slice 1 red onion into petals, 2 tomatoes into wedges, julienne 1 aji amarillo, chop 20 g cilantro.",
        "Station C - Sauce: Mix 30 ml oyster sauce, 15 ml soy sauce, 15 ml Pisco (optional) or rice vinegar, 10 ml fish sauce and 5 g sugar (or 5 ml honey).",
        "Station D - Fried egg & fries: Cut 2 medium sweet potatoes into batons; toss with 15 ml olive oil, salt and smoked paprika. Preheat oven to 220 °C."
      ],
      "ingredients": [
        "240 g quinoa, 500 g beef sirloin, 2 sweet potatoes, 1 red onion, 2 tomatoes, 1 aji amarillo chile, 20 g cilantro, 2 cloves garlic minced, 30 ml oyster sauce, 45 ml soy sauce, 20 ml vinegar or Pisco, 10 ml fish sauce, 5 ml sesame oil, 4 eggs, olive oil, salt, black pepper."
      ],
      "method": [
        "Bake sweet-potato fries: Toss batons with olive oil, smoked paprika and salt. Spread on a parchment-lined tray; bake at 220 °C for 25 min, flipping once, until crisp.",
        "Cook quinoa: Simmer rinsed quinoa with water until tender and fluffy; set aside and keep warm.",
        "Stir-fry beef: Heat a wok or heavy skillet until smoking. Add 1 tbsp high-smoke-point oil. Sear marinated beef strips in batches until browned; set aside.",
        "Aromatics: In the same wok, add a bit more oil if needed; stir-fry garlic, onion petals and aji amarillo for 2 min until fragrant. Return beef; add tomatoes and sauce mixture. Stir-fry 1 min to glaze; the tomatoes should soften but retain shape.",
        "Fry eggs: Fry 4 eggs sunny-side up in a non-stick pan until whites are crisp and yolks runny.",
        "Assemble bowls: Divide quinoa among bowls. Top with lomo saltado mixture, sweet-potato fries and a fried egg. Sprinkle with chopped cilantro."
      ],
      "whyThisWorks": "High-heat wok cooking caramelises beef quickly, preserving tenderness and producing smoky wok hei. Tomatoes release juice that, combined with oyster sauce and soy, creates a glossy sauce. Sweet-potato fries baked rather than fried maintain crispness while reducing processed fat and providing beta-carotene.",
      "plating": "Serve in deep bowls with the egg yolk perched like a jewel. Pair with a citrusy sour beer or chilled kombucha infused with passion fruit.",
      "fullMarkdown": "## Chifa Lomo Saltado Quinoa Bowl (Peruvian × Chinese)\n\n**Servings:** 4 **Active time:** 35 min **Total time:** 50 min\n\n**Mise en place (≈20 min)**\n- **Station A - Quinoa:** Rinse 240 g tricolour quinoa; place in a pot with 480 ml water and a pinch of salt; bring to boil then simmer 15 min until fluffy.\n- **Station B - Beef & vegetables:** Slice 500 g beef sirloin into strips; marinate with 30 ml soy sauce, 5 ml sesame oil and 10 ml rice vinegar. Slice 1 red onion into petals, 2 tomatoes into wedges, julienne 1 aji amarillo, chop 20 g cilantro.\n- **Station C - Sauce:** Mix 30 ml oyster sauce, 15 ml soy sauce, 15 ml Pisco (optional) or rice vinegar, 10 ml fish sauce and 5 g sugar (or 5 ml honey).\n- **Station D - Fried egg & fries:** Cut 2 medium sweet potatoes into batons; toss with 15 ml olive oil, salt and smoked paprika. Preheat oven to 220 °C.\n\n**Ingredients**\n- 240 g quinoa, 500 g beef sirloin, 2 sweet potatoes, 1 red onion, 2 tomatoes, 1 aji amarillo chile, 20 g cilantro, 2 cloves garlic minced, 30 ml oyster sauce, 45 ml soy sauce, 20 ml vinegar or Pisco, 10 ml fish sauce, 5 ml sesame oil, 4 eggs, olive oil, salt, black pepper.\n\n**Method**\n1. **Bake sweet-potato fries:** Toss batons with olive oil, smoked paprika and salt. Spread on a parchment-lined tray; bake at 220 °C for 25 min, flipping once, until crisp.\n2. **Cook quinoa:** Simmer rinsed quinoa with water until tender and fluffy; set aside and keep warm.\n3. **Stir-fry beef:** Heat a wok or heavy skillet until smoking. Add 1 tbsp high-smoke-point oil. Sear marinated beef strips in batches until browned; set aside.\n4. **Aromatics:** In the same wok, add a bit more oil if needed; stir-fry garlic, onion petals and aji amarillo for 2 min until fragrant. Return beef; add tomatoes and sauce mixture. Stir-fry 1 min to glaze; the tomatoes should soften but retain shape.\n5. **Fry eggs:** Fry 4 eggs sunny-side up in a non-stick pan until whites are crisp and yolks runny.\n6. **Assemble bowls:** Divide quinoa among bowls. Top with lomo saltado mixture, sweet-potato fries and a fried egg. Sprinkle with chopped cilantro.\n\n**Why this works:** High-heat wok cooking caramelises beef quickly, preserving tenderness and producing smoky wok hei. Tomatoes release juice that, combined with oyster sauce and soy, creates a glossy sauce. Sweet-potato fries baked rather than fried maintain crispness while reducing processed fat and providing beta-carotene.\n\n**Plating & Pairing:** Serve in deep bowls with the egg yolk perched like a jewel. Pair with a citrusy sour beer or chilled kombucha infused with passion fruit."
    },
    {
      "id": "chocolate-cinnamon-churro-sundae-with-dark-chocolate-sorbet",
      "name": "Chocolate-Cinnamon Churro Sundae with Dark Chocolate Sorbet",
      "cuisine": "Mexican",
      "servings": "4",
      "activeTime": "40 min",
      "totalTime": "2 h (includes chilling)",
      "miseEnPlace": [
        "Station A - Sorbet: In a saucepan combine 500 ml water, 80 g raw sugar, 50 g cocoa powder, 80 g 70 % dark chocolate chopped, 1 pinch salt and 2 g cinnamon; heat until dissolved. Chill base 1 h.",
        "Station B - Churros: Prepare whole-wheat pâte à choux: measure 125 ml water, 40 g butter, 5 g salt, 5 g sugar, 75 g whole-wheat flour and 2 eggs. Set up a piping bag with a star tip.",
        "Station C - Coating & caramel: Mix 50 g raw sugar with 5 g cinnamon. Prepare mezcal-spiced caramel by simmering 100 g honey, 50 g butter, 5 ml mezcal (optional) and a pinch of smoked salt until amber."
      ],
      "ingredients": [
        "Sorbet: 500 ml water, 80 g raw sugar, 50 g cocoa powder, 80 g dark chocolate (70 %), pinch salt, pinch cinnamon.",
        "Churros: 125 ml water, 40 g unsalted butter, 5 g salt, 5 g sugar, 75 g whole-wheat flour, 2 eggs, 500 ml high-oleic sunflower oil for frying.",
        "Coating: 50 g raw sugar, 5 g cinnamon.",
        "Caramel: 100 g honey, 50 g butter, 5 ml mezcal (optional), smoked sea salt.",
        "Garnish: Toasted almonds, orange zest."
      ],
      "method": [
        "Make sorbet: Whisk water, sugar and cocoa powder in a saucepan; bring to a simmer. Remove from heat; add chopped chocolate, salt and cinnamon, whisking until smooth. Cool, then chill 1 h. Churn in an ice-cream maker according to manufacturer’s instructions. Freeze until firm.",
        "Prepare churro dough: In a saucepan, bring water, butter, salt and sugar to a boil. Off heat, stir in flour until a cohesive dough forms. Return to low heat and stir 1 min to dry slightly. Transfer to a bowl; beat in eggs one at a time until smooth and glossy. Fill a piping bag fitted with a 1 cm star tip.",
        "Fry churros: Heat oil to 180 °C in a deep pot. Pipe 10 cm lengths of dough into the oil, cutting with scissors. Fry until puffed and golden (≈3 min). Drain on paper towels then roll in cinnamon sugar.",
        "Mezcal caramel: Simmer honey and butter until bubbly and amber. Off heat, stir in mezcal (if using) and a pinch of smoked salt.",
        "Assemble: Place two churros in each bowl. Scoop dark chocolate sorbet alongside. Drizzle with warm mezcal caramel. Garnish with toasted almonds and orange zest."
      ],
      "whyThisWorks": "Whole-wheat flour in the pâte à choux provides extra fibre yet still yields a light, crisp shell due to steam leavening. Chocolate sorbet, with no dairy, delivers intense cacao flavour and creamy texture thanks to cocoa butter; churning incorporates air and prevents large ice crystals. The caramel adds smoky sweetness, while cinnamon sugar evokes traditional churros.",
      "plating": "Serve immediately to enjoy the temperature contrast. Pair with a small pour of Oloroso sherry or a cinnamon-infused cold brew coffee.",
      "fullMarkdown": "## Chocolate-Cinnamon Churro Sundae with Dark Chocolate Sorbet (Mexican)\n\n**Servings:** 4 **Active time:** 40 min **Total time:** 2 h (includes chilling)\n\n**Mise en place (≈30 min)**\n- **Station A - Sorbet:** In a saucepan combine 500 ml water, 80 g raw sugar, 50 g cocoa powder, 80 g 70 % dark chocolate chopped, 1 pinch salt and 2 g cinnamon; heat until dissolved. Chill base 1 h.\n- **Station B - Churros:** Prepare whole-wheat pâte à choux: measure 125 ml water, 40 g butter, 5 g salt, 5 g sugar, 75 g whole-wheat flour and 2 eggs. Set up a piping bag with a star tip.\n- **Station C - Coating & caramel:** Mix 50 g raw sugar with 5 g cinnamon. Prepare mezcal-spiced caramel by simmering 100 g honey, 50 g butter, 5 ml mezcal (optional) and a pinch of smoked salt until amber.\n\n**Ingredients**\n- **Sorbet:** 500 ml water, 80 g raw sugar, 50 g cocoa powder, 80 g dark chocolate (70 %), pinch salt, pinch cinnamon.\n- **Churros:** 125 ml water, 40 g unsalted butter, 5 g salt, 5 g sugar, 75 g whole-wheat flour, 2 eggs, 500 ml high-oleic sunflower oil for frying.\n- **Coating:** 50 g raw sugar, 5 g cinnamon.\n- **Caramel:** 100 g honey, 50 g butter, 5 ml mezcal (optional), smoked sea salt.\n- **Garnish:** Toasted almonds, orange zest.\n\n**Method**\n1. **Make sorbet:** Whisk water, sugar and cocoa powder in a saucepan; bring to a simmer. Remove from heat; add chopped chocolate, salt and cinnamon, whisking until smooth. Cool, then chill 1 h. Churn in an ice-cream maker according to manufacturer’s instructions. Freeze until firm.\n2. **Prepare churro dough:** In a saucepan, bring water, butter, salt and sugar to a boil. Off heat, stir in flour until a cohesive dough forms. Return to low heat and stir 1 min to dry slightly. Transfer to a bowl; beat in eggs one at a time until smooth and glossy. Fill a piping bag fitted with a 1 cm star tip.\n3. **Fry churros:** Heat oil to 180 °C in a deep pot. Pipe 10 cm lengths of dough into the oil, cutting with scissors. Fry until puffed and golden (≈3 min). Drain on paper towels then roll in cinnamon sugar.\n4. **Mezcal caramel:** Simmer honey and butter until bubbly and amber. Off heat, stir in mezcal (if using) and a pinch of smoked salt.\n5. **Assemble:** Place two churros in each bowl. Scoop dark chocolate sorbet alongside. Drizzle with warm mezcal caramel. Garnish with toasted almonds and orange zest.\n\n**Why this works:** Whole-wheat flour in the pâte à choux provides extra fibre yet still yields a light, crisp shell due to steam leavening. Chocolate sorbet, with no dairy, delivers intense cacao flavour and creamy texture thanks to cocoa butter; churning incorporates air and prevents large ice crystals. The caramel adds smoky sweetness, while cinnamon sugar evokes traditional churros.\n\n**Plating & Pairing:** Serve immediately to enjoy the temperature contrast. Pair with a small pour of Oloroso sherry or a cinnamon-infused cold brew coffee."
    },
    {
      "id": "crispy-fish-tacos-with-mango-slaw-black-bean-salad",
      "name": "Crispy Fish Tacos with Mango Slaw & Black Bean Salad",
      "cuisine": "Mexican",
      "servings": "4",
      "activeTime": "45 min",
      "totalTime": "1 h",
      "miseEnPlace": [
        "Station A - Fish: Cut 600 g firm white fish (e.g., cod or corvina) into 12 strips. Prepare batter: whisk 150 g whole-wheat flour, 50 g cornstarch, 5 g baking powder, 5 g paprika and 5 g salt; gradually whisk in 300 ml chilled sparkling water.",
        "Station B - Slaw: Julienne 1 ripe mango, ½ red cabbage (200 g), 1 carrot and 1 red onion; toss with 30 ml lime juice, 15 ml olive oil, 5 ml honey and 2 g salt. Set aside to marinate.",
        "Station C - Black bean salad: Rinse 400 g cooked black beans, halve 200 g cherry tomatoes, dice 1 avocado, chop 20 g cilantro. Mix with 30 ml lime juice and 15 ml olive oil.",
        "Station D - Tortillas & crema: Warm 12 small corn tortillas. For chipotle crema, blend 200 g Greek yoghurt with 1 chipotle in adobo, 5 ml lime juice and a pinch of salt."
      ],
      "ingredients": [
        "600 g cod or corvina, 150 g whole-wheat flour, 50 g cornstarch, 5 g baking powder, 5 g paprika, 5 g salt, 300 ml sparkling water, sunflower oil for frying.",
        "Mango slaw: 1 mango, ½ red cabbage, 1 carrot, 1 red onion, 30 ml lime juice, 15 ml olive oil, 5 ml honey, pinch salt.",
        "Black bean salad: 400 g cooked black beans, 200 g cherry tomatoes, 1 avocado, 20 g cilantro, 30 ml lime juice, 15 ml olive oil.",
        "Chipotle crema & tortillas: 200 g Greek yoghurt, 1 chipotle chile in adobo, 5 ml lime juice, salt; 12 corn tortillas."
      ],
      "method": [
        "Make slaw & salad: Combine slaw vegetables and dressing; let stand to soften. Toss black bean salad ingredients together; season to taste.",
        "Prepare batter: In a bowl, whisk flour, cornstarch, baking powder, paprika and salt. Add sparkling water gradually to form a smooth, airy batter. Keep cold.",
        "Fry fish: Heat oil to 180 °C in a deep pan. Dip fish strips into batter, allowing excess to drip off, and fry in batches until puffed and golden (≈3 min). Transfer to a wire rack to drain; sprinkle with sea salt.",
        "Warm tortillas: Heat tortillas briefly on a dry skillet; keep warm in a cloth.",
        "Assemble tacos: Spread a spoonful of chipotle crema on each tortilla. Lay a piece of fried fish on top. Pile on mango slaw and garnish with cilantro leaves. Serve with black bean salad on the side."
      ],
      "whyThisWorks": "Using sparkling water and cornstarch in the batter traps bubbles and reduces gluten formation, resulting in an ultracrisp coating that stays light. Whole-wheat flour adds nuttiness without compromising texture. The acidic mango slaw cuts through fried richness, while chipotle crema provides smoky heat and probiotic benefits from yoghurt.",
      "plating": "Serve tacos family-style on a platter with extra lime wedges. Pair with a light lager or a chilled cucumber-lime agua fresca.",
      "fullMarkdown": "## Crispy Fish Tacos with Mango Slaw & Black Bean Salad (Mexican)\n\n**Servings:** 4 **Active time:** 45 min **Total time:** 1 h\n\n**Mise en place (≈25 min)**\n- **Station A - Fish:** Cut 600 g firm white fish (e.g., cod or corvina) into 12 strips. Prepare batter: whisk 150 g whole-wheat flour, 50 g cornstarch, 5 g baking powder, 5 g paprika and 5 g salt; gradually whisk in 300 ml chilled sparkling water.\n- **Station B - Slaw:** Julienne 1 ripe mango, ½ red cabbage (200 g), 1 carrot and 1 red onion; toss with 30 ml lime juice, 15 ml olive oil, 5 ml honey and 2 g salt. Set aside to marinate.\n- **Station C - Black bean salad:** Rinse 400 g cooked black beans, halve 200 g cherry tomatoes, dice 1 avocado, chop 20 g cilantro. Mix with 30 ml lime juice and 15 ml olive oil.\n- **Station D - Tortillas & crema:** Warm 12 small corn tortillas. For chipotle crema, blend 200 g Greek yoghurt with 1 chipotle in adobo, 5 ml lime juice and a pinch of salt.\n\n**Ingredients**\n- 600 g cod or corvina, 150 g whole-wheat flour, 50 g cornstarch, 5 g baking powder, 5 g paprika, 5 g salt, 300 ml sparkling water, sunflower oil for frying.\n- **Mango slaw:** 1 mango, ½ red cabbage, 1 carrot, 1 red onion, 30 ml lime juice, 15 ml olive oil, 5 ml honey, pinch salt.\n- **Black bean salad:** 400 g cooked black beans, 200 g cherry tomatoes, 1 avocado, 20 g cilantro, 30 ml lime juice, 15 ml olive oil.\n- **Chipotle crema & tortillas:** 200 g Greek yoghurt, 1 chipotle chile in adobo, 5 ml lime juice, salt; 12 corn tortillas.\n\n**Method**\n1. **Make slaw & salad:** Combine slaw vegetables and dressing; let stand to soften. Toss black bean salad ingredients together; season to taste.\n2. **Prepare batter:** In a bowl, whisk flour, cornstarch, baking powder, paprika and salt. Add sparkling water gradually to form a smooth, airy batter. Keep cold.\n3. **Fry fish:** Heat oil to 180 °C in a deep pan. Dip fish strips into batter, allowing excess to drip off, and fry in batches until puffed and golden (≈3 min). Transfer to a wire rack to drain; sprinkle with sea salt.\n4. **Warm tortillas:** Heat tortillas briefly on a dry skillet; keep warm in a cloth.\n5. **Assemble tacos:** Spread a spoonful of chipotle crema on each tortilla. Lay a piece of fried fish on top. Pile on mango slaw and garnish with cilantro leaves. Serve with black bean salad on the side.\n\n**Why this works:** Using sparkling water and cornstarch in the batter traps bubbles and reduces gluten formation, resulting in an ultracrisp coating that stays light. Whole-wheat flour adds nuttiness without compromising texture. The acidic mango slaw cuts through fried richness, while chipotle crema provides smoky heat and probiotic benefits from yoghurt.\n\n**Plating & Pairing:** Serve tacos family-style on a platter with extra lime wedges. Pair with a light lager or a chilled cucumber-lime agua fresca."
    },
    {
      "id": "dark-chocolate-chicha-morada-mousse-with-roasted-pineapple",
      "name": "Dark Chocolate & Chicha Morada Mousse with Roasted Pineapple",
      "cuisine": "Peruvian",
      "servings": "4",
      "activeTime": "30 min",
      "totalTime": "2 h (includes chilling)",
      "miseEnPlace": [
        "Station A - Chicha reduction: Simmer 500 ml purple corn chicha (made by boiling purple corn, pineapple rind, cinnamon and clove) until reduced to 150 ml; strain.",
        "Station B - Mousse: Separate 4 eggs; chop 150 g 70 % dark chocolate; measure 50 g honey, 200 ml heavy cream.",
        "Station C - Pineapple: Peel and core ½ pineapple (300 g); cut into 2 cm cubes. Toss with 10 g coconut sugar and 5 ml lime juice."
      ],
      "ingredients": [
        "150 g dark chocolate (70 %), 4 eggs separated, 50 g honey, 150 ml chicha morada reduction, 200 ml heavy cream, pinch of salt.",
        "Roasted pineapple: 300 g pineapple cubes, 10 g coconut sugar, 5 ml lime juice."
      ],
      "method": [
        "Make mousse base: Melt dark chocolate in a heatproof bowl over a bain-marie. Remove from heat; stir in honey and chicha reduction until smooth. Allow to cool slightly. Whisk in egg yolks one at a time.",
        "Whip egg whites: In a clean bowl, whip egg whites with a pinch of salt to soft peaks. In a separate bowl, whip cream to soft peaks.",
        "Fold: Fold egg whites into the chocolate base in two additions, keeping as much air as possible. Gently fold in whipped cream. Divide among glasses and chill for at least 90 min.",
        "Roast pineapple: Spread pineapple on a lined baking sheet; sprinkle with coconut sugar and lime juice. Roast at 200 °C for 15 min until caramelised. Cool.",
        "Serve: Top each mousse with warm roasted pineapple and drizzle of extra chicha reduction."
      ],
      "whyThisWorks": "The combination of whipped egg whites and cream aerates the chocolate base without the need for gelatin. Reducing chicha morada intensifies its fruity, spiced flavours while providing natural sweetness and anthocyanins. Roasting pineapple caramelises natural sugars, creating contrast in texture and temperature.",
      "plating": "Serve in chilled glass cups to showcase layers. Garnish with a sprig of mint. Pair with a demi-sec sparkling wine or a chilled hibiscus infusion with orange peel.",
      "fullMarkdown": "## Dark Chocolate & Chicha Morada Mousse with Roasted Pineapple (Peruvian)\n\n**Servings:** 4 **Active time:** 30 min **Total time:** 2 h (includes chilling)\n\n**Mise en place (≈20 min)**\n- **Station A - Chicha reduction:** Simmer 500 ml purple corn chicha (made by boiling purple corn, pineapple rind, cinnamon and clove) until reduced to 150 ml; strain.\n- **Station B - Mousse:** Separate 4 eggs; chop 150 g 70 % dark chocolate; measure 50 g honey, 200 ml heavy cream.\n- **Station C - Pineapple:** Peel and core ½ pineapple (300 g); cut into 2 cm cubes. Toss with 10 g coconut sugar and 5 ml lime juice.\n\n**Ingredients**\n- 150 g dark chocolate (70 %), 4 eggs separated, 50 g honey, 150 ml chicha morada reduction, 200 ml heavy cream, pinch of salt.\n- Roasted pineapple: 300 g pineapple cubes, 10 g coconut sugar, 5 ml lime juice.\n\n**Method**\n1. **Make mousse base:** Melt dark chocolate in a heatproof bowl over a bain-marie. Remove from heat; stir in honey and chicha reduction until smooth. Allow to cool slightly. Whisk in egg yolks one at a time.\n2. **Whip egg whites:** In a clean bowl, whip egg whites with a pinch of salt to soft peaks. In a separate bowl, whip cream to soft peaks.\n3. **Fold:** Fold egg whites into the chocolate base in two additions, keeping as much air as possible. Gently fold in whipped cream. Divide among glasses and chill for at least 90 min.\n4. **Roast pineapple:** Spread pineapple on a lined baking sheet; sprinkle with coconut sugar and lime juice. Roast at 200 °C for 15 min until caramelised. Cool.\n5. **Serve:** Top each mousse with warm roasted pineapple and drizzle of extra chicha reduction.\n\n**Why this works:** The combination of whipped egg whites and cream aerates the chocolate base without the need for gelatin. Reducing chicha morada intensifies its fruity, spiced flavours while providing natural sweetness and anthocyanins. Roasting pineapple caramelises natural sugars, creating contrast in texture and temperature.\n\n**Plating & Pairing:** Serve in chilled glass cups to showcase layers. Garnish with a sprig of mint. Pair with a demi-sec sparkling wine or a chilled hibiscus infusion with orange peel."
    },
    {
      "id": "deconstructed-acevichado-cod-with-quinoa-crust-aji-emulsion",
      "name": "Deconstructed Acevichado Cod with Quinoa Crust & Aji Emulsion",
      "cuisine": "Nikkei",
      "servings": "4",
      "activeTime": "1 h",
      "totalTime": "1 h 30 min",
      "miseEnPlace": [
        "Station A - Fish & crust: Portion 4 black cod fillets (150 g each); season with salt and refrigerate. Cook 100 g quinoa in 200 ml water until just tender; drain and dry on a towel. Crush 20 g nori sheets into flakes.",
        "Station B - Pickles & garnish: Thinly slice 1 red onion and 1 cucumber; marinate in 30 ml rice vinegar, 5 ml honey and pinch salt. Dice 1 avocado; keep with lime juice.",
        "Station C - Emulsion: Blend 2 egg yolks with 50 ml lime juice, 30 ml fish stock and 50 g aji amarillo paste; slowly emulsify 120 ml olive oil."
      ],
      "ingredients": [
        "4 black cod fillets (≈150 g each), 100 g quinoa, 20 g nori, 1 egg white, 30 ml soy sauce.",
        "Pickled onion & cucumber: 1 red onion, 1 cucumber, 30 ml rice vinegar, 5 ml honey, pinch salt.",
        "Aji emulsion: 2 egg yolks, 50 ml lime juice, 30 ml fish stock, 50 g aji amarillo paste, 120 ml olive oil, salt.",
        "Avocado puree: 1 ripe avocado, 10 ml lime juice, salt.",
        "Garnish: micro-coriander, sesame seeds."
      ],
      "method": [
        "Make quinoa crust: Spread cooked quinoa on a baking sheet and dehydrate in a 100 °C oven for 30 min until dry. Mix with crumbled nori and a pinch of salt. Brush cod fillets with beaten egg white and press onto quinoa mixture to form a crust.",
        "Sear fish: Heat a non-stick pan with 2 tbsp neutral oil. Place cod crust-side down and cook on medium heat until crust is golden and crisp (≈4 min). Transfer to a baking tray and finish in a 180 °C oven for 6-8 min until fish flakes easily.",
        "Make emulsion: In a blender, combine egg yolks, lime juice, fish stock and aji amarillo paste. With motor running, slowly drizzle in olive oil to create a thick emulsion. Season with salt.",
        "Assemble: Spread a swipe of avocado purée on each plate. Arrange cod fillet atop, crust side up. Scatter pickled onion and cucumber around, along with avocado cubes. Drizzle with aji emulsion and soy sauce drops. Sprinkle sesame seeds and micro-corinander."
      ],
      "whyThisWorks": "Dehydrating quinoa yields a crispy coating that echoes the crunch of tempura while providing whole-grain fibre. Cod’s high oil content prevents it from drying out during searing and roasting. Emulsifying lime juice and aji amarillo with egg yolks produces a tangy, spicy sauce reminiscent of acevichado without the raw fish.",
      "plating": "Plate with negative space for a refined look. Pair with a dry Riesling or a yuzu-sparkling water.",
      "fullMarkdown": "## Deconstructed Acevichado Cod with Quinoa Crust & Aji Emulsion (Nikkei)\n\n**Servings:** 4 **Active time:** 1 h **Total time:** 1 h 30 min\n\n**Mise en place (≈30 min)**\n- **Station A - Fish & crust:** Portion 4 black cod fillets (150 g each); season with salt and refrigerate. Cook 100 g quinoa in 200 ml water until just tender; drain and dry on a towel. Crush 20 g nori sheets into flakes.\n- **Station B - Pickles & garnish:** Thinly slice 1 red onion and 1 cucumber; marinate in 30 ml rice vinegar, 5 ml honey and pinch salt. Dice 1 avocado; keep with lime juice.\n- **Station C - Emulsion:** Blend 2 egg yolks with 50 ml lime juice, 30 ml fish stock and 50 g aji amarillo paste; slowly emulsify 120 ml olive oil.\n\n**Ingredients**\n- 4 black cod fillets (≈150 g each), 100 g quinoa, 20 g nori, 1 egg white, 30 ml soy sauce.\n- Pickled onion & cucumber: 1 red onion, 1 cucumber, 30 ml rice vinegar, 5 ml honey, pinch salt.\n- Aji emulsion: 2 egg yolks, 50 ml lime juice, 30 ml fish stock, 50 g aji amarillo paste, 120 ml olive oil, salt.\n- Avocado puree: 1 ripe avocado, 10 ml lime juice, salt.\n- Garnish: micro-coriander, sesame seeds.\n\n**Method**\n1. **Make quinoa crust:** Spread cooked quinoa on a baking sheet and dehydrate in a 100 °C oven for 30 min until dry. Mix with crumbled nori and a pinch of salt. Brush cod fillets with beaten egg white and press onto quinoa mixture to form a crust.\n2. **Sear fish:** Heat a non-stick pan with 2 tbsp neutral oil. Place cod crust-side down and cook on medium heat until crust is golden and crisp (≈4 min). Transfer to a baking tray and finish in a 180 °C oven for 6-8 min until fish flakes easily.\n3. **Make emulsion:** In a blender, combine egg yolks, lime juice, fish stock and aji amarillo paste. With motor running, slowly drizzle in olive oil to create a thick emulsion. Season with salt.\n4. **Assemble:** Spread a swipe of avocado purée on each plate. Arrange cod fillet atop, crust side up. Scatter pickled onion and cucumber around, along with avocado cubes. Drizzle with aji emulsion and soy sauce drops. Sprinkle sesame seeds and micro-corinander.\n\n**Why this works:** Dehydrating quinoa yields a crispy coating that echoes the crunch of tempura while providing whole-grain fibre. Cod’s high oil content prevents it from drying out during searing and roasting. Emulsifying lime juice and aji amarillo with egg yolks produces a tangy, spicy sauce reminiscent of acevichado without the raw fish.\n\n**Plating & Pairing:** Plate with negative space for a refined look. Pair with a dry Riesling or a yuzu-sparkling water."
    },
    {
      "id": "elote-style-corn-ribs",
      "name": "Elote-Style Corn Ribs",
      "cuisine": "Mexican",
      "servings": "4",
      "activeTime": "20 min",
      "totalTime": "40 min",
      "miseEnPlace": [
        "Station A - Corn: Quarter 4 ears of corn lengthwise to form “ribs.”",
        "Station B - Seasoning: Mix 30 ml olive oil, 10 g smoked paprika, 5 g cumin, 5 g chili powder, 5 g garlic powder and 5 g salt.",
        "Station C - Sauce & toppings: Blend 100 g Greek yoghurt with 30 g mayo, 1 chipotle chile, 10 ml lime juice and 20 g cilantro; crumble 50 g cotija cheese; chop extra cilantro."
      ],
      "ingredients": [
        "4 ears corn, 30 ml olive oil, 10 g smoked paprika, 5 g cumin, 5 g chili powder, 5 g garlic powder, 5 g salt.",
        "Sauce: 100 g Greek yoghurt, 30 g mayonnaise, 1 chipotle chile, 10 ml lime juice, 20 g cilantro.",
        "Garnish: 50 g cotija cheese, extra cilantro, lime wedges."
      ],
      "method": [
        "Season corn: Toss corn ribs with spice oil mixture until well coated.",
        "Roast or grill: Arrange on a baking sheet and roast at 220 °C for 20 min, turning once, until kernels char and curl slightly. Alternatively, grill over medium-high heat.",
        "Prepare sauce: Blend yoghurt, mayo, chipotle, lime juice and cilantro until smooth; season to taste.",
        "Serve: Drizzle corn ribs with sauce, sprinkle with cotija and cilantro, and serve with lime wedges."
      ],
      "whyThisWorks": "Cutting corn into ribs increases surface area for caramelisation and creates a fun, handheld snack. Roasting at high heat develops charred, sweet notes without deep frying. The yoghurt-mayo sauce provides creaminess while chipotle adds smoky heat.",
      "plating": "Serve on a board lined with parchment. Pair with a light lager or agua de tamarindo.",
      "fullMarkdown": "## Elote-Style Corn Ribs (Mexican)\n\n**Servings:** 4 **Active time:** 20 min **Total time:** 40 min\n\n**Mise en place (≈15 min)**\n- **Station A - Corn:** Quarter 4 ears of corn lengthwise to form “ribs.”\n- **Station B - Seasoning:** Mix 30 ml olive oil, 10 g smoked paprika, 5 g cumin, 5 g chili powder, 5 g garlic powder and 5 g salt.\n- **Station C - Sauce & toppings:** Blend 100 g Greek yoghurt with 30 g mayo, 1 chipotle chile, 10 ml lime juice and 20 g cilantro; crumble 50 g cotija cheese; chop extra cilantro.\n\n**Ingredients**\n- 4 ears corn, 30 ml olive oil, 10 g smoked paprika, 5 g cumin, 5 g chili powder, 5 g garlic powder, 5 g salt.\n- Sauce: 100 g Greek yoghurt, 30 g mayonnaise, 1 chipotle chile, 10 ml lime juice, 20 g cilantro.\n- Garnish: 50 g cotija cheese, extra cilantro, lime wedges.\n\n**Method**\n1. **Season corn:** Toss corn ribs with spice oil mixture until well coated.\n2. **Roast or grill:** Arrange on a baking sheet and roast at 220 °C for 20 min, turning once, until kernels char and curl slightly. Alternatively, grill over medium-high heat.\n3. **Prepare sauce:** Blend yoghurt, mayo, chipotle, lime juice and cilantro until smooth; season to taste.\n4. **Serve:** Drizzle corn ribs with sauce, sprinkle with cotija and cilantro, and serve with lime wedges.\n\n**Why this works:** Cutting corn into ribs increases surface area for caramelisation and creates a fun, handheld snack. Roasting at high heat develops charred, sweet notes without deep frying. The yoghurt-mayo sauce provides creaminess while chipotle adds smoky heat.\n\n**Plating & Pairing:** Serve on a board lined with parchment. Pair with a light lager or agua de tamarindo."
    },
    {
      "id": "grilled-chicken-parmigiana-with-aji-verde-quinoa-salad",
      "name": "Grilled Chicken Parmigiana with Aji Verde & Quinoa Salad",
      "cuisine": "Italian × Peruvian",
      "servings": "4",
      "activeTime": "45 min",
      "totalTime": "1 h 15 min",
      "miseEnPlace": [
        "Station A - Chicken: Pound 4 free-range chicken breasts (150 g each) to 1 cm thickness. Prepare breading station: 100 g almond meal mixed with 50 g whole-wheat breadcrumbs and 10 g grated Parmesan; beat 2 eggs; measure 50 g flour seasoned with salt and pepper.",
        "Station B - Sauce: Simmer 500 g crushed San Marzano tomatoes with 2 minced garlic cloves, 5 ml olive oil, 5 g dried oregano, and 5 g sugar until thickened.",
        "Station C - Aji verde: Blend 50 g cilantro, 1 jalapeño, 1 garlic clove, 30 ml lime juice, 50 g Greek yoghurt, 30 ml olive oil and 5 g salt until smooth.",
        "Station D - Quinoa salad: Cook 200 g quinoa in 400 ml water; dice 1 cucumber, 1 bell pepper, 1 avocado; chop 20 g mint."
      ],
      "ingredients": [
        "4 chicken breasts (600 g total), 50 g flour, 2 eggs, 100 g almond meal, 50 g whole-wheat breadcrumbs, 10 g Parmesan, 500 g crushed tomatoes, garlic, oregano, sugar, 150 g fresh mozzarella, olive oil.",
        "Aji verde: 50 g cilantro, 1 jalapeño, 1 garlic clove, 30 ml lime juice, 50 g Greek yoghurt, 30 ml olive oil, salt.",
        "Quinoa salad: 200 g quinoa, 1 cucumber, 1 bell pepper, 1 avocado, 20 g mint, 30 ml lemon juice, 15 ml olive oil."
      ],
      "method": [
        "Prepare sauce: Simmer tomatoes with garlic, oregano and sugar for 20 min until rich; season with salt and pepper.",
        "Bread chicken: Dredge pounded chicken in flour, dip in egg, then coat with almond-breadcrumb mixture. Drizzle with olive oil.",
        "Bake or air-fry: Arrange breaded chicken on a rack and bake at 200 °C for 15 min or air-fry until crisp and cooked through. Top each cutlet with spoonful of tomato sauce and slice of mozzarella; return to oven for 5 min to melt.",
        "Make aji verde: Blend all sauce ingredients until smooth and vibrant green.",
        "Quinoa salad: Fluff cooked quinoa and toss with diced cucumber, bell pepper, avocado, mint, lemon juice and olive oil; season.",
        "Serve: Plate chicken parmigiana on quinoa salad; drizzle with aji verde."
      ],
      "whyThisWorks": "Using almond meal and whole-wheat breadcrumbs reduces refined grains and increases healthy fats. Baking rather than shallow-frying delivers a crisp crust with less oil. Aji verde provides a tangy herbal counterpoint to the rich tomato and melted cheese.",
      "plating": "Serve on wide plates with salad spread underneath. Pair with a medium-bodied red like Sangiovese or a lime-mint sparkling water.",
      "fullMarkdown": "## Grilled Chicken Parmigiana with Aji Verde & Quinoa Salad (Italian × Peruvian)\n\n**Servings:** 4 **Active time:** 45 min **Total time:** 1 h 15 min\n\n**Mise en place (≈25 min)**\n- **Station A - Chicken:** Pound 4 free-range chicken breasts (150 g each) to 1 cm thickness. Prepare breading station: 100 g almond meal mixed with 50 g whole-wheat breadcrumbs and 10 g grated Parmesan; beat 2 eggs; measure 50 g flour seasoned with salt and pepper.\n- **Station B - Sauce:** Simmer 500 g crushed San Marzano tomatoes with 2 minced garlic cloves, 5 ml olive oil, 5 g dried oregano, and 5 g sugar until thickened.\n- **Station C - Aji verde:** Blend 50 g cilantro, 1 jalapeño, 1 garlic clove, 30 ml lime juice, 50 g Greek yoghurt, 30 ml olive oil and 5 g salt until smooth.\n- **Station D - Quinoa salad:** Cook 200 g quinoa in 400 ml water; dice 1 cucumber, 1 bell pepper, 1 avocado; chop 20 g mint.\n\n**Ingredients**\n- 4 chicken breasts (600 g total), 50 g flour, 2 eggs, 100 g almond meal, 50 g whole-wheat breadcrumbs, 10 g Parmesan, 500 g crushed tomatoes, garlic, oregano, sugar, 150 g fresh mozzarella, olive oil.\n- **Aji verde:** 50 g cilantro, 1 jalapeño, 1 garlic clove, 30 ml lime juice, 50 g Greek yoghurt, 30 ml olive oil, salt.\n- **Quinoa salad:** 200 g quinoa, 1 cucumber, 1 bell pepper, 1 avocado, 20 g mint, 30 ml lemon juice, 15 ml olive oil.\n\n**Method**\n1. **Prepare sauce:** Simmer tomatoes with garlic, oregano and sugar for 20 min until rich; season with salt and pepper.\n2. **Bread chicken:** Dredge pounded chicken in flour, dip in egg, then coat with almond-breadcrumb mixture. Drizzle with olive oil.\n3. **Bake or air-fry:** Arrange breaded chicken on a rack and bake at 200 °C for 15 min or air-fry until crisp and cooked through. Top each cutlet with spoonful of tomato sauce and slice of mozzarella; return to oven for 5 min to melt.\n4. **Make aji verde:** Blend all sauce ingredients until smooth and vibrant green.\n5. **Quinoa salad:** Fluff cooked quinoa and toss with diced cucumber, bell pepper, avocado, mint, lemon juice and olive oil; season.\n6. **Serve:** Plate chicken parmigiana on quinoa salad; drizzle with aji verde.\n\n**Why this works:** Using almond meal and whole-wheat breadcrumbs reduces refined grains and increases healthy fats. Baking rather than shallow-frying delivers a crisp crust with less oil. Aji verde provides a tangy herbal counterpoint to the rich tomato and melted cheese.\n\n**Plating & Pairing:** Serve on wide plates with salad spread underneath. Pair with a medium-bodied red like Sangiovese or a lime-mint sparkling water."
    },
    {
      "id": "korean-bulgogi-breakfast-burrito",
      "name": "Korean Bulgogi Breakfast Burrito",
      "cuisine": "Korean × Mexican",
      "servings": "4",
      "activeTime": "35 min",
      "totalTime": "50 min",
      "miseEnPlace": [
        "Station A - Bulgogi: Thinly slice 400 g beef sirloin and marinate with 30 ml soy sauce, 10 g brown sugar, 10 ml sesame oil, 2 g grated ginger, 2 cloves minced garlic, 5 ml rice vinegar and 5 ml gochujang. Rest 20 min.",
        "Station B - Rice & eggs: Cook 200 g brown rice; scramble 4 eggs with 30 ml milk and a pinch of salt.",
        "Station C - Pickles & fillings: Thinly slice 1 cucumber, toss with 10 ml rice vinegar and pinch salt; prepare 100 g kimchi; chop 10 g scallions; warm 4 large whole-wheat tortillas."
      ],
      "ingredients": [
        "400 g beef sirloin, 30 ml soy sauce, 10 g brown sugar or coconut sugar, 10 ml sesame oil, ginger, garlic, 5 ml rice vinegar, 5 ml gochujang.",
        "200 g brown rice, 4 eggs, 30 ml milk, 100 g kimchi, 1 cucumber, 10 ml rice vinegar, 10 g scallions, 4 whole-wheat tortillas, sesame seeds."
      ],
      "method": [
        "Cook bulgogi: Heat a skillet until hot. Sear marinated beef in batches for 2 min until caramelised; the sugar in the marinade will help develop a glaze. Set aside.",
        "Scramble eggs: In the same pan, add a knob of butter and cook beaten eggs gently until just set; season.",
        "Assemble burritos: Lay tortillas on a board. Divide rice down the centre of each, top with bulgogi, scrambled eggs, kimchi, cucumber pickles and scallions. Sprinkle with sesame seeds and extra gochujang if desired.",
        "Roll & sear: Fold sides in and roll tightly. Sear seam-side down in a hot dry pan for 1 min to seal."
      ],
      "whyThisWorks": "Marinating thinly sliced beef with soy, sugar and gochujang tenderises the meat and builds caramelisation. Whole-wheat tortillas and brown rice provide fibre. Incorporating kimchi and pickled cucumber adds fermentation acids to balance the rich beef and eggs.",
      "plating": "Serve halved burritos with a side of sliced avocado. Pair with a lightly sweet cold brew tea or a session ale.",
      "fullMarkdown": "## Korean Bulgogi Breakfast Burrito (Korean × Mexican)\n\n**Servings:** 4 **Active time:** 35 min **Total time:** 50 min\n\n**Mise en place (≈20 min)**\n- **Station A - Bulgogi:** Thinly slice 400 g beef sirloin and marinate with 30 ml soy sauce, 10 g brown sugar, 10 ml sesame oil, 2 g grated ginger, 2 cloves minced garlic, 5 ml rice vinegar and 5 ml gochujang. Rest 20 min.\n- **Station B - Rice & eggs:** Cook 200 g brown rice; scramble 4 eggs with 30 ml milk and a pinch of salt.\n- **Station C - Pickles & fillings:** Thinly slice 1 cucumber, toss with 10 ml rice vinegar and pinch salt; prepare 100 g kimchi; chop 10 g scallions; warm 4 large whole-wheat tortillas.\n\n**Ingredients**\n- 400 g beef sirloin, 30 ml soy sauce, 10 g brown sugar or coconut sugar, 10 ml sesame oil, ginger, garlic, 5 ml rice vinegar, 5 ml gochujang.\n- 200 g brown rice, 4 eggs, 30 ml milk, 100 g kimchi, 1 cucumber, 10 ml rice vinegar, 10 g scallions, 4 whole-wheat tortillas, sesame seeds.\n\n**Method**\n1. **Cook bulgogi:** Heat a skillet until hot. Sear marinated beef in batches for 2 min until caramelised; the sugar in the marinade will help develop a glaze. Set aside.\n2. **Scramble eggs:** In the same pan, add a knob of butter and cook beaten eggs gently until just set; season.\n3. **Assemble burritos:** Lay tortillas on a board. Divide rice down the centre of each, top with bulgogi, scrambled eggs, kimchi, cucumber pickles and scallions. Sprinkle with sesame seeds and extra gochujang if desired.\n4. **Roll & sear:** Fold sides in and roll tightly. Sear seam-side down in a hot dry pan for 1 min to seal.\n\n**Why this works:** Marinating thinly sliced beef with soy, sugar and gochujang tenderises the meat and builds caramelisation. Whole-wheat tortillas and brown rice provide fibre. Incorporating kimchi and pickled cucumber adds fermentation acids to balance the rich beef and eggs.\n\n**Plating & Pairing:** Serve halved burritos with a side of sliced avocado. Pair with a lightly sweet cold brew tea or a session ale."
    },
    {
      "id": "lucuma-tiramisu",
      "name": "Lucuma Tiramisu",
      "cuisine": "Italian × Peruvian",
      "servings": "4",
      "activeTime": "45 min",
      "totalTime": "4 h (includes chilling)",
      "miseEnPlace": [
        "Station A - Ladyfingers: Prepare a batter with 3 eggs (separated), 80 g raw sugar, 75 g whole-wheat pastry flour and 5 g baking powder. Pipe onto a parchment sheet into finger shapes and bake at 180 °C for 10 min until just set.",
        "Station B - Lucuma cream: Whisk 3 egg yolks with 80 g honey over a bain-marie until pale. Beat in 250 g mascarpone and 100 g lucuma purée until smooth.",
        "Station C - Espresso soak: Brew 200 ml strong espresso; stir in 20 ml Marsala wine (optional) or almond extract. Allow to cool."
      ],
      "ingredients": [
        "Ladyfingers: 3 eggs, 80 g raw sugar, 75 g whole-wheat pastry flour, 5 g baking powder.",
        "Lucuma cream: 3 egg yolks, 80 g honey, 250 g mascarpone, 100 g lucuma purée (Peruvian fruit), pinch salt.",
        "Espresso soak: 200 ml espresso, 20 ml Marsala wine or 5 ml almond extract.",
        "Topping: 30 g dark cocoa powder, shaved dark chocolate."
      ],
      "method": [
        "Bake ladyfingers: Beat egg whites to stiff peaks; gradually add half the sugar. In another bowl, beat yolks with remaining sugar until pale. Fold in flour and baking powder, then fold in meringue. Pipe into fingers and bake until lightly golden. Cool.",
        "Make lucuma cream: Cook yolks and honey over a gentle bain-marie until thick ribbons form. Cool slightly, then fold in mascarpone and lucuma purée until smooth.",
        "Assemble tiramisu: Dip ladyfingers briefly into cooled espresso soak and arrange a single layer in a glass dish. Spread half the lucuma cream over. Repeat with another layer. Smooth the top and chill at least 3 h.",
        "Finish: Dust with cocoa powder and garnish with shaved dark chocolate just before serving."
      ],
      "whyThisWorks": "Whole-wheat ladyfingers retain lightness due to whipped egg whites yet add fibre. Lucuma purée lends natural sweetness and caramel notes that pair beautifully with mascarpone, reducing the need for refined sugar. Honey-cooked yolks provide safe, stable richness.",
      "plating": "Cut into squares and serve with espresso. Pair with a glass of Vin Santo or an almond-milk cortado.",
      "fullMarkdown": "## Lucuma Tiramisu (Italian × Peruvian)\n\n**Servings:** 4 **Active time:** 45 min **Total time:** 4 h (includes chilling)\n\n**Mise en place (≈30 min)**\n- **Station A - Ladyfingers:** Prepare a batter with 3 eggs (separated), 80 g raw sugar, 75 g whole-wheat pastry flour and 5 g baking powder. Pipe onto a parchment sheet into finger shapes and bake at 180 °C for 10 min until just set.\n- **Station B - Lucuma cream:** Whisk 3 egg yolks with 80 g honey over a bain-marie until pale. Beat in 250 g mascarpone and 100 g lucuma purée until smooth.\n- **Station C - Espresso soak:** Brew 200 ml strong espresso; stir in 20 ml Marsala wine (optional) or almond extract. Allow to cool.\n\n**Ingredients**\n- **Ladyfingers:** 3 eggs, 80 g raw sugar, 75 g whole-wheat pastry flour, 5 g baking powder.\n- **Lucuma cream:** 3 egg yolks, 80 g honey, 250 g mascarpone, 100 g lucuma purée (Peruvian fruit), pinch salt.\n- **Espresso soak:** 200 ml espresso, 20 ml Marsala wine or 5 ml almond extract.\n- **Topping:** 30 g dark cocoa powder, shaved dark chocolate.\n\n**Method**\n1. **Bake ladyfingers:** Beat egg whites to stiff peaks; gradually add half the sugar. In another bowl, beat yolks with remaining sugar until pale. Fold in flour and baking powder, then fold in meringue. Pipe into fingers and bake until lightly golden. Cool.\n2. **Make lucuma cream:** Cook yolks and honey over a gentle bain-marie until thick ribbons form. Cool slightly, then fold in mascarpone and lucuma purée until smooth.\n3. **Assemble tiramisu:** Dip ladyfingers briefly into cooled espresso soak and arrange a single layer in a glass dish. Spread half the lucuma cream over. Repeat with another layer. Smooth the top and chill at least 3 h.\n4. **Finish:** Dust with cocoa powder and garnish with shaved dark chocolate just before serving.\n\n**Why this works:** Whole-wheat ladyfingers retain lightness due to whipped egg whites yet add fibre. Lucuma purée lends natural sweetness and caramel notes that pair beautifully with mascarpone, reducing the need for refined sugar. Honey-cooked yolks provide safe, stable richness.\n\n**Plating & Pairing:** Cut into squares and serve with espresso. Pair with a glass of Vin Santo or an almond-milk cortado."
    },
    {
      "id": "mapo-tofu-with-quinoa-sichuan-peanuts",
      "name": "Mapo Tofu with Quinoa & Sichuan Peanuts",
      "cuisine": "Chinese × Peruvian",
      "servings": "4",
      "activeTime": "30 min",
      "totalTime": "45 min",
      "miseEnPlace": [
        "Station A - Quinoa: Rinse 240 g quinoa; cook in 480 ml water until fluffy; keep warm.",
        "Station B - Tofu & turkey: Drain and cube 400 g firm tofu; mince 250 g turkey thigh. Chop 4 garlic cloves, 20 g ginger and 2 scallions; measure 30 g doubanjiang (fermented broad bean paste), 5 ml soy sauce and 5 ml rice wine.",
        "Station C - Sichuan pepper oil: Toast 5 g Sichuan peppercorns and 5 g chili flakes in 30 ml oil until fragrant; strain."
      ],
      "ingredients": [
        "400 g firm tofu, 250 g ground turkey, 240 g quinoa, 4 garlic cloves, 20 g ginger, 2 scallions, 30 g doubanjiang, 15 ml soy sauce, 5 ml Shaoxing wine or rice wine, 200 ml chicken stock, 5 g cornstarch mixed with 30 ml water, 30 ml Sichuan pepper-chili oil, 30 g roasted peanuts, 10 ml sesame oil."
      ],
      "method": [
        "Sauté aromatics: In a wok, heat 15 ml oil; add garlic, ginger and whites of scallions; stir-fry until fragrant. Add minced turkey; cook until browned.",
        "Build sauce: Stir in doubanjiang and soy sauce; fry 1 min to release oils. Pour in stock and Shaoxing wine; bring to a simmer.",
        "Add tofu: Gently slide in tofu cubes; simmer 5 min to absorb flavours.",
        "Thicken: Stir cornstarch slurry into the sauce and simmer until glossy. Drizzle with Sichuan pepper oil and sesame oil.",
        "Serve: Spoon mapo tofu over quinoa. Sprinkle with chopped peanuts and green parts of scallions."
      ],
      "whyThisWorks": "Combining tofu with lean turkey increases protein diversity. Doubanjiang provides deep umami and heat, while Sichuan pepper oil contributes numbing spice. Quinoa soaks up the spicy sauce and offers a whole-grain alternative to rice.",
      "plating": "Serve in shallow bowls with a cool cucumber salad. Pair with off-dry Gewürztraminer or jasmine tea.",
      "fullMarkdown": "## Mapo Tofu with Quinoa & Sichuan Peanuts (Chinese × Peruvian)\n\n**Servings:** 4 **Active time:** 30 min **Total time:** 45 min\n\n**Mise en place (≈15 min)**\n- **Station A - Quinoa:** Rinse 240 g quinoa; cook in 480 ml water until fluffy; keep warm.\n- **Station B - Tofu & turkey:** Drain and cube 400 g firm tofu; mince 250 g turkey thigh. Chop 4 garlic cloves, 20 g ginger and 2 scallions; measure 30 g doubanjiang (fermented broad bean paste), 5 ml soy sauce and 5 ml rice wine.\n- **Station C - Sichuan pepper oil:** Toast 5 g Sichuan peppercorns and 5 g chili flakes in 30 ml oil until fragrant; strain.\n\n**Ingredients**\n- 400 g firm tofu, 250 g ground turkey, 240 g quinoa, 4 garlic cloves, 20 g ginger, 2 scallions, 30 g doubanjiang, 15 ml soy sauce, 5 ml Shaoxing wine or rice wine, 200 ml chicken stock, 5 g cornstarch mixed with 30 ml water, 30 ml Sichuan pepper-chili oil, 30 g roasted peanuts, 10 ml sesame oil.\n\n**Method**\n1. **Sauté aromatics:** In a wok, heat 15 ml oil; add garlic, ginger and whites of scallions; stir-fry until fragrant. Add minced turkey; cook until browned.\n2. **Build sauce:** Stir in doubanjiang and soy sauce; fry 1 min to release oils. Pour in stock and Shaoxing wine; bring to a simmer.\n3. **Add tofu:** Gently slide in tofu cubes; simmer 5 min to absorb flavours.\n4. **Thicken:** Stir cornstarch slurry into the sauce and simmer until glossy. Drizzle with Sichuan pepper oil and sesame oil.\n5. **Serve:** Spoon mapo tofu over quinoa. Sprinkle with chopped peanuts and green parts of scallions.\n\n**Why this works:** Combining tofu with lean turkey increases protein diversity. Doubanjiang provides deep umami and heat, while Sichuan pepper oil contributes numbing spice. Quinoa soaks up the spicy sauce and offers a whole-grain alternative to rice.\n\n**Plating & Pairing:** Serve in shallow bowls with a cool cucumber salad. Pair with off-dry Gewürztraminer or jasmine tea."
    },
    {
      "id": "miso-glazed-salmon-bowl-with-brown-rice-sesame-kale",
      "name": "Miso-Glazed Salmon Bowl with Brown Rice & Sesame Kale",
      "cuisine": "Japanese",
      "servings": "4",
      "activeTime": "35 min",
      "totalTime": "50 min",
      "miseEnPlace": [
        "Station A - Rice: Cook 300 g brown rice in 600 ml water until tender; keep warm.",
        "Station B - Salmon: Mix glaze: 40 g white miso, 20 g honey, 10 ml mirin (or extra honey), 10 ml soy sauce. Portion 4 salmon fillets (180 g each) and brush with glaze; marinate 15 min.",
        "Station C - Kale & toppings: Destem 200 g kale; slice into ribbons. Julienne 1 cucumber, slice 1 avocado, cook 200 g edamame. Toast 20 g sesame seeds."
      ],
      "ingredients": [
        "4 salmon fillets (≈720 g), 40 g white miso, 20 g honey, 10 ml mirin, 10 ml soy sauce, 300 g brown rice, 200 g kale, 1 cucumber, 1 avocado, 200 g edamame, 20 g sesame seeds, 30 ml rice vinegar, 5 ml sesame oil."
      ],
      "method": [
        "Cook rice: Simmer brown rice until fluffy; season with a pinch of salt and 15 ml rice vinegar.",
        "Roast salmon: Preheat oven to 200 °C. Place glazed salmon on a parchment-lined tray; bake 10-12 min until just opaque. Broil for 1 min to caramelise the glaze.",
        "Sauté kale: Heat 5 ml sesame oil in a pan; sauté kale until just wilted; season with salt.",
        "Assemble bowls: Divide rice among bowls. Top with roasted salmon, sautéed kale, cucumber, avocado slices and edamame. Sprinkle with sesame seeds. Drizzle with remaining glaze diluted with 20 ml water as a sauce."
      ],
      "whyThisWorks": "Miso’s glutamates create deep umami; honey and mirin help caramelise the glaze. Brown rice offers chewiness and fibre. Quick sautéing retains kale’s nutrients, while edamame adds plant protein.",
      "plating": "Serve with chopsticks. Pair with a chilled sake or green tea with jasmine.",
      "fullMarkdown": "## Miso-Glazed Salmon Bowl with Brown Rice & Sesame Kale (Japanese)\n\n**Servings:** 4 **Active time:** 35 min **Total time:** 50 min\n\n**Mise en place (≈20 min)**\n- **Station A - Rice:** Cook 300 g brown rice in 600 ml water until tender; keep warm.\n- **Station B - Salmon:** Mix glaze: 40 g white miso, 20 g honey, 10 ml mirin (or extra honey), 10 ml soy sauce. Portion 4 salmon fillets (180 g each) and brush with glaze; marinate 15 min.\n- **Station C - Kale & toppings:** Destem 200 g kale; slice into ribbons. Julienne 1 cucumber, slice 1 avocado, cook 200 g edamame. Toast 20 g sesame seeds.\n\n**Ingredients**\n- 4 salmon fillets (≈720 g), 40 g white miso, 20 g honey, 10 ml mirin, 10 ml soy sauce, 300 g brown rice, 200 g kale, 1 cucumber, 1 avocado, 200 g edamame, 20 g sesame seeds, 30 ml rice vinegar, 5 ml sesame oil.\n\n**Method**\n1. **Cook rice:** Simmer brown rice until fluffy; season with a pinch of salt and 15 ml rice vinegar.\n2. **Roast salmon:** Preheat oven to 200 °C. Place glazed salmon on a parchment-lined tray; bake 10-12 min until just opaque. Broil for 1 min to caramelise the glaze.\n3. **Sauté kale:** Heat 5 ml sesame oil in a pan; sauté kale until just wilted; season with salt.\n4. **Assemble bowls:** Divide rice among bowls. Top with roasted salmon, sautéed kale, cucumber, avocado slices and edamame. Sprinkle with sesame seeds. Drizzle with remaining glaze diluted with 20 ml water as a sauce.\n\n**Why this works:** Miso’s glutamates create deep umami; honey and mirin help caramelise the glaze. Brown rice offers chewiness and fibre. Quick sautéing retains kale’s nutrients, while edamame adds plant protein.\n\n**Plating & Pairing:** Serve with chopsticks. Pair with a chilled sake or green tea with jasmine."
    },
    {
      "id": "nikkei-quinoa-acevichado-salad",
      "name": "Nikkei Quinoa Acevichado Salad",
      "cuisine": "Peruvian × Japanese",
      "servings": "4",
      "activeTime": "25 min",
      "totalTime": "40 min",
      "miseEnPlace": [
        "Station A - Quinoa: Rinse 200 g red quinoa and cook in 400 ml water until fluffy.",
        "Station B - Fish & dressing: Slice 200 g sushi-grade salmon or tuna into thin sashimi strips; juice 4 limes (80 ml); blend 30 ml aji amarillo paste, 5 g grated ginger, 1 garlic clove and 5 g salt.",
        "Station C - Vegetables: Julienne 1 avocado, 1 cucumber and ½ red onion; chop 50 g fresh cilantro."
      ],
      "ingredients": [
        "200 g red quinoa, 200 g sashimi-grade salmon or tuna, 80 ml lime juice, 30 ml aji amarillo paste, 10 ml soy sauce, 5 g grated ginger, 1 garlic clove, 1 avocado, 1 cucumber, ½ red onion, 50 g cilantro, 30 g toasted corn nuts or cancha serrana, 10 ml olive oil, salt."
      ],
      "method": [
        "Prepare quinoa: Cook quinoa until tender; spread on a tray to cool.",
        "Make dressing: Blend lime juice, aji amarillo, ginger, garlic, soy sauce and olive oil until emulsified. Season to taste.",
        "Assemble salad: In a bowl, toss cooled quinoa with avocado, cucumber, red onion and cilantro. Add fish slices and gently mix with dressing. Top with toasted corn nuts for crunch."
      ],
      "whyThisWorks": "Using quinoa instead of rice increases protein and fibre. The acidic, spicy dressing “cooks” the sashimi lightly, akin to ceviche, while soy and aji amarillo provide Nikkei flavour. Cancha adds a nutty crunch reminiscent of tempura bits.",
      "plating": "Serve in shallow bowls or mould into ring forms. Pair with a citrus-driven Sauvignon Blanc or a chilled pisco sour made with egg white and minimal sugar.",
      "fullMarkdown": "## Nikkei Quinoa Acevichado Salad (Peruvian × Japanese)\n\n**Servings:** 4 **Active time:** 25 min **Total time:** 40 min\n\n**Mise en place (≈15 min)**\n- **Station A - Quinoa:** Rinse 200 g red quinoa and cook in 400 ml water until fluffy.\n- **Station B - Fish & dressing:** Slice 200 g sushi-grade salmon or tuna into thin sashimi strips; juice 4 limes (80 ml); blend 30 ml aji amarillo paste, 5 g grated ginger, 1 garlic clove and 5 g salt.\n- **Station C - Vegetables:** Julienne 1 avocado, 1 cucumber and ½ red onion; chop 50 g fresh cilantro.\n\n**Ingredients**\n- 200 g red quinoa, 200 g sashimi-grade salmon or tuna, 80 ml lime juice, 30 ml aji amarillo paste, 10 ml soy sauce, 5 g grated ginger, 1 garlic clove, 1 avocado, 1 cucumber, ½ red onion, 50 g cilantro, 30 g toasted corn nuts or cancha serrana, 10 ml olive oil, salt.\n\n**Method**\n1. **Prepare quinoa:** Cook quinoa until tender; spread on a tray to cool.\n2. **Make dressing:** Blend lime juice, aji amarillo, ginger, garlic, soy sauce and olive oil until emulsified. Season to taste.\n3. **Assemble salad:** In a bowl, toss cooled quinoa with avocado, cucumber, red onion and cilantro. Add fish slices and gently mix with dressing. Top with toasted corn nuts for crunch.\n\n**Why this works:** Using quinoa instead of rice increases protein and fibre. The acidic, spicy dressing “cooks” the sashimi lightly, akin to ceviche, while soy and aji amarillo provide Nikkei flavour. Cancha adds a nutty crunch reminiscent of tempura bits.\n\n**Plating & Pairing:** Serve in shallow bowls or mould into ring forms. Pair with a citrus-driven Sauvignon Blanc or a chilled pisco sour made with egg white and minimal sugar."
    },
    {
      "id": "parmesan-reggiano-crisps-with-aji-amarillo-aioli",
      "name": "Parmesan-Reggiano Crisps with Aji Amarillo Aioli",
      "cuisine": "Italian × Peruvian",
      "servings": "4 (snack)",
      "activeTime": "15 min",
      "totalTime": "30 min",
      "miseEnPlace": [
        "Station A - Crisps: Finely grate 100 g Parmigiano-Reggiano and 50 g aged cheddar; line a baking tray with silicone.",
        "Station B - Aioli: Separate 1 egg yolk; measure 5 ml lemon juice, 5 ml white vinegar, 5 g Dijon mustard, 50 g aji amarillo paste and 100 ml olive oil. Mince 1 garlic clove."
      ],
      "ingredients": [
        "Crisps: 100 g Parmigiano-Reggiano, 50 g aged cheddar, 2 g smoked paprika.",
        "Aji aioli: 1 egg yolk, 5 ml lemon juice, 5 ml white vinegar, 5 g Dijon mustard, 50 g aji amarillo paste, 100 ml olive oil, 1 minced garlic clove, salt."
      ],
      "method": [
        "Bake crisps: Preheat oven to 200 °C. On a silicone-lined sheet, spoon 15 g mounds of cheese mixture, leaving space to spread. Flatten gently and sprinkle with smoked paprika. Bake for 6-8 min until golden and lace-like. Cool completely to crisp.",
        "Make aioli: In a bowl, whisk egg yolk, lemon juice, vinegar and mustard. Slowly drizzle in olive oil while whisking until thick and emulsified. Stir in aji amarillo paste and minced garlic; season.",
        "Serve: Plate crisps with a bowl of aioli for dipping."
      ],
      "whyThisWorks": "Parmesan’s low moisture content melts into lacy crisps that firm up upon cooling. Adding cheddar provides additional sharpness. Making aioli from scratch allows control over oil and eliminates additives; aji amarillo brings floral heat and golden hue.",
      "plating": "Serve as a pre-meal snack with sparkling wine or a chilled lager.",
      "fullMarkdown": "## Parmesan-Reggiano Crisps with Aji Amarillo Aioli (Italian × Peruvian)\n\n**Servings:** 4 (snack) **Active time:** 15 min **Total time:** 30 min\n\n**Mise en place (≈10 min)**\n- **Station A - Crisps:** Finely grate 100 g Parmigiano-Reggiano and 50 g aged cheddar; line a baking tray with silicone.\n- **Station B - Aioli:** Separate 1 egg yolk; measure 5 ml lemon juice, 5 ml white vinegar, 5 g Dijon mustard, 50 g aji amarillo paste and 100 ml olive oil. Mince 1 garlic clove.\n\n**Ingredients**\n- **Crisps:** 100 g Parmigiano-Reggiano, 50 g aged cheddar, 2 g smoked paprika.\n- **Aji aioli:** 1 egg yolk, 5 ml lemon juice, 5 ml white vinegar, 5 g Dijon mustard, 50 g aji amarillo paste, 100 ml olive oil, 1 minced garlic clove, salt.\n\n**Method**\n1. **Bake crisps:** Preheat oven to 200 °C. On a silicone-lined sheet, spoon 15 g mounds of cheese mixture, leaving space to spread. Flatten gently and sprinkle with smoked paprika. Bake for 6-8 min until golden and lace-like. Cool completely to crisp.\n2. **Make aioli:** In a bowl, whisk egg yolk, lemon juice, vinegar and mustard. Slowly drizzle in olive oil while whisking until thick and emulsified. Stir in aji amarillo paste and minced garlic; season.\n3. **Serve:** Plate crisps with a bowl of aioli for dipping.\n\n**Why this works:** Parmesan’s low moisture content melts into lacy crisps that firm up upon cooling. Adding cheddar provides additional sharpness. Making aioli from scratch allows control over oil and eliminates additives; aji amarillo brings floral heat and golden hue.\n\n**Plating & Pairing:** Serve as a pre-meal snack with sparkling wine or a chilled lager."
    },
    {
      "id": "roasted-plantain-chips-with-rocoto-dip",
      "name": "Roasted Plantain Chips with Rocoto Dip",
      "cuisine": "Peruvian",
      "servings": "4",
      "activeTime": "15 min",
      "totalTime": "40 min",
      "miseEnPlace": [
        "Station A - Plantains: Peel 3 green plantains and slice thinly on a mandolin; soak in salted water for 10 min.",
        "Station B - Seasoning: Mix 20 ml olive oil with 5 g cumin, 5 g smoked paprika and 5 g salt.",
        "Station C - Rocoto dip: Blend 1 roasted red pepper, 1 fresh rocoto chile (seeded), 1 garlic clove, 50 g Greek yoghurt, 20 ml olive oil, 10 ml lime juice and salt."
      ],
      "ingredients": [
        "3 green plantains, 20 ml olive oil, 5 g cumin, 5 g smoked paprika, 5 g salt.",
        "Dip: 1 roasted red pepper, 1 rocoto chile, 1 garlic clove, 50 g Greek yoghurt, 20 ml olive oil, 10 ml lime juice, salt."
      ],
      "method": [
        "Prepare chips: Drain plantain slices and pat dry. Toss with spiced oil. Arrange in a single layer on a lined baking sheet. Roast at 200 °C for 20-25 min, flipping halfway, until crisp and golden.",
        "Make dip: Blend roasted pepper, rocoto, garlic, yoghurt, olive oil and lime juice until smooth. Season with salt.",
        "Serve: Serve warm plantain chips with rocoto dip."
      ],
      "whyThisWorks": "Soaking plantains removes excess starch, promoting crispness. Roasting with a thin coating of oil yields chips with a satisfying crunch without deep frying. Rocoto provides fruity heat balanced by creamy yoghurt.",
      "plating": "Serve in a parchment-lined basket with dip on the side. Pair with a pilsner or passion fruit iced tea.",
      "fullMarkdown": "## Roasted Plantain Chips with Rocoto Dip (Peruvian)\n\n**Servings:** 4 **Active time:** 15 min **Total time:** 40 min\n\n**Mise en place (≈10 min)**\n- **Station A - Plantains:** Peel 3 green plantains and slice thinly on a mandolin; soak in salted water for 10 min.\n- **Station B - Seasoning:** Mix 20 ml olive oil with 5 g cumin, 5 g smoked paprika and 5 g salt.\n- **Station C - Rocoto dip:** Blend 1 roasted red pepper, 1 fresh rocoto chile (seeded), 1 garlic clove, 50 g Greek yoghurt, 20 ml olive oil, 10 ml lime juice and salt.\n\n**Ingredients**\n- 3 green plantains, 20 ml olive oil, 5 g cumin, 5 g smoked paprika, 5 g salt.\n- **Dip:** 1 roasted red pepper, 1 rocoto chile, 1 garlic clove, 50 g Greek yoghurt, 20 ml olive oil, 10 ml lime juice, salt.\n\n**Method**\n1. **Prepare chips:** Drain plantain slices and pat dry. Toss with spiced oil. Arrange in a single layer on a lined baking sheet. Roast at 200 °C for 20-25 min, flipping halfway, until crisp and golden.\n2. **Make dip:** Blend roasted pepper, rocoto, garlic, yoghurt, olive oil and lime juice until smooth. Season with salt.\n3. **Serve:** Serve warm plantain chips with rocoto dip.\n\n**Why this works:** Soaking plantains removes excess starch, promoting crispness. Roasting with a thin coating of oil yields chips with a satisfying crunch without deep frying. Rocoto provides fruity heat balanced by creamy yoghurt.\n\n**Plating & Pairing:** Serve in a parchment-lined basket with dip on the side. Pair with a pilsner or passion fruit iced tea."
    },
    {
      "id": "smoked-salmon-avocado-whole-grain-bagel",
      "name": "Smoked Salmon & Avocado Whole-Grain Bagel",
      "cuisine": "American × Peruvian",
      "servings": "4",
      "activeTime": "30 min",
      "totalTime": "3 h (includes proofing)",
      "miseEnPlace": [
        "Station A - Bagels: Mix dough with 250 g whole-wheat flour, 250 g bread flour, 7 g yeast, 10 g barley malt syrup, 300 ml warm water, 10 g salt. Knead and proof 1 h; shape into rings and proof again. Prepare water bath with 20 g baking soda.",
        "Station B - Cure salmon: Rub 400 g salmon fillet with 50 g salt, 50 g sugar and zest of 1 orange; cure 2 h, rinse, pat dry and cold-smoke (or bake at 90 °C until just opaque if no smoker).",
        "Station C - Toppings: Slice 2 avocados thinly, pickle 1 red onion in 30 ml cider vinegar and 5 g sugar, chop fresh dill, mix 200 g cream cheese with 10 g chopped chives."
      ],
      "ingredients": [
        "Bagels: 250 g whole-wheat flour, 250 g bread flour, 7 g yeast, 10 g malt syrup, 300 ml water, 10 g salt, 20 g baking soda for boiling.",
        "Cured salmon: 400 g salmon fillet, 50 g coarse salt, 50 g sugar, zest of 1 orange, fresh dill.",
        "Toppings: 2 avocados, 1 red onion, 30 ml cider vinegar, 5 g sugar, 200 g cream cheese, 10 g chives, fresh dill, lemon wedges."
      ],
      "method": [
        "Make bagels: After second proof, boil bagels in alkaline water for 30 s per side; sprinkle with sesame seeds if desired; bake at 220 °C for 15 min until golden.",
        "Prepare salmon: After curing and rinsing, cold-smoke salmon for 30 min with applewood chips or bake low and slow until barely cooked. Slice thinly.",
        "Assemble: Split bagels and spread with chive cream cheese. Layer with avocado slices, smoked salmon and pickled red onions. Sprinkle with dill and serve with lemon wedges."
      ],
      "whyThisWorks": "Boiling bagels in an alkaline bath gelatinises the exterior starch, creating the characteristic shiny crust. Whole-wheat flour increases fibre yet retains chew. Curing salmon lightly firms the flesh and concentrates flavour; cold smoking adds complexity without cooking.",
      "plating": "Serve open-faced or closed, accompanied by a small side salad of dressed greens. Pair with a crisp rosé or a citrus-infused sparkling water.",
      "fullMarkdown": "## Smoked Salmon & Avocado Whole-Grain Bagel (American × Peruvian)\n\n**Servings:** 4 **Active time:** 30 min **Total time:** 3 h (includes proofing)\n\n**Mise en place (≈30 min)**\n- **Station A - Bagels:** Mix dough with 250 g whole-wheat flour, 250 g bread flour, 7 g yeast, 10 g barley malt syrup, 300 ml warm water, 10 g salt. Knead and proof 1 h; shape into rings and proof again. Prepare water bath with 20 g baking soda.\n- **Station B - Cure salmon:** Rub 400 g salmon fillet with 50 g salt, 50 g sugar and zest of 1 orange; cure 2 h, rinse, pat dry and cold-smoke (or bake at 90 °C until just opaque if no smoker).\n- **Station C - Toppings:** Slice 2 avocados thinly, pickle 1 red onion in 30 ml cider vinegar and 5 g sugar, chop fresh dill, mix 200 g cream cheese with 10 g chopped chives.\n\n**Ingredients**\n- **Bagels:** 250 g whole-wheat flour, 250 g bread flour, 7 g yeast, 10 g malt syrup, 300 ml water, 10 g salt, 20 g baking soda for boiling.\n- **Cured salmon:** 400 g salmon fillet, 50 g coarse salt, 50 g sugar, zest of 1 orange, fresh dill.\n- **Toppings:** 2 avocados, 1 red onion, 30 ml cider vinegar, 5 g sugar, 200 g cream cheese, 10 g chives, fresh dill, lemon wedges.\n\n**Method**\n1. **Make bagels:** After second proof, boil bagels in alkaline water for 30 s per side; sprinkle with sesame seeds if desired; bake at 220 °C for 15 min until golden.\n2. **Prepare salmon:** After curing and rinsing, cold-smoke salmon for 30 min with applewood chips or bake low and slow until barely cooked. Slice thinly.\n3. **Assemble:** Split bagels and spread with chive cream cheese. Layer with avocado slices, smoked salmon and pickled red onions. Sprinkle with dill and serve with lemon wedges.\n\n**Why this works:** Boiling bagels in an alkaline bath gelatinises the exterior starch, creating the characteristic shiny crust. Whole-wheat flour increases fibre yet retains chew. Curing salmon lightly firms the flesh and concentrates flavour; cold smoking adds complexity without cooking.\n\n**Plating & Pairing:** Serve open-faced or closed, accompanied by a small side salad of dressed greens. Pair with a crisp rosé or a citrus-infused sparkling water."
    },
    {
      "id": "sous-vide-short-ribs-with-purple-potato-puree-sauteed-greens",
      "name": "Sous-Vide Short Ribs with Purple Potato Purée & Sautéed Greens",
      "cuisine": "American × Peruvian",
      "servings": "4",
      "activeTime": "1 h",
      "totalTime": "24 h (includes sous-vide)",
      "miseEnPlace": [
        "Station A - Ribs: Season 1.2 kg beef short ribs with 20 g salt, 10 g black pepper, 10 g brown sugar and 20 g miso paste. Vacuum-seal with 2 crushed garlic cloves and 2 sprigs thyme. Preheat sous-vide bath to 68 °C.",
        "Station B - Potatoes: Peel and cube 600 g purple potatoes; simmer in salted water until tender. Warm 100 ml whole milk and 50 g butter.",
        "Station C - Greens: Wash and chiffonade 300 g Swiss chard or kale. Slice 2 garlic cloves. Toast 30 g chopped pecans for garnish."
      ],
      "ingredients": [
        "1.2 kg beef short ribs, 20 g salt, 10 g pepper, 10 g brown sugar, 20 g miso paste, 2 garlic cloves, 2 thyme sprigs.",
        "Purple potato purée: 600 g purple potatoes, 100 ml whole milk, 50 g butter, 20 g Parmesan, salt.",
        "Sautéed greens: 300 g Swiss chard or kale, 2 garlic cloves, 15 ml olive oil, 30 g pecans.",
        "Glaze: 60 ml pomegranate molasses, 30 ml red wine, 10 ml balsamic vinegar."
      ],
      "method": [
        "Sous-vide ribs: Cook sealed ribs at 68 °C for 24 h. After cooking, remove from bag, pat dry and sear in a hot pan until deep brown. Reduce bag juices with pomegranate molasses, red wine and balsamic to glaze consistency.",
        "Make purée: Mash drained purple potatoes with warm milk, butter and Parmesan until smooth; season.",
        "Sauté greens: Heat olive oil; sauté garlic until fragrant. Add chard and cook until wilted; season and finish with toasted pecans.",
        "Serve: Spoon potato purée onto plates. Top with a rib portion, brush with glaze and arrange greens alongside."
      ],
      "whyThisWorks": "Long, low-temperature cooking converts collagen into gelatin without drying the meat, yielding fork-tender ribs. Miso and brown sugar in the cure enhance savoury depth and promote browning when seared. Purple potatoes provide antioxidants and a vivid colour contrast.",
      "plating": "Plate with glaze drizzled around and garnish with micro-herbs. Pair with a bold Malbec or a tart pomegranate mocktail.",
      "fullMarkdown": "## Sous-Vide Short Ribs with Purple Potato Purée & Sautéed Greens (American × Peruvian)\n\n**Servings:** 4 **Active time:** 1 h **Total time:** 24 h (includes sous-vide)\n\n**Mise en place (≈35 min)**\n- **Station A - Ribs:** Season 1.2 kg beef short ribs with 20 g salt, 10 g black pepper, 10 g brown sugar and 20 g miso paste. Vacuum-seal with 2 crushed garlic cloves and 2 sprigs thyme. Preheat sous-vide bath to 68 °C.\n- **Station B - Potatoes:** Peel and cube 600 g purple potatoes; simmer in salted water until tender. Warm 100 ml whole milk and 50 g butter.\n- **Station C - Greens:** Wash and chiffonade 300 g Swiss chard or kale. Slice 2 garlic cloves. Toast 30 g chopped pecans for garnish.\n\n**Ingredients**\n- 1.2 kg beef short ribs, 20 g salt, 10 g pepper, 10 g brown sugar, 20 g miso paste, 2 garlic cloves, 2 thyme sprigs.\n- Purple potato purée: 600 g purple potatoes, 100 ml whole milk, 50 g butter, 20 g Parmesan, salt.\n- Sautéed greens: 300 g Swiss chard or kale, 2 garlic cloves, 15 ml olive oil, 30 g pecans.\n- Glaze: 60 ml pomegranate molasses, 30 ml red wine, 10 ml balsamic vinegar.\n\n**Method**\n1. **Sous-vide ribs:** Cook sealed ribs at 68 °C for 24 h. After cooking, remove from bag, pat dry and sear in a hot pan until deep brown. Reduce bag juices with pomegranate molasses, red wine and balsamic to glaze consistency.\n2. **Make purée:** Mash drained purple potatoes with warm milk, butter and Parmesan until smooth; season.\n3. **Sauté greens:** Heat olive oil; sauté garlic until fragrant. Add chard and cook until wilted; season and finish with toasted pecans.\n4. **Serve:** Spoon potato purée onto plates. Top with a rib portion, brush with glaze and arrange greens alongside.\n\n**Why this works:** Long, low-temperature cooking converts collagen into gelatin without drying the meat, yielding fork-tender ribs. Miso and brown sugar in the cure enhance savoury depth and promote browning when seared. Purple potatoes provide antioxidants and a vivid colour contrast.\n\n**Plating & Pairing:** Plate with glaze drizzled around and garnish with micro-herbs. Pair with a bold Malbec or a tart pomegranate mocktail."
    },
    {
      "id": "sous-vide-eggs",
      "name": "Sous-Vide Eggs",
      "cuisine": "for general use",
      "servings": "4",
      "activeTime": "5 min",
      "totalTime": "50 min",
      "miseEnPlace": [],
      "ingredients": [],
      "method": [
        "Preheat a sous-vide water bath to 63 °C. Lower 4 eggs into the water and cook for 45 min. Transfer to ice water to stop cooking. Crack and gently peel when ready to serve. The whites will be set but creamy, and the yolks jam-like."
      ],
      "whyThisWorks": "Cooking at precisely 63 °C sets egg whites while leaving yolks rich and runny; the controlled environment prevents overcooking.",
      "plating": "",
      "fullMarkdown": "## Sous-Vide Eggs (for general use)\n\nAlthough sous-vide eggs are described in the birria ramen, this basic preparation applies to any breakfast or bowl needing a perfectly jammy egg.\n\n**Servings:** 4 **Active time:** 5 min **Total time:** 50 min\n\n**Method:** Preheat a sous-vide water bath to 63 °C. Lower 4 eggs into the water and cook for 45 min. Transfer to ice water to stop cooking. Crack and gently peel when ready to serve. The whites will be set but creamy, and the yolks jam-like.\n\n**Why this works:** Cooking at precisely 63 °C sets egg whites while leaving yolks rich and runny; the controlled environment prevents overcooking."
    },
    {
      "id": "spaghetti-cacio-e-pepe-oatmeal",
      "name": "Spaghetti Cacio e Pepe Oatmeal",
      "cuisine": "Italian × Andean",
      "servings": "4",
      "activeTime": "15 min",
      "totalTime": "25 min",
      "miseEnPlace": [
        "Station A - Oats: Measure 200 g rolled oats and 600 ml water. Grate 80 g Pecorino Romano and 20 g Parmigiano-Reggiano. Grind 5 g black pepper.",
        "Station B - Mushrooms: Clean and slice 200 g porcini or mixed mushrooms; mince 1 garlic clove; pick fresh thyme.",
        "Station C - Eggs (optional): Poach or fry 4 eggs for topping."
      ],
      "ingredients": [
        "200 g rolled oats, 600 ml water, 200 ml whole milk, 80 g Pecorino Romano, 20 g Parmigiano-Reggiano, 5 g freshly ground black pepper, 20 ml olive oil, 200 g mushrooms, 1 garlic clove, fresh thyme, salt."
      ],
      "method": [
        "Cook mushrooms: Sauté mushrooms in olive oil until golden; add minced garlic and thyme; season.",
        "Make oatmeal: In a saucepan, bring water and milk to a boil. Stir in oats; cook 5 min until creamy. Stir in cheeses and black pepper vigorously to emulsify. Adjust thickness with additional milk.",
        "Serve: Spoon oatmeal into bowls; top with sautéed mushrooms and an optional poached or fried egg. Grind extra pepper on top."
      ],
      "whyThisWorks": "Oats absorb liquid quickly, and adding cheese off heat prevents curdling. Freshly ground pepper releases volatile compounds that define this classic Roman flavour. Mushrooms add umami and meaty texture.",
      "plating": "Serve immediately while hot. Pair with a macchiato or a lightly floral white wine.",
      "fullMarkdown": "## Spaghetti Cacio e Pepe Oatmeal (Italian × Andean)\n\n**Servings:** 4 **Active time:** 15 min **Total time:** 25 min\n\n**Mise en place (≈10 min)**\n- **Station A - Oats:** Measure 200 g rolled oats and 600 ml water. Grate 80 g Pecorino Romano and 20 g Parmigiano-Reggiano. Grind 5 g black pepper.\n- **Station B - Mushrooms:** Clean and slice 200 g porcini or mixed mushrooms; mince 1 garlic clove; pick fresh thyme.\n- **Station C - Eggs (optional):** Poach or fry 4 eggs for topping.\n\n**Ingredients**\n- 200 g rolled oats, 600 ml water, 200 ml whole milk, 80 g Pecorino Romano, 20 g Parmigiano-Reggiano, 5 g freshly ground black pepper, 20 ml olive oil, 200 g mushrooms, 1 garlic clove, fresh thyme, salt.\n\n**Method**\n1. **Cook mushrooms:** Sauté mushrooms in olive oil until golden; add minced garlic and thyme; season.\n2. **Make oatmeal:** In a saucepan, bring water and milk to a boil. Stir in oats; cook 5 min until creamy. Stir in cheeses and black pepper vigorously to emulsify. Adjust thickness with additional milk.\n3. **Serve:** Spoon oatmeal into bowls; top with sautéed mushrooms and an optional poached or fried egg. Grind extra pepper on top.\n\n**Why this works:** Oats absorb liquid quickly, and adding cheese off heat prevents curdling. Freshly ground pepper releases volatile compounds that define this classic Roman flavour. Mushrooms add umami and meaty texture.\n\n**Plating & Pairing:** Serve immediately while hot. Pair with a macchiato or a lightly floral white wine."
    },
    {
      "id": "takoyaki-inspired-omelette-roll",
      "name": "Takoyaki-Inspired Omelette Roll",
      "cuisine": "Japanese",
      "servings": "4",
      "activeTime": "20 min",
      "totalTime": "35 min",
      "miseEnPlace": [
        "Station A - Batter: Beat 6 eggs with 30 ml dashi (or vegetable stock), 5 ml soy sauce and 5 ml mirin. Dice 100 g cooked octopus tentacle into small cubes. Mix 30 g chopped scallions, 20 g pickled ginger and 20 g tenkasu (tempura bits or toasted breadcrumbs).",
        "Station B - Sauces: Mix 30 ml Worcestershire sauce, 30 ml ketchup, 10 ml soy sauce and 10 g honey for okonomiyaki-style sauce. Prepare 50 g mayonnaise blended with 10 g yuzu juice or lime.",
        "Station C - Toppings: Shave 10 g bonito flakes (katsuobushi) and chop 10 g aonori (seaweed flakes)."
      ],
      "ingredients": [
        "6 eggs, 30 ml dashi, 5 ml soy sauce, 5 ml mirin, 100 g cooked octopus, 30 g scallions, 20 g pickled ginger, 20 g tenkasu, 30 ml Worcestershire sauce, 30 ml ketchup, 10 ml soy sauce, 10 g honey, 50 g mayonnaise, 10 g yuzu or lime juice, bonito flakes, aonori."
      ],
      "method": [
        "Cook omelette: Heat a rectangular tamagoyaki pan or non-stick skillet over medium heat. Lightly oil. Pour a thin layer of egg mixture to coat. Sprinkle with octopus, scallions, ginger and tenkasu. Once set, roll omelette toward you. Repeat layering and rolling until all egg is used, creating multiple layers.",
        "Glaze & slice: Brush the rolled omelette with okonomiyaki sauce and drizzle with yuzu mayo. Sprinkle with bonito flakes and aonori; the flakes will undulate from residual heat.",
        "Serve: Slice into rounds and serve warm."
      ],
      "whyThisWorks": "Tamagoyaki’s layered technique produces a tender yet structured omelette. Octopus pieces mimic takoyaki filling, while tenkasu adds crunch. The sweet-savory sauce and mayo provide richness and tang, and bonito flakes contribute smoky umami.",
      "plating": "Arrange slices neatly and garnish with extra scallions. Pair with cold green tea or a light pilsner.",
      "fullMarkdown": "## Takoyaki-Inspired Omelette Roll (Japanese)\n\n**Servings:** 4 **Active time:** 20 min **Total time:** 35 min\n\n**Mise en place (≈15 min)**\n- **Station A - Batter:** Beat 6 eggs with 30 ml dashi (or vegetable stock), 5 ml soy sauce and 5 ml mirin. Dice 100 g cooked octopus tentacle into small cubes. Mix 30 g chopped scallions, 20 g pickled ginger and 20 g tenkasu (tempura bits or toasted breadcrumbs).\n- **Station B - Sauces:** Mix 30 ml Worcestershire sauce, 30 ml ketchup, 10 ml soy sauce and 10 g honey for okonomiyaki-style sauce. Prepare 50 g mayonnaise blended with 10 g yuzu juice or lime.\n- **Station C - Toppings:** Shave 10 g bonito flakes (katsuobushi) and chop 10 g aonori (seaweed flakes).\n\n**Ingredients**\n- 6 eggs, 30 ml dashi, 5 ml soy sauce, 5 ml mirin, 100 g cooked octopus, 30 g scallions, 20 g pickled ginger, 20 g tenkasu, 30 ml Worcestershire sauce, 30 ml ketchup, 10 ml soy sauce, 10 g honey, 50 g mayonnaise, 10 g yuzu or lime juice, bonito flakes, aonori.\n\n**Method**\n1. **Cook omelette:** Heat a rectangular tamagoyaki pan or non-stick skillet over medium heat. Lightly oil. Pour a thin layer of egg mixture to coat. Sprinkle with octopus, scallions, ginger and tenkasu. Once set, roll omelette toward you. Repeat layering and rolling until all egg is used, creating multiple layers.\n2. **Glaze & slice:** Brush the rolled omelette with okonomiyaki sauce and drizzle with yuzu mayo. Sprinkle with bonito flakes and aonori; the flakes will undulate from residual heat.\n3. **Serve:** Slice into rounds and serve warm.\n\n**Why this works:** Tamagoyaki’s layered technique produces a tender yet structured omelette. Octopus pieces mimic takoyaki filling, while tenkasu adds crunch. The sweet-savory sauce and mayo provide richness and tang, and bonito flakes contribute smoky umami.\n\n**Plating & Pairing:** Arrange slices neatly and garnish with extra scallions. Pair with cold green tea or a light pilsner."
    },
    {
      "id": "whole-grain-chilaquiles-with-poached-eggs-and-salsa-roja",
      "name": "Whole-Grain Chilaquiles with Poached Eggs and Salsa Roja",
      "cuisine": "Mexican",
      "servings": "4",
      "activeTime": "30 min",
      "totalTime": "50 min",
      "miseEnPlace": [
        "Station A - Tortillas: Cut 8 whole-grain corn tortillas into wedges; brush with 15 ml oil and bake at 200 °C for 10 min until crisp.",
        "Station B - Salsa roja: Roast 5 tomatoes, 2 cloves garlic, 1 onion and 2 dried guajillo chiles; blend with 10 ml lime juice, 5 g cumin and salt.",
        "Station C - Garnish: Crumble 100 g queso fresco, slice 1 avocado, chop 20 g cilantro. Prepare 4 eggs for poaching."
      ],
      "ingredients": [
        "8 whole-grain corn tortillas, 5 tomatoes, 2 garlic cloves, 1 onion, 2 dried guajillo chiles, 10 ml lime juice, 5 g cumin, salt, 100 g queso fresco, 1 avocado, 20 g cilantro, 4 eggs."
      ],
      "method": [
        "Make chips: Bake tortilla wedges until golden and crisp; set aside.",
        "Prepare salsa: Dry-roast tomatoes, garlic, onion and guajillos in a hot pan until charred. Blend with lime juice, cumin and a splash of water to a smooth sauce; season.",
        "Poach eggs: Poach eggs in simmering acidulated water for 3 min; remove with a slotted spoon.",
        "Assemble chilaquiles: Heat salsa in a skillet; add tortilla chips and toss until coated but still crisp. Divide among plates. Top each with a poached egg, queso fresco, avocado slices and cilantro."
      ],
      "whyThisWorks": "Baking tortillas reduces oil while still producing crunchy chips. Charring vegetables adds smoky depth to the salsa. Tossing chips in hot salsa just before serving preserves some crunch, and the runny egg yolk enriches the sauce.",
      "plating": "Serve immediately with lime wedges. Pair with a michelada or cold brewed hibiscus tea.",
      "fullMarkdown": "## Whole-Grain Chilaquiles with Poached Eggs and Salsa Roja (Mexican)\n\n**Servings:** 4 **Active time:** 30 min **Total time:** 50 min\n\n**Mise en place (≈15 min)**\n- **Station A - Tortillas:** Cut 8 whole-grain corn tortillas into wedges; brush with 15 ml oil and bake at 200 °C for 10 min until crisp.\n- **Station B - Salsa roja:** Roast 5 tomatoes, 2 cloves garlic, 1 onion and 2 dried guajillo chiles; blend with 10 ml lime juice, 5 g cumin and salt.\n- **Station C - Garnish:** Crumble 100 g queso fresco, slice 1 avocado, chop 20 g cilantro. Prepare 4 eggs for poaching.\n\n**Ingredients**\n- 8 whole-grain corn tortillas, 5 tomatoes, 2 garlic cloves, 1 onion, 2 dried guajillo chiles, 10 ml lime juice, 5 g cumin, salt, 100 g queso fresco, 1 avocado, 20 g cilantro, 4 eggs.\n\n**Method**\n1. **Make chips:** Bake tortilla wedges until golden and crisp; set aside.\n2. **Prepare salsa:** Dry-roast tomatoes, garlic, onion and guajillos in a hot pan until charred. Blend with lime juice, cumin and a splash of water to a smooth sauce; season.\n3. **Poach eggs:** Poach eggs in simmering acidulated water for 3 min; remove with a slotted spoon.\n4. **Assemble chilaquiles:** Heat salsa in a skillet; add tortilla chips and toss until coated but still crisp. Divide among plates. Top each with a poached egg, queso fresco, avocado slices and cilantro.\n\n**Why this works:** Baking tortillas reduces oil while still producing crunchy chips. Charring vegetables adds smoky depth to the salsa. Tossing chips in hot salsa just before serving preserves some crunch, and the runny egg yolk enriches the sauce.\n\n**Plating & Pairing:** Serve immediately with lime wedges. Pair with a michelada or cold brewed hibiscus tea."
    },
    {
      "id": "whole-grain-croissant-with-jamon-del-pais-queso-fresco",
      "name": "Whole-Grain Croissant with Jamón del País & Queso Fresco",
      "cuisine": "French × Peruvian",
      "servings": "4",
      "activeTime": "1 h",
      "totalTime": "12 h (includes laminating/proofing)",
      "miseEnPlace": [
        "Station A - Dough: Prepare détrempe: combine 200 g whole-wheat flour, 200 g bread flour, 10 g yeast, 40 g sugar, 8 g salt, 220 ml cold milk and 50 g melted butter. Knead and refrigerate.",
        "Station B - Butter block: Flatten 250 g cold butter between parchment to a 20 cm square. Chill.",
        "Station C - Filling: Slice 200 g jamón del país (homemade or high-quality ham free of nitrites) and 200 g queso fresco; prepare 50 g rocoto jam by simmering 100 g rocoto with 30 g honey and 10 ml vinegar until thick."
      ],
      "ingredients": [
        "200 g whole-wheat flour, 200 g bread flour, 10 g instant yeast, 40 g sugar, 8 g salt, 220 ml milk, 50 g butter, 250 g butter for laminating.",
        "Filling: 200 g jamón del país, 200 g queso fresco, 50 g rocoto jam."
      ],
      "method": [
        "Laminate dough: Encapsulate butter block within détrempe and perform three single folds, resting dough in the refrigerator between folds to keep butter cold. Roll to 0.5 cm thick, cut into triangles and shape into croissants. Proof 2 h until puffy.",
        "Bake: Brush with egg wash and bake at 200 °C for 15 min until deeply golden and flaky.",
        "Assemble: Split croissants; spread rocoto jam. Fill with slices of jamón del país and queso fresco. Serve warm."
      ],
      "whyThisWorks": "Whole-wheat flour is tempered with bread flour to achieve flakiness while increasing fibre. Maintaining cold butter layers during lamination creates steam when baked, yielding distinct layers. Rocoto jam offers sweet heat to balance rich ham and cheese.",
      "plating": "Serve with a side salad of arugula and orange segments. Pair with a cappuccino or sparkling orange juice.",
      "fullMarkdown": "## Whole-Grain Croissant with Jamón del País & Queso Fresco (French × Peruvian)\n\n**Servings:** 4 **Active time:** 1 h **Total time:** 12 h (includes laminating/proofing)\n\n**Mise en place (≈1 h)**\n- **Station A - Dough:** Prepare détrempe: combine 200 g whole-wheat flour, 200 g bread flour, 10 g yeast, 40 g sugar, 8 g salt, 220 ml cold milk and 50 g melted butter. Knead and refrigerate.\n- **Station B - Butter block:** Flatten 250 g cold butter between parchment to a 20 cm square. Chill.\n- **Station C - Filling:** Slice 200 g jamón del país (homemade or high-quality ham free of nitrites) and 200 g queso fresco; prepare 50 g rocoto jam by simmering 100 g rocoto with 30 g honey and 10 ml vinegar until thick.\n\n**Ingredients**\n- 200 g whole-wheat flour, 200 g bread flour, 10 g instant yeast, 40 g sugar, 8 g salt, 220 ml milk, 50 g butter, 250 g butter for laminating.\n- Filling: 200 g jamón del país, 200 g queso fresco, 50 g rocoto jam.\n\n**Method**\n1. **Laminate dough:** Encapsulate butter block within détrempe and perform three single folds, resting dough in the refrigerator between folds to keep butter cold. Roll to 0.5 cm thick, cut into triangles and shape into croissants. Proof 2 h until puffy.\n2. **Bake:** Brush with egg wash and bake at 200 °C for 15 min until deeply golden and flaky.\n3. **Assemble:** Split croissants; spread rocoto jam. Fill with slices of jamón del país and queso fresco. Serve warm.\n\n**Why this works:** Whole-wheat flour is tempered with bread flour to achieve flakiness while increasing fibre. Maintaining cold butter layers during lamination creates steam when baked, yielding distinct layers. Rocoto jam offers sweet heat to balance rich ham and cheese.\n\n**Plating & Pairing:** Serve with a side salad of arugula and orange segments. Pair with a cappuccino or sparkling orange juice."
    },
    {
      "id": "whole-grain-gnocchi-a-la-huancaina-with-grilled-prawns",
      "name": "Whole-Grain Gnocchi a la Huancaína with Grilled Prawns",
      "cuisine": "Italian × Peruvian",
      "servings": "4",
      "activeTime": "1 h",
      "totalTime": "1 h 20 min",
      "miseEnPlace": [
        "Station A - Gnocchi: Bake 600 g russet potatoes until fluffy; peel and rice while hot. Mix with 150 g whole-wheat flour, 50 g grated Parmesan, 1 egg yolk and 5 g salt. Roll into ropes and cut into 2 cm pieces; press with a fork.",
        "Station B - Huancaína sauce: Blend 200 g queso fresco, 100 g aji amarillo paste, 200 ml evaporated milk, 2 crackers made from whole grains (for body), 2 garlic cloves and 30 ml olive oil until smooth.",
        "Station C - Prawns: Clean 12 large prawns (≈400 g); marinate with 10 ml olive oil, 5 ml lime juice, 1 g smoked paprika and salt."
      ],
      "ingredients": [
        "600 g russet potatoes, 150 g whole-wheat flour, 50 g Parmesan, 1 egg yolk, 5 g salt.",
        "Huancaína sauce: 200 g queso fresco, 100 g aji amarillo paste, 200 ml evaporated milk, 2 whole-grain crackers, 2 garlic cloves, 30 ml olive oil.",
        "12 large prawns, olive oil, lime juice, smoked paprika, salt.",
        "Garnish: Chopped olives, boiled quail eggs (optional), parsley."
      ],
      "method": [
        "Form gnocchi: Combine potatoes with flour, Parmesan, yolk and salt until a soft dough forms. Avoid overworking to keep light. Roll into ropes and cut. Dust with flour.",
        "Cook gnocchi: Boil salted water. Drop gnocchi in batches; cook until they float (≈2 min). Transfer to ice water briefly, then drain and toss with olive oil.",
        "Make sauce: Blend all sauce ingredients until smooth; adjust thickness with milk. Warm gently in a saucepan; do not boil.",
        "Grill prawns: Heat a grill pan; cook marinated prawns for 1 - 2 min per side until just opaque.",
        "Sauté gnocchi: In a skillet, heat 20 ml olive oil; sauté gnocchi until lightly golden. Toss with huancaína sauce. Top with grilled prawns, olives and parsley."
      ],
      "whyThisWorks": "Baking potatoes instead of boiling keeps them dry, producing lighter gnocchi. Using whole-wheat flour adds nuttiness and fibre without making the dumplings heavy. Huancaína sauce’s emulsified cheese and aji mixture coats each gnocchi, while grilling prawns adds smoky sweetness.",
      "plating": "Serve in shallow bowls with sauce pooling around. Pair with a crisp Sauvignon Blanc or maracuya (passion fruit) juice.",
      "fullMarkdown": "## Whole-Grain Gnocchi a la Huancaína with Grilled Prawns (Italian × Peruvian)\n\n**Servings:** 4 **Active time:** 1 h **Total time:** 1 h 20 min\n\n**Mise en place (≈30 min)**\n- **Station A - Gnocchi:** Bake 600 g russet potatoes until fluffy; peel and rice while hot. Mix with 150 g whole-wheat flour, 50 g grated Parmesan, 1 egg yolk and 5 g salt. Roll into ropes and cut into 2 cm pieces; press with a fork.\n- **Station B - Huancaína sauce:** Blend 200 g queso fresco, 100 g aji amarillo paste, 200 ml evaporated milk, 2 crackers made from whole grains (for body), 2 garlic cloves and 30 ml olive oil until smooth.\n- **Station C - Prawns:** Clean 12 large prawns (≈400 g); marinate with 10 ml olive oil, 5 ml lime juice, 1 g smoked paprika and salt.\n\n**Ingredients**\n- 600 g russet potatoes, 150 g whole-wheat flour, 50 g Parmesan, 1 egg yolk, 5 g salt.\n- Huancaína sauce: 200 g queso fresco, 100 g aji amarillo paste, 200 ml evaporated milk, 2 whole-grain crackers, 2 garlic cloves, 30 ml olive oil.\n- 12 large prawns, olive oil, lime juice, smoked paprika, salt.\n- Garnish: Chopped olives, boiled quail eggs (optional), parsley.\n\n**Method**\n1. **Form gnocchi:** Combine potatoes with flour, Parmesan, yolk and salt until a soft dough forms. Avoid overworking to keep light. Roll into ropes and cut. Dust with flour.\n2. **Cook gnocchi:** Boil salted water. Drop gnocchi in batches; cook until they float (≈2 min). Transfer to ice water briefly, then drain and toss with olive oil.\n3. **Make sauce:** Blend all sauce ingredients until smooth; adjust thickness with milk. Warm gently in a saucepan; do not boil.\n4. **Grill prawns:** Heat a grill pan; cook marinated prawns for 1 - 2 min per side until just opaque.\n5. **Sauté gnocchi:** In a skillet, heat 20 ml olive oil; sauté gnocchi until lightly golden. Toss with huancaína sauce. Top with grilled prawns, olives and parsley.\n\n**Why this works:** Baking potatoes instead of boiling keeps them dry, producing lighter gnocchi. Using whole-wheat flour adds nuttiness and fibre without making the dumplings heavy. Huancaína sauce’s emulsified cheese and aji mixture coats each gnocchi, while grilling prawns adds smoky sweetness.\n\n**Plating & Pairing:** Serve in shallow bowls with sauce pooling around. Pair with a crisp Sauvignon Blanc or maracuya (passion fruit) juice."
    },
    {
      "id": "whole-grain-pizza-diavola-with-rocoto-honey",
      "name": "Whole-Grain Pizza Diavola with Rocoto Honey",
      "cuisine": "Italian × Peruvian",
      "servings": "4",
      "activeTime": "45 min",
      "totalTime": "18 h (includes dough fermentation)",
      "miseEnPlace": [
        "Station A - Dough: Combine 250 g whole-wheat flour, 250 g bread flour, 2 g instant yeast, 350 ml water, 10 g salt and 20 ml olive oil. Mix until shaggy and refrigerate for slow fermentation (12-24 h). Bring to room temperature 2 h before baking.",
        "Station B - Sauce & toppings: Simmer 400 g crushed tomatoes with 2 garlic cloves and 5 g oregano; slice 150 g spicy artisanal salami (cured at home or nitrate-free), 1 red bell pepper and 1 red onion; slice 200 g fresh mozzarella.",
        "Station C - Rocoto honey: Heat 50 g honey with 20 g rocoto paste until combined; cool."
      ],
      "ingredients": [
        "250 g whole-wheat flour, 250 g bread flour, 2 g yeast, 350 ml water, 10 g salt, 20 ml olive oil.",
        "Toppings: 400 g crushed tomatoes, 2 garlic cloves, oregano, 150 g spicy salami (homemade), 1 red bell pepper, 1 red onion, 200 g mozzarella, 50 g rocoto honey, 10 g chili flakes."
      ],
      "method": [
        "Prepare dough: Mix ingredients and knead gently. Refrigerate in a covered container for 12 - 24 h. On baking day, divide and shape into balls; rest until puffy.",
        "Preheat oven: Heat a baking stone at 250 °C for at least 45 min. Stretch dough into 30 cm rounds.",
        "Assemble pizza: Spread a thin layer of tomato sauce. Top with salami, bell pepper, onion and mozzarella. Bake on the stone for 8 - 10 min until crust is crisp and toppings bubbly.",
        "Finish: Drizzle with rocoto honey and sprinkle with chili flakes and fresh oregano."
      ],
      "whyThisWorks": "Long fermentation develops flavour and elasticity in the dough. Baking on a preheated stone replicates a wood-fired oven, producing a crisp bottom. Rocoto honey provides sweet heat that contrasts with spicy salami and tangy tomato sauce.",
      "plating": "Slice and serve immediately. Pair with a dry Lambrusco or a berry-infused sparkling water.",
      "fullMarkdown": "## Whole-Grain Pizza Diavola with Rocoto Honey (Italian × Peruvian)\n\n**Servings:** 4 **Active time:** 45 min **Total time:** 18 h (includes dough fermentation)\n\n**Mise en place (≈30 min)**\n- **Station A - Dough:** Combine 250 g whole-wheat flour, 250 g bread flour, 2 g instant yeast, 350 ml water, 10 g salt and 20 ml olive oil. Mix until shaggy and refrigerate for slow fermentation (12-24 h). Bring to room temperature 2 h before baking.\n- **Station B - Sauce & toppings:** Simmer 400 g crushed tomatoes with 2 garlic cloves and 5 g oregano; slice 150 g spicy artisanal salami (cured at home or nitrate-free), 1 red bell pepper and 1 red onion; slice 200 g fresh mozzarella.\n- **Station C - Rocoto honey:** Heat 50 g honey with 20 g rocoto paste until combined; cool.\n\n**Ingredients**\n- 250 g whole-wheat flour, 250 g bread flour, 2 g yeast, 350 ml water, 10 g salt, 20 ml olive oil.\n- Toppings: 400 g crushed tomatoes, 2 garlic cloves, oregano, 150 g spicy salami (homemade), 1 red bell pepper, 1 red onion, 200 g mozzarella, 50 g rocoto honey, 10 g chili flakes.\n\n**Method**\n1. **Prepare dough:** Mix ingredients and knead gently. Refrigerate in a covered container for 12 - 24 h. On baking day, divide and shape into balls; rest until puffy.\n2. **Preheat oven:** Heat a baking stone at 250 °C for at least 45 min. Stretch dough into 30 cm rounds.\n3. **Assemble pizza:** Spread a thin layer of tomato sauce. Top with salami, bell pepper, onion and mozzarella. Bake on the stone for 8 - 10 min until crust is crisp and toppings bubbly.\n4. **Finish:** Drizzle with rocoto honey and sprinkle with chili flakes and fresh oregano.\n\n**Why this works:** Long fermentation develops flavour and elasticity in the dough. Baking on a preheated stone replicates a wood-fired oven, producing a crisp bottom. Rocoto honey provides sweet heat that contrasts with spicy salami and tangy tomato sauce.\n\n**Plating & Pairing:** Slice and serve immediately. Pair with a dry Lambrusco or a berry-infused sparkling water."
    },
    {
      "id": "whole-grain-pizza-diavola",
      "name": "Whole-Grain Pizza Diavola",
      "cuisine": "Substitution for Non-Meat Option",
      "servings": "",
      "activeTime": "",
      "totalTime": "",
      "miseEnPlace": [],
      "ingredients": [],
      "method": [],
      "whyThisWorks": "",
      "plating": "",
      "fullMarkdown": "## Whole-Grain Pizza Diavola (Substitution for Non-Meat Option)\n\nFor a vegetarian variation, replace salami with roasted mushrooms and strips of roasted eggplant; drizzle with rocoto honey as above."
    },
    {
      "id": "whole-grain-spaghetti-puttanesca-with-aji-panca-seafood",
      "name": "Whole-Grain Spaghetti Puttanesca with Ají Panca Seafood",
      "cuisine": "Italian × Peruvian",
      "servings": "4",
      "activeTime": "30 min",
      "totalTime": "45 min",
      "miseEnPlace": [
        "Station A - Pasta: Cook 400 g whole-grain spaghetti in abundant salted water until al dente; reserve 200 ml pasta water.",
        "Station B - Sauce: Chop 4 anchovy fillets, mince 4 garlic cloves, chop 10 g ají panca paste, pit 80 g olives, rinse 30 g capers, chop 400 g canned San Marzano tomatoes.",
        "Station C - Seafood: Clean 300 g squid tubes (cut into rings) and 200 g shrimp."
      ],
      "ingredients": [
        "400 g whole-grain spaghetti, 4 anchovy fillets, 4 garlic cloves, 10 g ají panca paste, 80 g olives, 30 g capers, 400 g canned tomatoes, 300 g squid, 200 g shrimp, 5 g red pepper flakes, 30 ml olive oil, 5 ml red wine vinegar, 20 g parsley."
      ],
      "method": [
        "Make sauce: In a large skillet, warm olive oil; melt anchovies and garlic until fragrant. Add ají panca paste and red pepper flakes; cook 1 min. Stir in tomatoes, olives and capers; simmer 10 min until thickened.",
        "Cook seafood: Add squid rings and shrimp to the sauce; cook 2-3 min until just opaque.",
        "Combine: Toss cooked spaghetti with sauce, adding reserved pasta water to loosen as needed. Finish with red wine vinegar and chopped parsley."
      ],
      "whyThisWorks": "Ají panca introduces a smoky, mild heat that complements the briny anchovies and olives. Whole-grain pasta brings extra nutty flavour and fibre, and reserved pasta water emulsifies the sauce, helping it cling to each strand.",
      "plating": "Twirl pasta into nests on warm plates; top with extra seafood pieces. Pair with a dry rosé or citrus-infused sparkling water.",
      "fullMarkdown": "## Whole-Grain Spaghetti Puttanesca with Ají Panca Seafood (Italian × Peruvian)\n\n**Servings:** 4 **Active time:** 30 min **Total time:** 45 min\n\n**Mise en place (≈15 min)**\n- **Station A - Pasta:** Cook 400 g whole-grain spaghetti in abundant salted water until al dente; reserve 200 ml pasta water.\n- **Station B - Sauce:** Chop 4 anchovy fillets, mince 4 garlic cloves, chop 10 g ají panca paste, pit 80 g olives, rinse 30 g capers, chop 400 g canned San Marzano tomatoes.\n- **Station C - Seafood:** Clean 300 g squid tubes (cut into rings) and 200 g shrimp.\n\n**Ingredients**\n- 400 g whole-grain spaghetti, 4 anchovy fillets, 4 garlic cloves, 10 g ají panca paste, 80 g olives, 30 g capers, 400 g canned tomatoes, 300 g squid, 200 g shrimp, 5 g red pepper flakes, 30 ml olive oil, 5 ml red wine vinegar, 20 g parsley.\n\n**Method**\n1. **Make sauce:** In a large skillet, warm olive oil; melt anchovies and garlic until fragrant. Add ají panca paste and red pepper flakes; cook 1 min. Stir in tomatoes, olives and capers; simmer 10 min until thickened.\n2. **Cook seafood:** Add squid rings and shrimp to the sauce; cook 2-3 min until just opaque.\n3. **Combine:** Toss cooked spaghetti with sauce, adding reserved pasta water to loosen as needed. Finish with red wine vinegar and chopped parsley.\n\n**Why this works:** Ají panca introduces a smoky, mild heat that complements the briny anchovies and olives. Whole-grain pasta brings extra nutty flavour and fibre, and reserved pasta water emulsifies the sauce, helping it cling to each strand.\n\n**Plating & Pairing:** Twirl pasta into nests on warm plates; top with extra seafood pieces. Pair with a dry rosé or citrus-infused sparkling water."
    },
    {
      "id": "whiskey-pecan-dark-chocolate-tart",
      "name": "Whiskey Pecan Dark Chocolate Tart",
      "cuisine": "American",
      "servings": "8",
      "activeTime": "1 h",
      "totalTime": "4 h (includes chilling)",
      "miseEnPlace": [
        "Station A - Tart shell: Combine 200 g whole-wheat flour, 50 g almond flour, 30 g cocoa powder, 50 g raw sugar and 120 g cold butter. Rub to sandy crumbs; add 1 beaten egg and form a dough. Press into a 24 cm tart tin; chill 30 min.",
        "Station B - Ganache: Chop 250 g 70 % dark chocolate. Heat 250 ml heavy cream with 30 g honey until steaming; pour over chocolate and stir until smooth. Stir in 30 ml whiskey (optional) and 50 g butter.",
        "Station C - Pecans: Toast 150 g pecans; reserve 50 g for garnish."
      ],
      "ingredients": [
        "Tart shell: 200 g whole-wheat flour, 50 g almond flour, 30 g cocoa powder, 50 g raw sugar, 120 g butter, 1 egg, pinch salt.",
        "Filling: 250 g dark chocolate, 250 ml heavy cream, 30 g honey, 30 ml whiskey (optional), 50 g butter, 100 g toasted pecans.",
        "Garnish: 50 g toasted pecans, flaky sea salt."
      ],
      "method": [
        "Bake shell: Blind-bake chilled tart shell at 180 °C for 15 min with weights; remove weights and bake 10 min more until crisp. Cool.",
        "Make ganache: Combine hot cream and honey with chopped chocolate; stir until glossy. Stir in butter and whiskey until emulsified. Fold in 100 g chopped pecans.",
        "Fill tart: Pour ganache into cooled shell; smooth top. Arrange remaining pecans decoratively. Chill for 3 h until set.",
        "Finish: Sprinkle with flaky sea salt just before serving."
      ],
      "whyThisWorks": "Whole-wheat and almond flours create a tender yet sturdy shell with nutty flavour. Honey lightly sweetens the ganache and aids emulsification. Whiskey adds complexity without excessive alcohol; to omit, replace with vanilla extract.",
      "plating": "Slice tart with a hot knife for clean edges. Serve with a dollop of crème fraîche or Greek yoghurt. Pair with a small pour of tawny Port or black coffee.",
      "fullMarkdown": "## Whiskey Pecan Dark Chocolate Tart (American)\n\n**Servings:** 8 **Active time:** 1 h **Total time:** 4 h (includes chilling)\n\n**Mise en place (≈45 min)**\n- **Station A - Tart shell:** Combine 200 g whole-wheat flour, 50 g almond flour, 30 g cocoa powder, 50 g raw sugar and 120 g cold butter. Rub to sandy crumbs; add 1 beaten egg and form a dough. Press into a 24 cm tart tin; chill 30 min.\n- **Station B - Ganache:** Chop 250 g 70 % dark chocolate. Heat 250 ml heavy cream with 30 g honey until steaming; pour over chocolate and stir until smooth. Stir in 30 ml whiskey (optional) and 50 g butter.\n- **Station C - Pecans:** Toast 150 g pecans; reserve 50 g for garnish.\n\n**Ingredients**\n- Tart shell: 200 g whole-wheat flour, 50 g almond flour, 30 g cocoa powder, 50 g raw sugar, 120 g butter, 1 egg, pinch salt.\n- Filling: 250 g dark chocolate, 250 ml heavy cream, 30 g honey, 30 ml whiskey (optional), 50 g butter, 100 g toasted pecans.\n- Garnish: 50 g toasted pecans, flaky sea salt.\n\n**Method**\n1. **Bake shell:** Blind-bake chilled tart shell at 180 °C for 15 min with weights; remove weights and bake 10 min more until crisp. Cool.\n2. **Make ganache:** Combine hot cream and honey with chopped chocolate; stir until glossy. Stir in butter and whiskey until emulsified. Fold in 100 g chopped pecans.\n3. **Fill tart:** Pour ganache into cooled shell; smooth top. Arrange remaining pecans decoratively. Chill for 3 h until set.\n4. **Finish:** Sprinkle with flaky sea salt just before serving.\n\n**Why this works:** Whole-wheat and almond flours create a tender yet sturdy shell with nutty flavour. Honey lightly sweetens the ganache and aids emulsification. Whiskey adds complexity without excessive alcohol; to omit, replace with vanilla extract.\n\n**Plating & Pairing:** Slice tart with a hot knife for clean edges. Serve with a dollop of crème fraîche or Greek yoghurt. Pair with a small pour of tawny Port or black coffee."
    },
    {
      "id": "whole-grain-bagels",
      "name": "Whole-Grain Bagels",
      "cuisine": "Base for breakfast",
      "servings": "",
      "activeTime": "",
      "totalTime": "",
      "miseEnPlace": [],
      "ingredients": [],
      "method": [],
      "whyThisWorks": "",
      "plating": "",
      "fullMarkdown": "## Whole-Grain Bagels (Base for breakfast)\n\nRefer to the Smoked Salmon & Avocado Bagel recipe for instructions on making bagels. They can be prepared in bulk and frozen for other breakfasts during the month."
    }
  ],
  "shoppingLists": [
    {
      "week": 1,
      "categories": [
        {
          "category": "Produce",
          "items": [
            "Artichokes (6 whole)",
            "lemons (4)",
            "limes (12)",
            "cilantro (3 bunches)",
            "chives",
            "red onions (4)",
            "cucumbers (3)",
            "avocados (4)",
            "purple corn or chicha morada concentrate",
            "pineapple",
            "tomatoes (8)",
            "sweet potatoes (2)",
            "red cabbage",
            "carrot",
            "mango",
            "plantains (3)",
            "rocoto chiles",
            "garlic (3 heads)",
            "ginger",
            "scallions",
            "mushrooms (200 g)",
            "shallot",
            "edamame (200 g)",
            "kale (200 g)",
            "radishes",
            "micro-greens",
            "herbs (mint, parsley)."
          ]
        },
        {
          "category": "Proteins",
          "items": [
            "Smoked trout (200 g)",
            "salmon fillet (720 g)",
            "sashimi-grade tuna/salmon (200 g)",
            "beef sirloin (1 kg)",
            "lamb or beef chuck (800 g)",
            "beef sirloin for bulgogi (400 g)",
            "seafood mix (cod 600 g, prawns 400 g, squid 300 g)",
            "turkey mince (250 g)",
            "firm tofu (400 g)",
            "eggs (3 dozen)",
            "chicken breasts (4)",
            "black cod (600 g)",
            "short ribs (1.2 kg)."
          ]
        },
        {
          "category": "Dairy",
          "items": [
            "Butter (500 g)",
            "heavy cream (500 ml)",
            "whole milk (1 L)",
            "Greek yoghurt (600 g)",
            "cream cheese (200 g)",
            "mascarpone (250 g)",
            "queso fresco (600 g)",
            "mozzarella (200 g)",
            "Parmesan & Pecorino (400 g total)."
          ]
        },
        {
          "category": "Grains & bakery",
          "items": [
            "Whole-wheat flour (2 kg)",
            "bread flour (1 kg)",
            "quinoa (800 g)",
            "brown rice (1 kg)",
            "whole-grain tortillas",
            "corn tortillas",
            "ramen noodles",
            "whole-wheat spaghetti",
            "whole-wheat gnocchi ingredients (potatoes)",
            "oats (200 g)",
            "whole-grain ladyfinger ingredients",
            "whole-grain pizza dough ingredients",
            "whole-grain crackers",
            "purple potatoes",
            "bagel ingredients."
          ]
        },
        {
          "category": "Pantry",
          "items": [
            "Olive oil (500 ml)",
            "sesame oil",
            "sunflower oil",
            "soy sauce",
            "tamari",
            "fish sauce",
            "oyster sauce",
            "miso (white and red)",
            "aji amarillo paste (300 g)",
            "ají panca paste",
            "rocoto paste",
            "chipotle in adobo",
            "dried guajillo and ancho chiles",
            "cumin",
            "coriander seeds",
            "cinnamon stick",
            "cloves",
            "star anise",
            "brown sugar",
            "honey",
            "coconut sugar",
            "raw sugar",
            "cocoa powder",
            "dark chocolate (500 g)",
            "almonds",
            "pecans",
            "peanuts",
            "sesame seeds",
            "seaweed (nori)",
            "bonito flakes",
            "tenkasu or breadcrumbs",
            "vinegar (rice, cider, white)",
            "baking powder",
            "yeast",
            "malt syrup."
          ]
        },
        {
          "category": "Beverages & Misc.",
          "items": [
            "Sparkling water",
            "sake (optional)",
            "dry white wine (750 ml)",
            "pomegranate molasses",
            "Marsala or fortified wine (for tiramisu)",
            "whiskey (optional)",
            "beer or non-alcoholic alternatives."
          ]
        }
      ]
    },
    {
      "week": 2,
      "categories": [
        {
          "category": "Produce",
          "items": [
            "Mushrooms (400 g)",
            "artichokes",
            "tomatoes (8)",
            "bell peppers (3)",
            "eggplant (optional)",
            "olives (80 g)",
            "capers (30 g)",
            "carrots",
            "celery",
            "onions",
            "spinach or Swiss chard",
            "purple potatoes",
            "lemons",
            "limes",
            "herbs (basil, oregano, rosemary)",
            "lucuma purée or fresh lucuma",
            "salad greens."
          ]
        },
        {
          "category": "Proteins",
          "items": [
            "Sea scallops (8)",
            "prawns (12)",
            "chicken breasts (4)",
            "grass-fed beef or lamb for birria (remainder if needed)",
            "salmon",
            "tuna",
            "cod",
            "turkey mince (if replenishing)",
            "eggs."
          ]
        },
        {
          "category": "Dairy",
          "items": [
            "Parmesan",
            "Pecorino",
            "mozzarella",
            "mascarpone",
            "Greek yoghurt",
            "cream cheese."
          ]
        },
        {
          "category": "Grains",
          "items": [
            "Brown rice",
            "whole-grain pasta",
            "whole-wheat flour",
            "bread flour",
            "quinoa",
            "corn tortillas",
            "whole-grain crackers",
            "whole-grain pizza dough ingredients."
          ]
        },
        {
          "category": "Pantry",
          "items": [
            "Canned San Marzano tomatoes",
            "anchovies",
            "anchovy fillets",
            "olives",
            "capers",
            "ají panca paste",
            "dried herbs",
            "chipotle",
            "cocoa powder",
            "honey",
            "raw sugar",
            "dark chocolate",
            "espresso beans",
            "nuts (pecans)",
            "spices as needed."
          ]
        }
      ]
    },
    {
      "week": 3,
      "categories": [
        {
          "category": "Produce",
          "items": [
            "Mangoes",
            "jicama",
            "red cabbage",
            "limes",
            "avocados",
            "cucumbers",
            "carrots",
            "onions",
            "tomatoes",
            "radishes",
            "cilantro",
            "Thai basil",
            "shallots",
            "ginger",
            "garlic",
            "scallions",
            "chili peppers (guajillo, ancho, chipotle)",
            "sesame seeds",
            "edamame",
            "kimchi ingredients if making from scratch (napa cabbage, daikon, Korean chile powder)."
          ]
        },
        {
          "category": "Proteins",
          "items": [
            "White fish for tacos (600 g)",
            "salmon",
            "turkey mince",
            "tofu",
            "lamb or beef for birria (if not leftover)",
            "eggs",
            "squid",
            "shrimp",
            "octopus",
            "ground turkey."
          ]
        },
        {
          "category": "Dairy",
          "items": [
            "Greek yoghurt",
            "crema or sour cream alternative",
            "cotija cheese",
            "butter."
          ]
        },
        {
          "category": "Grains",
          "items": [
            "Whole-wheat tortillas",
            "corn tortillas",
            "brown rice",
            "quinoa",
            "ramen noodles."
          ]
        },
        {
          "category": "Pantry",
          "items": [
            "Cornstarch",
            "baking powder",
            "sparkling water",
            "soy sauce",
            "gochujang",
            "sesame oil",
            "mirin",
            "miso",
            "miso paste",
            "sake (optional)",
            "vinegars",
            "chipotle in adobo",
            "cumin",
            "smoked paprika",
            "cinnamon",
            "honey",
            "cocoa powder."
          ]
        }
      ]
    },
    {
      "week": 4,
      "categories": [
        {
          "category": "Produce",
          "items": [
            "Purple potatoes",
            "Swiss chard or kale",
            "oranges (for curing salmon)",
            "dill",
            "fresh herbs (parsley, cilantro)",
            "garlic",
            "onions",
            "mushrooms",
            "cabbage",
            "carrots",
            "celery",
            "lettuce",
            "avocados",
            "lemons",
            "limes",
            "pomegranates or pomegranate juice."
          ]
        },
        {
          "category": "Proteins",
          "items": [
            "Salmon fillet (for curing)",
            "beef short ribs",
            "chicken thighs",
            "Wagyu or grass-fed beef mince (800 g)",
            "duck breasts (4)",
            "bacon optional for burger toppings (choose nitrate-free)",
            "eggs."
          ]
        },
        {
          "category": "Dairy",
          "items": [
            "Butter",
            "milk",
            "cream",
            "Greek yoghurt",
            "cream cheese",
            "cheddar",
            "mozzarella",
            "Parmesan",
            "mascarpone."
          ]
        },
        {
          "category": "Grains",
          "items": [
            "Whole-wheat flour",
            "bread flour",
            "almond meal",
            "cornmeal (for fried chicken breading)",
            "farro",
            "whole-grain buns or ingredients to make them",
            "bagels (if not already made)",
            "sourdough loaf",
            "popcorn kernels."
          ]
        },
        {
          "category": "Pantry",
          "items": [
            "Pomegranate molasses",
            "miso",
            "soy sauce",
            "honey",
            "brown sugar",
            "spices (smoked paprika, cayenne)",
            "whiskey",
            "bourbon",
            "cocoa powder",
            "dark chocolate",
            "nuts (pecans)",
            "nutritional yeast",
            "truffle oil or truffle salt."
          ]
        }
      ]
    }
  ],
  "recipeIntro": "The recipes are listed alphabetically by primary meal name. All ingredients are given in metric units. Each recipe yields four generous servings unless noted. The mise en place section breaks down pre-prep tasks into stations, optimising workflow; approximate times are provided. Methods call for just-in-time preparation, sensory cues and scientifically informed techniques. “Why this works” offers a brief food-science explanation. Pairing notes suggest wines or non-alcoholic beverages that complement the dish and respect the guidelines (moderate alcohol). For optional wine pairings, limit to one glass for women and two for men as advised."
};
